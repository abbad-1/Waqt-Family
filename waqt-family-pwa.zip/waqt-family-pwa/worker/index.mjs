// Waqt Cloudflare Worker (Option A: 100% Card-Free Stack — Workers + D1 + Cron + Native VAPID Web Push)
// Zero npm runtime dependencies. Uses standard Web Crypto, Fetch, and D1 bindings.

import {
  PRAYERS,
  PRAYER_ARABIC,
  METHOD_PRESETS,
  validateTimeZone,
  localDateString,
  timesForDate,
  nextReminderSchedule,
  currentPrayerWindow,
  formatTimeInZone,
  endOfLocalDayUtc,
} from '../shared/prayer-engine.mjs';
import { D1WaqtStore } from './store-d1.mjs';
import { sendWebPush, base64UrlEncode } from './webpush.mjs';

const MAX_CIRCLE_MEMBERS = 20;
const MAX_PUSH_DELAY_MS = 10 * 60 * 1000;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const CHARACTER_LINES = {
  'little-noor': { name: 'Little Noor', line: 'Wakey wakey, Fajr is here!' },
  teta: { name: 'Teta', line: 'Habibi, have you prayed yet?' },
  jiddo: { name: 'Jiddo', line: 'Come, we pray together.' },
  sami: { name: 'Sami', line: 'Race you to the prayer mat!' },
  hilal: { name: 'Hilal', line: 'Mashallah! {prayer} is done.' },
  fanous: { name: 'Fanous', line: 'Your light is waiting.' },
};

const VALID_METHODS = new Set(Object.keys(METHOD_PRESETS));
const VALID_ASR = new Set(['standard', 'hanafi']);
const VALID_HIGH_LAT = new Set(['auto', 'middleOfTheNight', 'seventhOfTheNight', 'twilightAngle']);
const VALID_CHAR_STYLES = new Set(['characters', 'symbols', 'off']);
const VALID_CHARACTERS = new Set(Object.keys(CHARACTER_LINES));

const encoder = new TextEncoder();

async function sha256Hex(input) {
  const digest = await globalThis.crypto.subtle.digest('SHA-256', encoder.encode(input));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function randomId(prefix = 'id') {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(12));
  return `${prefix}_${base64UrlEncode(bytes)}`;
}

function randomToken() {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(24));
  return base64UrlEncode(bytes);
}

function randomInviteCode(circleName) {
  const prefix =
    String(circleName || 'FAM')
      .replace(/[^A-Za-z]/g, '')
      .slice(0, 3)
      .toUpperCase()
      .padEnd(3, 'X');
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(4));
  let suffix = '';
  for (let i = 0; i < 4; i += 1) {
    suffix += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  }
  return `${prefix}-${suffix}`;
}

function jsonResponse(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...extraHeaders,
    },
  });
}

function errorResponse(message, status = 400, code = 'bad_request') {
  return jsonResponse({ ok: false, error: message, code }, status);
}

function isQuiet(user, nowMs) {
  return Boolean(user.quietUntilMs && user.quietUntilMs > nowMs);
}

function joinNames(names) {
  if (names.length === 0) return 'Someone';
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} and ${names[1]}`;
  const others = names.length - 2;
  return `${names[0]}, ${names[1]} and ${others} ${others === 1 ? 'other' : 'others'}`;
}

function vapidFromEnv(env) {
  if (!env || !env.VAPID_PUBLIC_KEY || !env.VAPID_PRIVATE_KEY) return null;
  return {
    publicKey: String(env.VAPID_PUBLIC_KEY).trim(),
    privateKey: String(env.VAPID_PRIVATE_KEY).trim(),
    subject: String(env.VAPID_SUBJECT || 'mailto:family@waqt.app').trim(),
  };
}

async function pushToUser(store, env, uid, payload, fetchImpl = globalThis.fetch) {
  const vapid = vapidFromEnv(env);
  if (!vapid) return { sent: 0, skipped: true };
  const subs = await store.getPushSubscriptions(uid);
  if (subs.length === 0) return { sent: 0 };

  let sent = 0;
  await Promise.all(
    subs.map(async (sub) => {
      try {
        const res = await sendWebPush(sub, payload, vapid, fetchImpl);
        if (res.ok) sent += 1;
        else if (res.gone) await store.deletePushSubscription(sub.endpoint);
      } catch {
        // Ignore transient network errors on individual push endpoints
      }
    })
  );
  return { sent };
}

function computeNextReminderFields(user, now) {
  if (Number(user.remindOffsetMinutes) < 0) {
    return { nextPrayerName: null, nextPrayerAtMs: null, nextPrayerDate: null };
  }
  const sched = nextReminderSchedule(user, now);
  if (!sched) {
    return { nextPrayerName: null, nextPrayerAtMs: null, nextPrayerDate: null };
  }
  return {
    nextPrayerName: sched.name,
    nextPrayerAtMs: sched.at.getTime(),
    nextPrayerDate: sched.date,
  };
}

function sanitizeContact(raw) {
  return String(raw || '').trim().slice(0, 80);
}

async function serializeMemberView(store, viewerUid, member, now) {
  const isSelf = viewerUid === member.uid;
  const win = currentPrayerWindow(member, now);
  const canSeeStatus = isSelf || member.shareStatus === true;
  const log = canSeeStatus ? await store.getPrayerLog(member.uid, win.date) : null;
  const todayLog =
    canSeeStatus && win.todayDate !== win.date
      ? await store.getPrayerLog(member.uid, win.todayDate)
      : log;

  const canSeeCity = isSelf || member.showCity === true;
  let alreadyNudgedByMe = false;
  if (!isSelf) {
    const memberNudges = await store.getNudgesForRecipientPrayer(member.uid, win.date, win.name);
    alreadyNudgedByMe = memberNudges.some((n) => n.fromUid === viewerUid);
  }

  return {
    uid: member.uid,
    displayName: member.displayName,
    isSelf,
    city: canSeeCity ? member.city : null,
    country: canSeeCity ? member.country : null,
    tz: canSeeCity ? member.tz : null,
    shareStatus: member.shareStatus,
    showCity: member.showCity,
    isPrivate: !isSelf && !member.shareStatus,
    alreadyNudgedByMe,
    phone: member.phone || '',
    facetimeId: member.facetimeId || '',
    characterStyle: member.characterStyle,
    preferredCharacter: member.preferredCharacter,
    localTimeFormatted: canSeeCity ? formatTimeInZone(now, member.tz) : null,
    currentPrayer: {
      name: win.name,
      arabic: win.arabic,
      date: win.date,
      startMs: win.start.getTime(),
      endMs: win.end.getTime(),
      startFormatted: canSeeCity ? formatTimeInZone(win.start, member.tz) : null,
      endFormatted: canSeeCity ? formatTimeInZone(win.end, member.tz) : null,
      nextName: win.nextName,
      nextStartFormatted: canSeeCity ? formatTimeInZone(win.nextStart, member.tz) : null,
      prayed: canSeeStatus ? Boolean(log && log[win.name]) : null,
      prayedAtMs: canSeeStatus && log && log[win.name] ? log[win.name] : null,
    },
    prayerLog: canSeeStatus ? log : null,
    todayPrayerLog: canSeeStatus ? todayLog : null,
  };
}

async function buildFullState(store, me, now) {
  const myWin = currentPrayerWindow(me, now);
  const myActiveLog = await store.getPrayerLog(me.uid, myWin.date);
  const myTodayLog =
    myWin.todayDate === myWin.date
      ? myActiveLog
      : await store.getPrayerLog(me.uid, myWin.todayDate);

  const circles = await store.getCirclesForUser(me.uid);
  const memberCache = new Map();
  memberCache.set(me.uid, await serializeMemberView(store, me.uid, me, now));

  const hydratedCircles = [];
  for (const c of circles) {
    const members = [];
    for (const mUid of c.memberUids) {
      if (!memberCache.has(mUid)) {
        const mUser = await store.getUser(mUid);
        if (mUser) {
          memberCache.set(mUid, await serializeMemberView(store, me.uid, mUser, now));
        }
      }
      const mView = memberCache.get(mUid);
      if (mView) members.push(mView);
    }
    hydratedCircles.push({
      circleId: c.circleId,
      name: c.name,
      ownerUid: c.ownerUid,
      inviteCode: c.inviteCode,
      members,
    });
  }

  // Active incoming nudges for my current prayer window (if not yet confirmed)
  const rawNudges = await store.getNudgesForRecipientPrayer(me.uid, myWin.date, myWin.name);
  const visibleNudges = rawNudges.filter((n) => !n.suppressed);
  const senderNames = [];
  const senders = [];
  const seenSenders = new Set();
  for (const n of visibleNudges) {
    if (seenSenders.has(n.fromUid)) continue;
    seenSenders.add(n.fromUid);
    const sUser = await store.getUser(n.fromUid);
    if (sUser) {
      senderNames.push(sUser.displayName);
      senders.push({
        uid: sUser.uid,
        displayName: sUser.displayName,
        characterId: n.characterId || 'teta',
        createdAtMs: n.createdAtMs,
      });
    }
  }

  const pushSubs = await store.getPushSubscriptions(me.uid);

  const todaySched = myWin.todaySchedule;
  const serializeSchedule = (sched) => ({
    Fajr: sched.Fajr.getTime(),
    Sunrise: sched.Sunrise.getTime(),
    Dhuhr: sched.Dhuhr.getTime(),
    Asr: sched.Asr.getTime(),
    Maghrib: sched.Maghrib.getTime(),
    Isha: sched.Isha.getTime(),
  });

  return {
    serverTimeMs: now.getTime(),
    me: {
      uid: me.uid,
      displayName: me.displayName,
      hasPin: Boolean(me.pinHash),
      phone: me.phone || '',
      facetimeId: me.facetimeId || '',
      city: me.city,
      country: me.country,
      lat: me.lat,
      lon: me.lon,
      tz: me.tz,
      method: me.method,
      asrMethod: me.asrMethod,
      highLatitudeRule: me.highLatitudeRule,
      remindOffsetMinutes: me.remindOffsetMinutes,
      shareStatus: me.shareStatus,
      showCity: me.showCity,
      circleReminders: me.circleReminders,
      quietToday: isQuiet(me, now.getTime()),
      quietUntilMs: me.quietUntilMs,
      eveningSummary: me.eveningSummary,
      characterStyle: me.characterStyle,
      preferredCharacter: me.preferredCharacter,
      snoozeAtMs: me.snoozeAtMs,
      snoozePrayerName: me.snoozePrayerName,
      pushEnabled: pushSubs.length > 0,
      currentWindow: {
        name: myWin.name,
        arabic: myWin.arabic,
        date: myWin.date,
        todayDate: myWin.todayDate,
        startMs: myWin.start.getTime(),
        endMs: myWin.end.getTime(),
        startFormatted: formatTimeInZone(myWin.start, me.tz),
        endFormatted: formatTimeInZone(myWin.end, me.tz),
        nextName: myWin.nextName,
        nextStartMs: myWin.nextStart.getTime(),
        nextStartFormatted: formatTimeInZone(myWin.nextStart, me.tz),
      },
      activePrayerLog: myActiveLog,
      todayPrayerLog: myTodayLog,
      todayScheduleMs: serializeSchedule(todaySched),
    },
    circles: hydratedCircles,
    activeNudge:
      senders.length > 0 && !myActiveLog[myWin.name] && !isQuiet(me, now.getTime())
        ? {
            prayer: myWin.name,
            arabic: myWin.arabic,
            date: myWin.date,
            startFormatted: formatTimeInZone(myWin.start, me.tz),
            endFormatted: formatTimeInZone(myWin.end, me.tz),
            senders,
            summaryLine: `${joinNames(senderNames)} ${senderNames.length === 1 ? 'is' : 'are'} thinking of you`,
            latestCharacterId: senders[senders.length - 1].characterId || 'teta',
          }
        : null,
  };
}

async function authenticate(request, store) {
  const authHeader = request.headers.get('Authorization') || '';
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) return null;
  const rawToken = match[1].trim();
  if (!rawToken) return null;
  const tokenHash = await sha256Hex(rawToken);
  const uid = await store.getUidBySession(tokenHash);
  if (!uid) return null;
  const user = await store.getUser(uid);
  return user ? { user, tokenHash } : null;
}

async function parseJson(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

export async function handleApiRequest(request, env, options = {}) {
  const store = options.store || new D1WaqtStore(env.DB);
  const now = options.now ? new Date(options.now) : new Date();
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method.toUpperCase();

  // Public health & VAPID config endpoint
  if (path === '/api/config' && method === 'GET') {
    const vapid = vapidFromEnv(env);
    return jsonResponse({
      ok: true,
      mode: 'live',
      vapidPublicKey: vapid ? vapid.publicKey : null,
      requiresAccessCode: Boolean(env && env.FAMILY_ACCESS_CODE),
    });
  }

  // Register new family member
  if (path === '/api/auth/register' && method === 'POST') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');

    const displayName = String(body.displayName || '').trim().slice(0, 40);
    const city = String(body.city || '').trim().slice(0, 60);
    const country = String(body.country || '').trim().slice(0, 60);
    const lat = Number(body.lat);
    const lon = Number(body.lon);
    const tz = String(body.tz || '').trim();
    const calcMethod = VALID_METHODS.has(body.method) ? body.method : 'MuslimWorldLeague';
    const asrMethod = VALID_ASR.has(body.asrMethod) ? body.asrMethod : 'standard';
    const highLat = VALID_HIGH_LAT.has(body.highLatitudeRule) ? body.highLatitudeRule : 'auto';
    const shareStatus = body.shareStatus !== undefined ? Boolean(body.shareStatus) : true;
    const inviteCode = String(body.inviteCode || '').trim().toUpperCase();
    const accessCode = String(body.accessCode || '').trim();
    const rawPin = String(body.pin || '').trim();

    if (!displayName) return errorResponse('Please enter your name.');
    if (!city || !country) return errorResponse('Please choose your city.');
    if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180) {
      return errorResponse('Invalid city coordinates.');
    }
    if (!validateTimeZone(tz)) {
      return errorResponse('Invalid city IANA time zone.');
    }

    // Optional private family server gate: pass either FAMILY_ACCESS_CODE or a valid circle inviteCode
    let circleToJoin = null;
    if (inviteCode) {
      circleToJoin = await store.getCircleByInviteCode(inviteCode);
      if (!circleToJoin) return errorResponse('That circle invite code was not found.', 404, 'not_found');
      if (circleToJoin.memberUids.length >= MAX_CIRCLE_MEMBERS) {
        return errorResponse('That circle is already full (20 members max).', 409, 'circle_full');
      }
    }
    if (env && env.FAMILY_ACCESS_CODE && !circleToJoin) {
      if (accessCode !== String(env.FAMILY_ACCESS_CODE).trim()) {
        return errorResponse('Enter your family access code or an invite code to join.', 403, 'access_code_required');
      }
    }

    let pinSalt = null;
    let pinHash = null;
    if (rawPin) {
      if (rawPin.length < 4 || rawPin.length > 32) {
        return errorResponse('PIN must be between 4 and 32 characters.');
      }
      pinSalt = randomId('salt');
      pinHash = await sha256Hex(`${pinSalt}:${rawPin}`);
    }

    const uid = randomId('usr');
    const draftUser = {
      uid,
      displayName,
      pinHash,
      pinSalt,
      phone: sanitizeContact(body.phone),
      facetimeId: sanitizeContact(body.facetimeId),
      city,
      country,
      lat,
      lon,
      tz,
      method: calcMethod,
      asrMethod,
      highLatitudeRule: highLat,
      remindOffsetMinutes: 0,
      shareStatus,
      showCity: true,
      circleReminders: true,
      quietUntilMs: null,
      eveningSummary: false,
      lastSummaryDate: null,
      characterStyle: 'characters',
      preferredCharacter: 'teta',
      createdAtMs: now.getTime(),
    };
    const nextFields = computeNextReminderFields(draftUser, now);
    const created = await store.createUser({ ...draftUser, ...nextFields });

    if (circleToJoin) {
      await store.addCircleMember(circleToJoin.circleId, uid, now.getTime());
    } else if (body.createDefaultCircle !== false) {
      const circleName = String(body.circleName || `${displayName}'s Family`).trim().slice(0, 48);
      let code = randomInviteCode(circleName);
      for (let attempt = 0; attempt < 6; attempt += 1) {
        const collision = await store.getCircleByInviteCode(code);
        if (!collision) break;
        code = randomInviteCode(circleName);
      }
      await store.createCircle({
        circleId: randomId('cir'),
        name: circleName,
        ownerUid: uid,
        inviteCode: code,
        createdAtMs: now.getTime(),
      });
    }

    const token = randomToken();
    await store.createSession(await sha256Hex(token), uid, now.getTime());
    const state = await buildFullState(store, created, now);
    return jsonResponse({ ok: true, token, state }, 201);
  }

  // Sign back in with Name + PIN
  if (path === '/api/auth/login' && method === 'POST') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');
    const displayName = String(body.displayName || '').trim();
    const rawPin = String(body.pin || '').trim();
    if (!displayName || !rawPin) {
      return errorResponse('Enter your name and recovery PIN.');
    }
    const candidates = await store.findUsersByName(displayName);
    let matched = null;
    let sawPinlessCandidate = false;
    for (const c of candidates) {
      if (c.pinSalt && c.pinHash) {
        const check = await sha256Hex(`${c.pinSalt}:${rawPin}`);
        if (check === c.pinHash) {
          matched = c;
          break;
        }
      } else {
        sawPinlessCandidate = true;
      }
    }
    if (!matched) {
      if (sawPinlessCandidate && candidates.every((c) => !c.pinHash)) {
        return errorResponse(
          'This profile does not have a recovery PIN set yet. Set a 4-digit PIN in Settings on your original device.',
          401,
          'no_pin_set'
        );
      }
      return errorResponse('Name or PIN did not match.', 401, 'invalid_credentials');
    }
    const token = randomToken();
    await store.createSession(await sha256Hex(token), matched.uid, now.getTime());
    const state = await buildFullState(store, matched, now);
    return jsonResponse({ ok: true, token, state });
  }

  // Authenticated routes below
  const authCtx = await authenticate(request, store);
  if (!authCtx) {
    return errorResponse('Please sign in first.', 401, 'unauthenticated');
  }
  const { user: me, tokenHash } = authCtx;

  if (path === '/api/auth/logout' && method === 'POST') {
    const body = await parseJson(request);
    if (body && body.endpoint) {
      await store.deletePushSubscription(String(body.endpoint));
    }
    await store.deleteSession(tokenHash);
    return jsonResponse({ ok: true });
  }

  if (path === '/api/state' && method === 'GET') {
    const state = await buildFullState(store, me, now);
    return jsonResponse({ ok: true, state });
  }

  if (path === '/api/me' && method === 'PATCH') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');
    const patch = {};

    if (body.displayName !== undefined) {
      const name = String(body.displayName).trim().slice(0, 40);
      if (!name) return errorResponse('Name cannot be empty.');
      patch.displayName = name;
    }
    if (body.city !== undefined && body.country !== undefined) {
      const lat = Number(body.lat);
      const lon = Number(body.lon);
      const tz = String(body.tz || '').trim();
      if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lon) || lon < -180 || lon > 180) {
        return errorResponse('Invalid coordinates.');
      }
      if (!validateTimeZone(tz)) return errorResponse('Invalid IANA time zone.');
      patch.city = String(body.city).trim().slice(0, 60);
      patch.country = String(body.country).trim().slice(0, 60);
      patch.lat = lat;
      patch.lon = lon;
      patch.tz = tz;
    }
    if (body.method !== undefined) {
      if (!VALID_METHODS.has(body.method)) return errorResponse('Unsupported calculation method.');
      patch.method = body.method;
    }
    if (body.asrMethod !== undefined) {
      if (!VALID_ASR.has(body.asrMethod)) return errorResponse('Unsupported Asr method.');
      patch.asrMethod = body.asrMethod;
    }
    if (body.highLatitudeRule !== undefined) {
      if (!VALID_HIGH_LAT.has(body.highLatitudeRule)) return errorResponse('Unsupported high-latitude rule.');
      patch.highLatitudeRule = body.highLatitudeRule;
    }
    if (body.remindOffsetMinutes !== undefined) {
      const off = Number(body.remindOffsetMinutes);
      if (![-1, 0, 5, 10, 15].includes(off)) return errorResponse('Invalid reminder timing.');
      patch.remindOffsetMinutes = off;
    }
    if (body.shareStatus !== undefined) patch.shareStatus = Boolean(body.shareStatus);
    if (body.showCity !== undefined) patch.showCity = Boolean(body.showCity);
    if (body.circleReminders !== undefined) patch.circleReminders = Boolean(body.circleReminders);
    if (body.eveningSummary !== undefined) patch.eveningSummary = Boolean(body.eveningSummary);
    if (body.quietToday !== undefined) {
      const effectiveTz = patch.tz || me.tz;
      patch.quietUntilMs = body.quietToday ? endOfLocalDayUtc(now, effectiveTz).getTime() : null;
    }
    if (body.characterStyle !== undefined) {
      if (!VALID_CHAR_STYLES.has(body.characterStyle)) return errorResponse('Invalid character style.');
      patch.characterStyle = body.characterStyle;
    }
    if (body.preferredCharacter !== undefined) {
      if (!VALID_CHARACTERS.has(body.preferredCharacter)) return errorResponse('Invalid character.');
      patch.preferredCharacter = body.preferredCharacter;
    }
    if (body.phone !== undefined) patch.phone = sanitizeContact(body.phone);
    if (body.facetimeId !== undefined) patch.facetimeId = sanitizeContact(body.facetimeId);
    if (body.pin !== undefined && String(body.pin).trim()) {
      const rawPin = String(body.pin).trim();
      if (rawPin.length < 4 || rawPin.length > 32) {
        return errorResponse('PIN must be 4 to 32 characters.');
      }
      const salt = randomId('salt');
      patch.pinSalt = salt;
      patch.pinHash = await sha256Hex(`${salt}:${rawPin}`);
    }

    const preview = { ...me, ...patch };
    const scheduleChanged = ['lat', 'lon', 'tz', 'method', 'asrMethod', 'highLatitudeRule', 'remindOffsetMinutes'].some(
      (k) => patch[k] !== undefined
    );
    if (scheduleChanged || preview.nextPrayerAtMs === null) {
      Object.assign(patch, computeNextReminderFields(preview, now));
    }

    const updated = await store.updateUser(me.uid, patch);
    const state = await buildFullState(store, updated, now);
    return jsonResponse({ ok: true, state });
  }

  // Confirm (or unconfirm) a prayer
  if (path === '/api/prayers/confirm' && method === 'POST') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');
    const myWin = currentPrayerWindow(me, now);
    const prayerName = body.prayer ? String(body.prayer) : myWin.name;
    if (!PRAYERS.includes(prayerName)) return errorResponse('Invalid prayer name.');

    // Default to the owning date of the active prayer window (fixes after-midnight Isha belonging to yesterday!)
    const targetDate =
      body.date && /^\d{4}-\d{2}-\d{2}$/.test(String(body.date))
        ? String(body.date)
        : prayerName === myWin.name
        ? myWin.date
        : myWin.todayDate;

    const beforeLog = await store.getPrayerLog(me.uid, targetDate);
    const alreadyPrayed = Boolean(beforeLog[prayerName]);

    if (body.unconfirm === true || body.undo === true) {
      await store.removePrayerConfirmed(me.uid, targetDate, prayerName);
    } else {
      await store.setPrayerConfirmed(me.uid, targetDate, prayerName, now.getTime());
      if (me.snoozePrayerName === prayerName) {
        await store.updateUser(me.uid, { snoozePrayerName: null, snoozeAtMs: null });
      }
      // Notify family members who nudged me for this prayer ONLY if I share status and wasn't already confirmed
      if (!alreadyPrayed && me.shareStatus === true) {
        const nudges = await store.getNudgesForRecipientPrayer(me.uid, targetDate, prayerName);
        const senderUids = [...new Set(nudges.map((n) => n.fromUid))];
        await Promise.all(
          senderUids.map(async (senderUid) => {
            const nudgeRow = nudges.find((n) => n.fromUid === senderUid);
            await store.createMessage({
              messageId: randomId('msg'),
              circleId: nudgeRow ? nudgeRow.circleId : 'circle',
              fromUid: me.uid,
              toUid: senderUid,
              kind: 'confirmed',
              prayer: prayerName,
              body: `${me.displayName} prayed ${prayerName}`,
              createdAtMs: now.getTime(),
            });
            const sender = await store.getUser(senderUid);
            if (sender && !isQuiet(sender, now.getTime())) {
              await pushToUser(
                store,
                env,
                senderUid,
                {
                  type: 'confirmed',
                  title: 'Waqt',
                  body: `${me.displayName} prayed ${prayerName}.`,
                  tag: `confirmed-${me.uid}-${prayerName}-${targetDate}`,
                  url: `/?screen=chat&peer=${encodeURIComponent(me.uid)}`,
                },
                fetchImpl
              );
            }
          })
        );
      }
    }

    const refreshedMe = await store.getUser(me.uid);
    const state = await buildFullState(store, refreshedMe, now);
    return jsonResponse({ ok: true, state });
  }

  // Snooze reminder for 15 minutes
  if (path === '/api/prayers/snooze' && method === 'POST') {
    const body = (await parseJson(request)) || {};
    const myWin = currentPrayerWindow(me, now);
    const prayerName = PRAYERS.includes(body.prayer) ? body.prayer : myWin.name;
    const minutes = Math.min(60, Math.max(5, Number(body.minutes || 15)));
    const snoozeAtMs = now.getTime() + minutes * 60000;
    const updated = await store.updateUser(me.uid, {
      snoozePrayerName: prayerName,
      snoozeAtMs,
    });
    const state = await buildFullState(store, updated, now);
    return jsonResponse({ ok: true, snoozeAtMs, state });
  }

  // Circles: create, join, leave, remove-member
  if (path === '/api/circles/create' && method === 'POST') {
    const body = await parseJson(request);
    const name = String((body && body.name) || '').trim().slice(0, 40);
    if (!name) return errorResponse('Give your circle a name (e.g. Family).');

    let inviteCode = null;
    for (let i = 0; i < 8 && !inviteCode; i += 1) {
      const candidate = randomInviteCode(name);
      const clash = await store.getCircleByInviteCode(candidate);
      if (!clash) inviteCode = candidate;
    }
    if (!inviteCode) return errorResponse('Could not generate a unique invite code.', 500);

    const circleId = randomId('cir');
    await store.createCircle({
      circleId,
      name,
      ownerUid: me.uid,
      inviteCode,
      createdAtMs: now.getTime(),
    });
    const state = await buildFullState(store, me, now);
    return jsonResponse({ ok: true, circleId, inviteCode, state }, 201);
  }

  if (path === '/api/circles/join' && method === 'POST') {
    const body = await parseJson(request);
    const code = String((body && body.inviteCode) || '').trim().toUpperCase();
    if (!code) return errorResponse('Enter an invite code.');
    const circle = await store.getCircleByInviteCode(code);
    if (!circle) return errorResponse('That invite code was not found.', 404, 'not_found');
    if (!circle.memberUids.includes(me.uid)) {
      if (circle.memberUids.length >= MAX_CIRCLE_MEMBERS) {
        return errorResponse('This circle is full (20 members max).', 409, 'circle_full');
      }
      await store.addCircleMember(circle.circleId, me.uid, now.getTime());
    }
    const state = await buildFullState(store, me, now);
    return jsonResponse({ ok: true, circleId: circle.circleId, state });
  }

  if (path === '/api/circles/leave' && method === 'POST') {
    const body = await parseJson(request);
    const circleId = String((body && body.circleId) || '').trim();
    if (!circleId) return errorResponse('Missing circleId.');
    await store.removeCircleMember(circleId, me.uid);
    const state = await buildFullState(store, me, now);
    return jsonResponse({ ok: true, state });
  }

  if (path === '/api/circles/remove-member' && method === 'POST') {
    const body = await parseJson(request);
    const circleId = String((body && body.circleId) || '').trim();
    const memberUid = String((body && body.memberUid) || '').trim();
    if (!circleId || !memberUid) return errorResponse('Missing circle or member.');
    const circle = await store.getCircle(circleId);
    if (!circle) return errorResponse('Circle not found.', 404);
    if (circle.ownerUid !== me.uid) return errorResponse('Only the circle admin can remove members.', 403);
    if (memberUid === me.uid) return errorResponse('Use Leave circle instead.');
    await store.removeCircleMember(circleId, memberUid);
    const state = await buildFullState(store, me, now);
    return jsonResponse({ ok: true, state });
  }

  // Send a gentle cross-circle nudge
  if (path === '/api/nudges' && method === 'POST') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');
    const toUid = String(body.toUid || '').trim();
    const circleId = String(body.circleId || '').trim();
    const characterId = VALID_CHARACTERS.has(body.characterId)
      ? body.characterId
      : me.preferredCharacter || 'teta';

    if (!toUid || toUid === me.uid) return errorResponse('Choose a circle member to remind.');
    const shared = await store.sharesCircle(me.uid, toUid);
    if (!shared) return errorResponse('You can only remind members of your circle.', 403, 'forbidden');

    const recipient = await store.getUser(toUid);
    if (!recipient) return errorResponse('Member not found.', 404);

    // Always evaluate recipient's current prayer in THEIR time zone!
    const recipientWin = currentPrayerWindow(recipient, now);
    const recipientLog = await store.getPrayerLog(toUid, recipientWin.date);
    const recipientAlreadyPrayed = Boolean(recipientLog && recipientLog[recipientWin.name]);
    if (recipientAlreadyPrayed && recipient.shareStatus === true) {
      return errorResponse(
        `${recipient.displayName} has already prayed ${recipientWin.name}, alhamdulillah.`,
        409,
        'already_prayed'
      );
    }

    const nudgeId = `${toUid}_${recipientWin.date}_${recipientWin.name}_${me.uid}`;
    const suppressed =
      recipientAlreadyPrayed ||
      isQuiet(recipient, now.getTime()) ||
      recipient.circleReminders === false;

    const result = await store.createNudge({
      nudgeId,
      fromUid: me.uid,
      toUid,
      circleId: circleId || 'circle',
      prayer: recipientWin.name,
      localDate: recipientWin.date,
      characterId,
      createdAtMs: now.getTime(),
      deliveredAtMs: suppressed ? null : now.getTime(),
      suppressed,
    });

    if (result.duplicate) {
      return errorResponse(
        `You already sent a gentle reminder to ${recipient.displayName} for ${recipientWin.name}.`,
        409,
        'already_nudged'
      );
    }

    // Record nudge event in their 1:1 chat stream
    await store.createMessage({
      messageId: randomId('msg'),
      circleId: circleId || 'circle',
      fromUid: me.uid,
      toUid,
      kind: 'nudge',
      prayer: recipientWin.name,
      body: `Sent a reminder for ${recipientWin.name}`,
      createdAtMs: now.getTime(),
    });

    // Send grouped Web Push only if not suppressed (quiet mode & private already-prayed are invisible to the sender!)
    if (!suppressed) {
      const siblings = await store.getNudgesForRecipientPrayer(toUid, recipientWin.date, recipientWin.name);
      const activeSiblings = siblings.filter((s) => !s.suppressed);
      const senderIds = [...new Set(activeSiblings.map((s) => s.fromUid))];
      const senderUsers = await Promise.all(senderIds.map((id) => store.getUser(id)));
      const names = senderUsers.filter(Boolean).map((u) => u.displayName);

      let pushBody = `${joinNames(names)} ${names.length === 1 ? 'is' : 'are'} thinking of you for ${recipientWin.name}. Pray when you're ready.`;
      if (recipient.characterStyle === 'characters' && CHARACTER_LINES[characterId]) {
        const line = CHARACTER_LINES[characterId].line.replace('{prayer}', recipientWin.name);
        pushBody = `${joinNames(names)} ${names.length === 1 ? 'is' : 'are'} thinking of you for ${recipientWin.name} — "${line}"`;
      }

      await pushToUser(
        store,
        env,
        toUid,
        {
          type: 'nudge',
          title: 'Waqt',
          body: pushBody,
          prayer: recipientWin.name,
          date: recipientWin.date,
          tag: `nudge-${recipientWin.name}-${recipientWin.date}`,
          url: `/?screen=reminder&prayer=${encodeURIComponent(recipientWin.name)}`,
        },
        fetchImpl
      );
    }

    const state = await buildFullState(store, me, now);
    return jsonResponse({
      ok: true,
      sent: true,
      prayer: recipientWin.name,
      recipientName: recipient.displayName,
      state,
    });
  }

  // 1:1 Family Chat
  if (path === '/api/messages' && method === 'GET') {
    const peerUid = String(url.searchParams.get('peerUid') || '').trim();
    if (!peerUid) return errorResponse('Missing peerUid.');
    const shared = await store.sharesCircle(me.uid, peerUid);
    if (!shared) return errorResponse('Not in the same circle.', 403);
    const messages = await store.getMessagesBetween(me.uid, peerUid, 80);
    return jsonResponse({ ok: true, messages });
  }

  if (path === '/api/messages' && method === 'POST') {
    const body = await parseJson(request);
    if (!body) return errorResponse('Invalid JSON payload.');
    const toUid = String(body.toUid || '').trim();
    const circleId = String(body.circleId || 'circle').trim();
    const text = String(body.body || '').trim().slice(0, 600);
    if (!toUid || toUid === me.uid) return errorResponse('Missing recipient.');
    if (!text) return errorResponse('Write a message first.');

    const shared = await store.sharesCircle(me.uid, toUid);
    if (!shared) return errorResponse('You can only message circle members.', 403);

    const recipient = await store.getUser(toUid);
    if (!recipient) return errorResponse('Recipient not found.', 404);

    const msg = {
      messageId: randomId('msg'),
      circleId,
      fromUid: me.uid,
      toUid,
      kind: 'text',
      prayer: null,
      body: text,
      createdAtMs: now.getTime(),
    };
    await store.createMessage(msg);

    if (!isQuiet(recipient, now.getTime())) {
      await pushToUser(
        store,
        env,
        toUid,
        {
          type: 'chat',
          title: me.displayName,
          body: text.slice(0, 140),
          tag: `chat-${me.uid}`,
          url: `/?screen=chat&peer=${encodeURIComponent(me.uid)}`,
        },
        fetchImpl
      );
    }

    const messages = await store.getMessagesBetween(me.uid, toUid, 80);
    return jsonResponse({ ok: true, message: msg, messages }, 201);
  }

  // Web Push Subscriptions
  if (path === '/api/push/subscribe' && method === 'POST') {
    const body = await parseJson(request);
    const sub = body && body.subscription;
    if (!sub || !sub.endpoint || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) {
      return errorResponse('Invalid PushSubscription object.');
    }
    await store.upsertPushSubscription({
      endpoint: String(sub.endpoint),
      uid: me.uid,
      p256dh: String(sub.keys.p256dh),
      auth: String(sub.keys.auth),
      userAgent: request.headers.get('User-Agent') || '',
      createdAtMs: now.getTime(),
    });
    return jsonResponse({ ok: true });
  }

  if (path === '/api/push/unsubscribe' && method === 'POST') {
    const body = await parseJson(request);
    if (body && body.endpoint) {
      await store.deletePushSubscription(String(body.endpoint));
    }
    return jsonResponse({ ok: true });
  }

  if (path === '/api/push/test' && method === 'POST') {
    const myWin = currentPrayerWindow(me, now);
    const res = await pushToUser(
      store,
      env,
      me.uid,
      {
        type: 'own',
        title: 'Waqt',
        body: `Assalamu alaikum ${me.displayName} — lock-screen reminders are active for ${myWin.name}.`,
        prayer: myWin.name,
        date: myWin.date,
        tag: `test-${me.uid}`,
        url: '/',
      },
      fetchImpl
    );
    return jsonResponse({ ok: true, ...res });
  }

  return errorResponse('API route not found.', 404, 'not_found');
}

// Per-minute Cron Scheduler: own prayer reminders, 15m snoozes, and opt-in evening family summary.
export async function runPrayerCron(env, options = {}) {
  const store = options.store || new D1WaqtStore(env.DB);
  const now = options.now ? new Date(options.now) : new Date();
  const nowMs = now.getTime();
  const fetchImpl = options.fetchImpl || globalThis.fetch;

  let ownSent = 0;
  let snoozeSent = 0;
  let summariesSent = 0;

  // 1. Due personal prayer reminders
  const dueUsers = await store.getDuePrayerUsers(nowMs);
  await Promise.all(
    dueUsers.map(async (user) => {
      if (user.nextPrayerAtMs === null || !user.nextPrayerName) {
        await store.updateUser(user.uid, computeNextReminderFields(user, now));
        return;
      }
      const dueAtMs = user.nextPrayerAtMs;
      const prayerName = user.nextPrayerName;
      const prayerDate = user.nextPrayerDate || localDateString(new Date(dueAtMs), user.tz);
      const lateMs = nowMs - dueAtMs;

      if (lateMs <= MAX_PUSH_DELAY_MS && !isQuiet(user, nowMs) && user.remindOffsetMinutes >= 0) {
        const log = await store.getPrayerLog(user.uid, prayerDate);
        if (!log[prayerName]) {
          const lead = Number(user.remindOffsetMinutes || 0);
          const body =
            lead > 0
              ? `${prayerName} is in ${lead} minutes.`
              : prayerName === 'Fajr' && user.characterStyle === 'characters'
              ? `It's time for Fajr — "${CHARACTER_LINES['little-noor'].line}"`
              : `It's time for ${prayerName}.`;

          const res = await pushToUser(
            store,
            env,
            user.uid,
            {
              type: 'own',
              title: 'Waqt',
              body,
              prayer: prayerName,
              date: prayerDate,
              tag: `own-${prayerName}-${prayerDate}`,
              url: '/',
            },
            fetchImpl
          );
          ownSent += res.sent;
        }
      }

      // Advance cursor past dueAtMs (and at least now) so we never double-fire the same prayer
      const cursor = new Date(Math.max(nowMs, dueAtMs + 60000));
      const nextFields = computeNextReminderFields(user, cursor);
      await store.updateUser(user.uid, nextFields);
    })
  );

  // 2. Due 15-minute snoozed reminders
  const snoozeUsers = await store.getDueSnoozeUsers(nowMs);
  await Promise.all(
    snoozeUsers.map(async (user) => {
      const prayerName = user.snoozePrayerName;
      const snoozeAtMs = user.snoozeAtMs;
      await store.updateUser(user.uid, { snoozePrayerName: null, snoozeAtMs: null });
      if (!prayerName || nowMs - snoozeAtMs > MAX_PUSH_DELAY_MS || isQuiet(user, nowMs)) return;

      const win = currentPrayerWindow(user, now);
      if (win.name !== prayerName) return;
      const log = await store.getPrayerLog(user.uid, win.date);
      if (log[prayerName]) return;

      const res = await pushToUser(
        store,
        env,
        user.uid,
        {
          type: 'own',
          title: 'Waqt',
          body: `Gentle 15-minute check-in for ${prayerName}. Pray when you're ready.`,
          prayer: prayerName,
          date: win.date,
          tag: `own-${prayerName}-${win.date}`,
          url: '/',
        },
        fetchImpl
      );
      snoozeSent += res.sent;
    })
  );

  // 3. Opt-in Evening Family Summary (~45 minutes after Maghrib in user's local time, once per day)
  const summaryUsers = await store.getEveningSummaryUsers();
  await Promise.all(
    summaryUsers.map(async (user) => {
      if (isQuiet(user, nowMs)) return;
      const localDay = localDateString(now, user.tz);
      if (user.lastSummaryDate === localDay) return;

      const sched = timesForDate(user, localDay);
      const summaryTriggerMs = sched.Maghrib.getTime() + 45 * 60000;
      if (nowMs < summaryTriggerMs || nowMs > summaryTriggerMs + 15 * 60000) return;

      await store.updateUser(user.uid, { lastSummaryDate: localDay });

      const circles = await store.getCirclesForUser(user.uid);
      if (circles.length === 0) return;
      const primary = circles[0];
      let sharingTotal = 0;
      let prayedCount = 0;
      for (const mUid of primary.memberUids) {
        const m = await store.getUser(mUid);
        if (!m || !m.shareStatus) continue;
        sharingTotal += 1;
        const mDay = localDateString(now, m.tz);
        const mLog = await store.getPrayerLog(mUid, mDay);
        if (mLog.Maghrib) prayedCount += 1;
      }
      if (sharingTotal > 0 && prayedCount > 0) {
        const res = await pushToUser(
          store,
          env,
          user.uid,
          {
            type: 'summary',
            title: `Waqt · ${primary.name}`,
            body: `Today: ${prayedCount} of ${sharingTotal} prayed Maghrib together, alhamdulillah.`,
            tag: `summary-${localDay}`,
            url: '/?screen=circle',
          },
          fetchImpl
        );
        summariesSent += res.sent;
      }
    })
  );

  return { ownSent, snoozeSent, summariesSent };
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      return handleApiRequest(request, env);
    }
    if (env && env.ASSETS) {
      return env.ASSETS.fetch(request);
    }
    return new Response('Waqt Worker API is running.', { status: 200 });
  },

  async scheduled(controller, env, ctx) {
    const work = runPrayerCron(env);
    if (ctx && typeof ctx.waitUntil === 'function') {
      ctx.waitUntil(work);
    } else {
      await work;
    }
  },
};
