# Waqt (وقت) — Family Prayer-Reminder PWA
### Option A: 100% Card-Free Stack ($0 Forever · Zero Credit Card Required)

**Waqt** is a warm, guilt-free family prayer-reminder PWA built around your exact 8 emerald & gold screens (`Welcome`, `Main`, `NudgeSheet`, `Reminder`, `Circle`, `Chat`, `Characters`, and `Settings`). It lets your family across Abu Dhabi, Dublin, Cairo, Toronto, London, or any of **126 world cities** gently remind one another to pray in each person's **own local prayer window**, confirm prayers with a single tap, and check in via **1-tap WhatsApp or FaceTime**.

---

## Why Option A Uses Cloudflare Free Plan + Native VAPID Web Push (Instead of Firebase Blaze)

In the original starter handoff, scheduled prayer push notifications used Firebase Cloud Functions (`onSchedule("every 1 minutes")`), which **requires upgrading to the Firebase Blaze billing plan and entering a credit card**.

To guarantee **$0 forever with zero credit card**, this build runs on **Cloudflare's Free Tier** with **zero runtime npm dependencies**:
1. **Cloudflare Workers Static Assets** — Hosts the installable PWA (`public/`) over HTTPS on a global `*.workers.dev` URL for free.
2. **Cloudflare D1 (Serverless SQLite)** — Stores users, family circles, prayer confirmations, rate-limited nudges, 1:1 messages, and push subscriptions (5 GB free, 5M reads/day, no card required).
3. **Cloudflare Cron Triggers (`* * * * *`)** — Runs `runPrayerCron()` every minute on the Free Plan (no card required!) to deliver each family member's personal prayer reminders, 15-minute snoozes, and opt-in evening family summaries.
4. **Standards-Based VAPID Web Push (RFC 8292 + `aes128gcm` RFC 8291)** — Implemented directly on Web Crypto (`worker/webpush.mjs`), delivering native lock-screen notifications to **iPhone iOS 16.4+ (Home Screen Web App)**, **Android Chrome**, and **Desktop browsers** with interactive **`✓ I prayed`** and **`Remind in 15m`** lock-screen buttons.

---

## What Was Completed & Verified Beyond the Handoff Prototype

- **All 8 Emerald & Gold Screens Wired End-to-End**:
  1. `Welcome` — Onboarding + returning-member PIN restore + optional circle code join (`?join=` deep-link auto-fill) + browser geolocation nearest-city match + 1-tap `Preview the Al-Mansoor Family Circle →`.
  2. `Home (Main)` — Live SVG progress ring (`r=92`, gold `#D4B46A`), Arabic calligraphy, local prayer countdown, **5-prayer pill strip with exact local times**, tap-to-open **Today's Full Prayer Schedule sheet (`Fajr`, `Sunrise / Shuruq`, `Dhuhr`, `Asr`, `Maghrib`, `Isha`)**, `I prayed` / `Prayed · tap to undo` confirmation toggle, smart-rotating cross-circle nudge card (`alreadyNudgedByMe`), and horizontal family circle strip.
  3. `Nudge Sheet` — Cross-timezone prayer translation (*"In Dublin it's Dhuhr · 1:15 PM — 1h 32m left"*), character selector (*Teta, Jiddo, Sami, Little Noor, Hilal, Fanous*), 1-per-prayer-per-day rate limit, automatic `already_prayed` protection (with silent suppression for private status), and 1-tap call check-in shortcut.
  4. `Reminder Received` — Full-screen emerald arrival overlay with character artwork, grouped sender stack, **`I prayed`**, **`Remind me in 15 minutes`**, and **`Quiet mode for today`**.
  5. `Family Circle` — Multi-circle switcher (`+ New circle` & `Join code`), `Invite` share/copy card + WhatsApp invite link + **100% offline on-device SVG QR Code modal (`shared/qr-svg.mjs`)**, cross-timezone-aware `"X/Y"` togetherness card, admin member management (`Remove from circle`), and per-member **Nudge / Message / Video call** sheet.
  6. `1:1 Family Chat` — Warm parchment chat bubbles, gold inline nudge & confirmation cards, quick-reply chips (*Alhamdulillah, JazakAllah khair, Praying now, Make dua for me, Aameen*), and header **Call** button.
  7. `Characters & Symbols` — Segmented switcher (`Characters` / `Moon & lantern` / `Off`) + interactive preview of all 6 companions.
  8. `Settings` — Location picker (126 cities + GPS), 12 regional calculation presets + Hanafi/Shafi'i Asr + high-latitude rules (`Automatic`, `Middle of the Night`, `One-Seventh`, `Twilight Angle`), lead-time selector (`At prayer time`, `5/10/15m before`, `Off`), `Lock-screen push` toggle + live test push, `WhatsApp, FaceTime & PIN`, and all 5 privacy/notification switches (`Share when I've prayed`, `Show my city` with full timezone/clock-time redaction, `Reminders from my circle`, `Quiet mode today`, `Evening family summary`).
- **Offline Live-State Caching & Solar Recalculation**:
  - Signed-in family members opening Waqt while offline keep their authenticated profile and last synced family circle state (`waqt_last_live_state_v1`), with live client-side astronomical recalculation of prayer windows and automatic background resync when connectivity returns.
- **1-Tap WhatsApp & FaceTime Check-In Sheet**:
  - Tap any family member -> **`Video call`** (or the video icon in the **Chat** header) to launch a **1-tap WhatsApp pre-filled greeting** (`https://wa.me/...`), **FaceTime Video** (`facetime://`), **FaceTime Audio** (`facetime-audio://`), or **Phone Call** (`tel:`).
- **126 Cities Enriched with Verified IANA Time Zones**:
  - Every city in `public/cities.json` and `data/cities.json` now includes a verified IANA `tz` identifier (including multi-zone countries like `America/Phoenix` no-DST, `America/Edmonton`, `America/Toronto`, `America/Vancouver`, `Asia/Hong_Kong`, `Australia/Perth`, `Australia/Sydney`).
- **Zero-Dependency Astronomical Prayer Engine (`shared/prayer-engine.mjs`)**:
  - Jean Meeus solar coordinates, all 12 calculation presets (including Umm al-Qura automatic 120-min Ramadan Isha via `islamic-umalqura` Hijri calendar and Moonsighting Committee seasonal twilight), Standard & Hanafi Asr, 3 high-latitude rules (`middleOfTheNight`, `seventhOfTheNight`, `twilightAngle` with midnight rollover collision guard), and a 3-day `[yesterday, today, tomorrow]` timeline so after-midnight Isha before Fajr attributes confirmations to the right night.

---

## Quick Local Preview (30 Seconds)

With Node 18+ installed, run the full app + live API + pre-seeded Al-Mansoor family circle locally:

```bash
node scripts/local-dev-server.mjs --seed
```

Then open **`http://127.0.0.1:8787`** in your browser!
- Enter your name, pick your city, and enter invite code **`FAM-4821`** on Welcome to join Mama (Abu Dhabi), Ahmed (Dublin), Teta (Cairo), Khalid (Toronto), and Layla (London) — or sign in directly as `Mama`, `Ahmed`, `Teta`, `Khalid`, or `Layla` using recovery PIN **`2468`**.
- Or tap **`Preview the Al-Mansoor Family Circle →`** on Welcome to explore the interactive family demo and switch perspectives across all 6 time zones using the **`View as:`** selector in the top banner.

## Running Verification & Automated Tests

```bash
# Verify astronomical prayer schedules across 11 cities & 12 solstice/DST/Ramadan dates
node scripts/verify-prayers.mjs

# Run the full automated test suite (cities, astronomy, VAPID/RFC 8291 crypto, API, privacy, SQLite D1, HTTP E2E)
node tests/waqt.test.mjs
```

## Deploying Free Forever for Your Family

See **[`SETUP_GUIDE.md`](./SETUP_GUIDE.md)** for the complete 10-minute step-by-step guide (no credit card required).
