#!/usr/bin/env node
// Zero-dependency local HTTP + API + Cron dev server for Waqt.
// Runs the exact Cloudflare Worker API (`worker/index.mjs`) + `MemoryWaqtStore` + static `public/` assets,
// so you can test multi-device onboarding, PIN login, nudges, chat, and Web Push on localhost before deploying.
//
// Usage:
//   node scripts/local-dev-server.mjs --seed       (pre-seeds Al-Mansoor Family circle: invite code FAM-4821)
//   node scripts/local-dev-server.mjs --port 8787  (clean database)

import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleApiRequest, runPrayerCron } from '../worker/index.mjs';
import { MemoryWaqtStore } from '../worker/store-memory.mjs';
import { generateVapidKeys } from '../worker/webpush.mjs';
import { currentPrayerWindow, nextReminderSchedule } from '../shared/prayer-engine.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.resolve(__dirname, '../public');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

export async function seedMemoryFamily(store, now = new Date()) {
  const nowMs = now.getTime();
  const defaultSalt = 'salt_seed_family';
  const defaultPinHash = crypto
    .createHash('sha256')
    .update(`${defaultSalt}:2468`)
    .digest('hex');

  const members = [
    {
      uid: 'uid_mama',
      displayName: 'Mama',
      phone: '+971509876543',
      facetimeId: '+971509876543',
      city: 'Abu Dhabi',
      country: 'UAE',
      lat: 24.4539,
      lon: 54.3773,
      tz: 'Asia/Dubai',
      method: 'Dubai',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 0,
      shareStatus: true,
      showCity: true,
      circleReminders: true,
      eveningSummary: true,
      characterStyle: 'characters',
      preferredCharacter: 'teta',
    },
    {
      uid: 'uid_ahmed',
      displayName: 'Ahmed',
      phone: '+353871234567',
      facetimeId: '+353871234567',
      city: 'Dublin',
      country: 'Ireland',
      lat: 53.3498,
      lon: -6.2603,
      tz: 'Europe/Dublin',
      method: 'MuslimWorldLeague',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 10,
      shareStatus: true,
      showCity: true,
      circleReminders: true,
      eveningSummary: false,
      characterStyle: 'characters',
      preferredCharacter: 'sami',
    },
    {
      uid: 'uid_teta',
      displayName: 'Teta',
      phone: '+201001234567',
      facetimeId: '',
      city: 'Cairo',
      country: 'Egypt',
      lat: 30.0444,
      lon: 31.2357,
      tz: 'Africa/Cairo',
      method: 'Egyptian',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 0,
      shareStatus: true,
      showCity: true,
      circleReminders: true,
      eveningSummary: true,
      characterStyle: 'characters',
      preferredCharacter: 'teta',
    },
    {
      uid: 'uid_khalid',
      displayName: 'Khalid',
      phone: '+14165550199',
      facetimeId: 'khalid@example.com',
      city: 'Toronto',
      country: 'Canada',
      lat: 43.6532,
      lon: -79.3832,
      tz: 'America/Toronto',
      method: 'NorthAmerica',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 5,
      shareStatus: true,
      showCity: true,
      circleReminders: true,
      eveningSummary: false,
      characterStyle: 'symbols',
      preferredCharacter: 'hilal',
    },
    {
      uid: 'uid_layla',
      displayName: 'Layla',
      phone: '+447700900123',
      facetimeId: '+447700900123',
      city: 'London',
      country: 'UK',
      lat: 51.5074,
      lon: -0.1278,
      tz: 'Europe/London',
      method: 'MuslimWorldLeague',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 0,
      shareStatus: false, // Private mode demo
      showCity: true,
      circleReminders: true,
      eveningSummary: false,
      characterStyle: 'symbols',
      preferredCharacter: 'fanous',
    },
  ];

  for (let i = 0; i < members.length; i += 1) {
    const m = members[i];
    const nextRem = nextReminderSchedule(m, now);
    await store.createUser({
      ...m,
      pinHash: defaultPinHash,
      pinSalt: defaultSalt,
      quietUntilMs: null,
      lastSummaryDate: null,
      nextPrayerName: nextRem ? nextRem.name : null,
      nextPrayerAtMs: nextRem ? nextRem.at.getTime() : null,
      nextPrayerDate: nextRem ? nextRem.date : null,
      snoozePrayerName: null,
      snoozeAtMs: null,
      createdAtMs: nowMs + i * 1000,
    });
  }

  await store.createCircle({
    circleId: 'cir_almansoor',
    name: 'Al-Mansoor Family',
    ownerUid: 'uid_mama',
    inviteCode: 'FAM-4821',
    createdAtMs: nowMs,
  });

  for (let i = 1; i < members.length; i += 1) {
    await store.addCircleMember('cir_almansoor', members[i].uid, nowMs + i * 1000);
  }

  // Mark Mama and Teta as having prayed their current prayer window
  for (const uid of ['uid_mama', 'uid_teta']) {
    const u = await store.getUser(uid);
    const win = currentPrayerWindow(u, now);
    await store.setPrayerConfirmed(uid, win.date, win.name, nowMs - 10 * 60000);
  }

  // Seed a warm reminder from Mama to Ahmed for Ahmed's current prayer window + 1:1 chat history
  const ahmed = await store.getUser('uid_ahmed');
  const ahmedWin = currentPrayerWindow(ahmed, now);
  await store.createNudge({
    nudgeId: `uid_ahmed_${ahmedWin.date}_${ahmedWin.name}_uid_mama`,
    fromUid: 'uid_mama',
    toUid: 'uid_ahmed',
    circleId: 'cir_almansoor',
    prayer: ahmedWin.name,
    localDate: ahmedWin.date,
    characterId: 'teta',
    createdAtMs: nowMs - 14 * 60000,
    deliveredAtMs: nowMs - 14 * 60000,
    suppressed: false,
  });

  await store.createMessage({
    messageId: 'msg_seed_1',
    circleId: 'cir_almansoor',
    fromUid: 'uid_mama',
    toUid: 'uid_ahmed',
    kind: 'nudge',
    prayer: ahmedWin.name,
    body: `Sent a reminder for ${ahmedWin.name}`,
    createdAtMs: nowMs - 14 * 60000,
  });
  await store.createMessage({
    messageId: 'msg_seed_2',
    circleId: 'cir_almansoor',
    fromUid: 'uid_mama',
    toUid: 'uid_ahmed',
    kind: 'text',
    prayer: null,
    body: 'Habibi, how was your exam today? Take a quiet break for prayer when you finish.',
    createdAtMs: nowMs - 12 * 60000,
  });
}

export async function startLocalServer(options = {}) {
  const port = options.port ?? 8787;
  const host = options.host || '127.0.0.1';
  const store = options.store || new MemoryWaqtStore();
  const keys = options.vapidKeys || (await generateVapidKeys());

  const env = {
    VAPID_PUBLIC_KEY: process.env.VAPID_PUBLIC_KEY || keys.publicKey,
    VAPID_PRIVATE_KEY: process.env.VAPID_PRIVATE_KEY || keys.privateKey,
    VAPID_SUBJECT: process.env.VAPID_SUBJECT || 'mailto:family@waqt.app',
    FAMILY_ACCESS_CODE: process.env.FAMILY_ACCESS_CODE || '',
    ...(options.env || {}),
  };

  if (options.seed) {
    await seedMemoryFamily(store);
  }

  const server = http.createServer(async (req, res) => {
    try {
      const origin = `http://${req.headers.host || `${host}:${port}`}`;
      const reqUrl = new URL(req.url || '/', origin);

      if (options.disableKeepAlive) {
        res.setHeader('Connection', 'close');
      }

      if (reqUrl.pathname.startsWith('/api/')) {
        const chunks = [];
        for await (const chunk of req) chunks.push(chunk);
        const bodyBuf = Buffer.concat(chunks);

        const webReq = new Request(reqUrl.toString(), {
          method: req.method || 'GET',
          headers: req.headers,
          body: ['GET', 'HEAD'].includes((req.method || 'GET').toUpperCase())
            ? undefined
            : bodyBuf,
        });

        const webRes = await handleApiRequest(webReq, env, {
          store,
          fetchImpl: options.fetchImpl,
        });

        res.statusCode = webRes.status;
        webRes.headers.forEach((val, key) => res.setHeader(key, val));
        const outBuf = Buffer.from(await webRes.arrayBuffer());
        res.end(outBuf);
        return;
      }

      // Static file from public/
      let relPath = decodeURIComponent(reqUrl.pathname);
      if (relPath === '/') relPath = '/index.html';
      const safePath = path.normalize(relPath).replace(/^(\.\.(\/|\\|$))+/, '');
      let filePath = path.join(PUBLIC_DIR, safePath);

      let stat = await fs.stat(filePath).catch(() => null);
      if (!stat || stat.isDirectory()) {
        // SPA fallback for deep-links
        filePath = path.join(PUBLIC_DIR, 'index.html');
        stat = await fs.stat(filePath);
      }

      const ext = path.extname(filePath).toLowerCase();
      res.statusCode = 200;
      res.setHeader('Content-Type', MIME_TYPES[ext] || 'application/octet-stream');
      res.setHeader('Cache-Control', 'no-cache');
      const data = await fs.readFile(filePath);
      res.end(data);
    } catch (err) {
      res.statusCode = 500;
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.end(JSON.stringify({ ok: false, error: err.message }));
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, resolve);
  });

  const cronTimer =
    options.enableCron !== false
      ? setInterval(() => {
          runPrayerCron(env, { store, fetchImpl: options.fetchImpl }).catch(() => {});
        }, 60000)
      : null;
  if (cronTimer && cronTimer.unref) cronTimer.unref();

  const address = server.address();
  const actualPort = typeof address === 'object' && address ? address.port : port;

  return {
    server,
    store,
    env,
    port: actualPort,
    url: `http://${host}:${actualPort}`,
    close: () =>
      new Promise((resolve) => {
        if (cronTimer) clearInterval(cronTimer);
        if (typeof server.closeAllConnections === 'function') {
          server.closeAllConnections();
        }
        server.close(() => resolve());
      }),
  };
}

// Run directly when executed from CLI
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const seed = args.includes('--seed');
  const portIdx = args.indexOf('--port');
  const port = portIdx >= 0 ? Number(args[portIdx + 1]) : Number(process.env.PORT || 8787);

  startLocalServer({ port, seed }).then((instance) => {
    console.log('\n🌙 Waqt Local Family Server is running!');
    console.log(`   URL:         ${instance.url}`);
    if (seed) {
      console.log('   Seed Circle: Al-Mansoor Family (Invite Code: FAM-4821)');
      console.log('   Tip:         Enter your name, pick your city, and join code FAM-4821 on Welcome!');
    }
    console.log('   Press Ctrl+C to stop.\n');
  });
}
