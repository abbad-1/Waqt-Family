-- Waqt Cloudflare D1 Schema (SQLite) — 100% Free Tier, No Credit Card Required
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  pin_hash TEXT DEFAULT NULL,
  pin_salt TEXT DEFAULT NULL,
  phone TEXT NOT NULL DEFAULT '',
  facetime_id TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL,
  country TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  tz TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT 'MuslimWorldLeague',
  asr_method TEXT NOT NULL DEFAULT 'standard',
  high_latitude_rule TEXT NOT NULL DEFAULT 'auto',
  remind_offset_minutes INTEGER NOT NULL DEFAULT 0,
  share_status INTEGER NOT NULL DEFAULT 1,
  show_city INTEGER NOT NULL DEFAULT 1,
  circle_reminders INTEGER NOT NULL DEFAULT 1,
  quiet_until_ms INTEGER DEFAULT NULL,
  evening_summary INTEGER NOT NULL DEFAULT 0,
  last_summary_date TEXT DEFAULT NULL,
  character_style TEXT NOT NULL DEFAULT 'characters',
  preferred_character TEXT NOT NULL DEFAULT 'teta',
  next_prayer_name TEXT DEFAULT NULL,
  next_prayer_at_ms INTEGER DEFAULT NULL,
  next_prayer_date TEXT DEFAULT NULL,
  snooze_prayer_name TEXT DEFAULT NULL,
  snooze_at_ms INTEGER DEFAULT NULL,
  created_at_ms INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_next_prayer ON users(next_prayer_at_ms);
CREATE INDEX IF NOT EXISTS idx_users_snooze ON users(snooze_at_ms);
CREATE INDEX IF NOT EXISTS idx_users_display_name ON users(display_name);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  uid TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL,
  FOREIGN KEY (uid) REFERENCES users(uid) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS circles (
  circle_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  owner_uid TEXT NOT NULL,
  invite_code TEXT NOT NULL UNIQUE,
  created_at_ms INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_circles_invite_code ON circles(invite_code);

CREATE TABLE IF NOT EXISTS circle_members (
  circle_id TEXT NOT NULL,
  uid TEXT NOT NULL,
  joined_at_ms INTEGER NOT NULL,
  PRIMARY KEY (circle_id, uid),
  FOREIGN KEY (circle_id) REFERENCES circles(circle_id) ON DELETE CASCADE,
  FOREIGN KEY (uid) REFERENCES users(uid) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_circle_members_uid ON circle_members(uid);

CREATE TABLE IF NOT EXISTS prayer_logs (
  uid TEXT NOT NULL,
  local_date TEXT NOT NULL,
  prayer TEXT NOT NULL,
  confirmed_at_ms INTEGER NOT NULL,
  PRIMARY KEY (uid, local_date, prayer),
  FOREIGN KEY (uid) REFERENCES users(uid) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS nudges (
  nudge_id TEXT PRIMARY KEY,
  from_uid TEXT NOT NULL,
  to_uid TEXT NOT NULL,
  circle_id TEXT NOT NULL,
  prayer TEXT NOT NULL,
  local_date TEXT NOT NULL,
  character_id TEXT NOT NULL DEFAULT 'teta',
  created_at_ms INTEGER NOT NULL,
  delivered_at_ms INTEGER DEFAULT NULL,
  suppressed INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_nudges_recipient ON nudges(to_uid, local_date, prayer, created_at_ms);

CREATE TABLE IF NOT EXISTS messages (
  message_id TEXT PRIMARY KEY,
  circle_id TEXT NOT NULL,
  from_uid TEXT NOT NULL,
  to_uid TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'text',
  prayer TEXT DEFAULT NULL,
  body TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(circle_id, created_at_ms);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  endpoint TEXT PRIMARY KEY,
  uid TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  user_agent TEXT NOT NULL DEFAULT '',
  created_at_ms INTEGER NOT NULL,
  FOREIGN KEY (uid) REFERENCES users(uid) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_push_uid ON push_subscriptions(uid);
