// Enriches data/cities.json with verified IANA time zones (`tz`) for all 126 cities
// and validates every IANA zone in Intl.DateTimeFormat.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SOURCE = process.argv[2] ? path.resolve(process.argv[2]) : path.join(ROOT_DIR, 'data/cities.json');

const CITY_TZ = {
  'Abu Dhabi|UAE': 'Asia/Dubai',
  'Dubai|UAE': 'Asia/Dubai',
  'Sharjah|UAE': 'Asia/Dubai',
  'Mecca|Saudi Arabia': 'Asia/Riyadh',
  'Medina|Saudi Arabia': 'Asia/Riyadh',
  'Riyadh|Saudi Arabia': 'Asia/Riyadh',
  'Jeddah|Saudi Arabia': 'Asia/Riyadh',
  'Dammam|Saudi Arabia': 'Asia/Riyadh',
  'Doha|Qatar': 'Asia/Qatar',
  'Manama|Bahrain': 'Asia/Bahrain',
  'Kuwait City|Kuwait': 'Asia/Kuwait',
  'Muscat|Oman': 'Asia/Muscat',
  'Sanaa|Yemen': 'Asia/Aden',
  'Cairo|Egypt': 'Africa/Cairo',
  'Alexandria|Egypt': 'Africa/Cairo',
  'Amman|Jordan': 'Asia/Amman',
  'Beirut|Lebanon': 'Asia/Beirut',
  'Damascus|Syria': 'Asia/Damascus',
  'Baghdad|Iraq': 'Asia/Baghdad',
  'Tehran|Iran': 'Asia/Tehran',
  'Mashhad|Iran': 'Asia/Tehran',
  'Istanbul|Turkey': 'Europe/Istanbul',
  'Ankara|Turkey': 'Europe/Istanbul',
  'Izmir|Turkey': 'Europe/Istanbul',
  'Casablanca|Morocco': 'Africa/Casablanca',
  'Rabat|Morocco': 'Africa/Casablanca',
  'Fez|Morocco': 'Africa/Casablanca',
  'Algiers|Algeria': 'Africa/Algiers',
  'Tunis|Tunisia': 'Africa/Tunis',
  'Tripoli|Libya': 'Africa/Tripoli',
  'Khartoum|Sudan': 'Africa/Khartoum',
  'Mogadishu|Somalia': 'Africa/Mogadishu',
  'Lagos|Nigeria': 'Africa/Lagos',
  'Abuja|Nigeria': 'Africa/Lagos',
  'Kano|Nigeria': 'Africa/Lagos',
  'Nairobi|Kenya': 'Africa/Nairobi',
  'Dar es Salaam|Tanzania': 'Africa/Dar_es_Salaam',
  'Kampala|Uganda': 'Africa/Kampala',
  'Kabul|Afghanistan': 'Asia/Kabul',
  'Islamabad|Pakistan': 'Asia/Karachi',
  'Karachi|Pakistan': 'Asia/Karachi',
  'Lahore|Pakistan': 'Asia/Karachi',
  'Peshawar|Pakistan': 'Asia/Karachi',
  'Delhi|India': 'Asia/Kolkata',
  'Mumbai|India': 'Asia/Kolkata',
  'Hyderabad|India': 'Asia/Kolkata',
  'Lucknow|India': 'Asia/Kolkata',
  'Bengaluru|India': 'Asia/Kolkata',
  'Chennai|India': 'Asia/Kolkata',
  'Dhaka|Bangladesh': 'Asia/Dhaka',
  'Chittagong|Bangladesh': 'Asia/Dhaka',
  'Colombo|Sri Lanka': 'Asia/Colombo',
  'Kathmandu|Nepal': 'Asia/Kathmandu',
  'Jakarta|Indonesia': 'Asia/Jakarta',
  'Surabaya|Indonesia': 'Asia/Jakarta',
  'Kuala Lumpur|Malaysia': 'Asia/Kuala_Lumpur',
  'Singapore|Singapore': 'Asia/Singapore',
  'Bangkok|Thailand': 'Asia/Bangkok',
  'Manila|Philippines': 'Asia/Manila',
  'Beijing|China': 'Asia/Shanghai',
  'Shanghai|China': 'Asia/Shanghai',
  'Guangzhou|China': 'Asia/Shanghai',
  'Hong Kong|China': 'Asia/Hong_Kong',
  'Tokyo|Japan': 'Asia/Tokyo',
  'Seoul|South Korea': 'Asia/Seoul',
  'London|UK': 'Europe/London',
  'Birmingham|UK': 'Europe/London',
  'Manchester|UK': 'Europe/London',
  'Dublin|Ireland': 'Europe/Dublin',
  'Cork|Ireland': 'Europe/Dublin',
  'Paris|France': 'Europe/Paris',
  'Marseille|France': 'Europe/Paris',
  'Lyon|France': 'Europe/Paris',
  'Berlin|Germany': 'Europe/Berlin',
  'Hamburg|Germany': 'Europe/Berlin',
  'Munich|Germany': 'Europe/Berlin',
  'Frankfurt|Germany': 'Europe/Berlin',
  'Cologne|Germany': 'Europe/Berlin',
  'Amsterdam|Netherlands': 'Europe/Amsterdam',
  'Rotterdam|Netherlands': 'Europe/Amsterdam',
  'Brussels|Belgium': 'Europe/Brussels',
  'Antwerp|Belgium': 'Europe/Brussels',
  'Madrid|Spain': 'Europe/Madrid',
  'Barcelona|Spain': 'Europe/Madrid',
  'Rome|Italy': 'Europe/Rome',
  'Milan|Italy': 'Europe/Rome',
  'Vienna|Austria': 'Europe/Vienna',
  'Zurich|Switzerland': 'Europe/Zurich',
  'Geneva|Switzerland': 'Europe/Zurich',
  'Stockholm|Sweden': 'Europe/Stockholm',
  'Oslo|Norway': 'Europe/Oslo',
  'Copenhagen|Denmark': 'Europe/Copenhagen',
  'Helsinki|Finland': 'Europe/Helsinki',
  'Warsaw|Poland': 'Europe/Warsaw',
  'Moscow|Russia': 'Europe/Moscow',
  'Athens|Greece': 'Europe/Athens',
  'Lisbon|Portugal': 'Europe/Lisbon',
  'Toronto|Canada': 'America/Toronto',
  'Montreal|Canada': 'America/Toronto',
  'Vancouver|Canada': 'America/Vancouver',
  'Ottawa|Canada': 'America/Toronto',
  'Calgary|Canada': 'America/Edmonton',
  'New York|USA': 'America/New_York',
  'Los Angeles|USA': 'America/Los_Angeles',
  'Chicago|USA': 'America/Chicago',
  'Houston|USA': 'America/Chicago',
  'Dallas|USA': 'America/Chicago',
  'Detroit|USA': 'America/Detroit',
  'San Francisco|USA': 'America/Los_Angeles',
  'Washington|USA': 'America/New_York',
  'Atlanta|USA': 'America/New_York',
  'Philadelphia|USA': 'America/New_York',
  'Boston|USA': 'America/New_York',
  'Minneapolis|USA': 'America/Chicago',
  'Seattle|USA': 'America/Los_Angeles',
  'Phoenix|USA': 'America/Phoenix',
  'Miami|USA': 'America/New_York',
  'Mexico City|Mexico': 'America/Mexico_City',
  'Sao Paulo|Brazil': 'America/Sao_Paulo',
  'Buenos Aires|Argentina': 'America/Argentina/Buenos_Aires',
  'Sydney|Australia': 'Australia/Sydney',
  'Melbourne|Australia': 'Australia/Melbourne',
  'Perth|Australia': 'Australia/Perth',
  'Auckland|New Zealand': 'Pacific/Auckland',
  'Johannesburg|South Africa': 'Africa/Johannesburg',
  'Cape Town|South Africa': 'Africa/Johannesburg',
};

const raw = JSON.parse(fs.readFileSync(SOURCE, 'utf8'));
const enrichedCities = raw.cities.map((c) => {
  const key = `${c.name}|${c.country}`;
  const tz = CITY_TZ[key];
  if (!tz) throw new Error(`Missing IANA tz for ${key}`);
  // Validate with Intl
  new Intl.DateTimeFormat('en-US', { timeZone: tz }).format(new Date());
  return {
    name: c.name,
    country: c.country,
    lat: c.lat,
    lon: c.lon,
    tz,
  };
});

const out = {
  note: '126 world cities with city-centre coordinates and verified IANA time zones (`tz`).',
  count: enrichedCities.length,
  cities: enrichedCities,
};

const targets = [
  path.join(ROOT_DIR, 'public/cities.json'),
  path.join(ROOT_DIR, 'data/cities.json'),
];

for (const t of targets) {
  fs.mkdirSync(path.dirname(t), { recursive: true });
  fs.writeFileSync(t, JSON.stringify(out, null, 2) + '\n', 'utf8');
}
console.log(`Successfully enriched and verified ${enrichedCities.length} cities with IANA tz.`);
