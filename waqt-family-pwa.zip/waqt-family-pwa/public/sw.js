/* eslint-env serviceworker */
// Waqt Service Worker — Native Web Push (VAPID, iOS 16.4+ & Android) + Offline App Shell Cache.
// Zero external SDK dependencies.

const CACHE = 'waqt-shell-v3';
const SHELL = [
  '/',
  '/index.html',
  '/styles.css',
  '/app.js',
  '/prayer-engine.js',
  '/qr-svg.js',
  '/manifest.webmanifest',
  '/cities.json',
  '/prayer-methods.json',
  '/notification-copy.json',
  '/sample-data.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-512-maskable.png',
  '/icons/apple-touch-icon.png',
];

let cachedAuthToken = null;

// Persist auth token in Cache Storage under a local-only synthetic key so lock-screen actions work even after SW wake-up
async function saveAuthToken(token) {
  cachedAuthToken = token || null;
  const cache = await caches.open('waqt-sw-meta-v1');
  if (token) {
    await cache.put('/__sw_token__', new Response(JSON.stringify({ token })));
  } else {
    await cache.delete('/__sw_token__');
  }
}

async function loadAuthToken() {
  if (cachedAuthToken) return cachedAuthToken;
  try {
    const cache = await caches.open('waqt-sw-meta-v1');
    const hit = await cache.match('/__sw_token__');
    if (!hit) return null;
    const data = await hit.json();
    cachedAuthToken = data.token || null;
    return cachedAuthToken;
  } catch {
    return null;
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k !== CACHE && k !== 'waqt-sw-meta-v1')
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'SET_AUTH_TOKEN') {
    event.waitUntil(saveAuthToken(msg.token));
  }
});

// Never intercept /api/* calls; serve static shell offline-capable with background refresh.
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/__sw_token__') return;

  const isNav = req.mode === 'navigate';
  event.respondWith(
    caches.match(isNav ? '/index.html' : req).then((cached) => {
      const networkFetch = fetch(req)
        .then((resp) => {
          if (resp && resp.ok) {
            const clone = resp.clone();
            caches.open(CACHE).then((c) => c.put(isNav ? '/index.html' : req, clone)).catch(() => {});
          }
          return resp;
        })
        .catch(() => cached || (isNav ? caches.match('/index.html') : Response.error()));

      return cached || networkFetch;
    })
  );
});

// Native Web Push handler (works on iOS 16.4+ Home Screen Web Apps, Android Chrome, Desktop)
self.addEventListener('push', (event) => {
  let payload = {
    type: 'own',
    title: 'Waqt',
    body: 'Time to pause and pray.',
    tag: 'waqt-reminder',
    url: '/',
  };

  if (event.data) {
    try {
      payload = { ...payload, ...event.data.json() };
    } catch {
      payload.body = event.data.text() || payload.body;
    }
  }

  const isPrayerPrompt = payload.type === 'own' || payload.type === 'nudge';
  const options = {
    body: payload.body,
    tag: payload.tag || 'waqt-reminder',
    renotify: true,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    data: {
      url: payload.url || '/',
      type: payload.type,
      prayer: payload.prayer || null,
      date: payload.date || null,
    },
    actions: isPrayerPrompt
      ? [
          { action: 'prayed', title: '✓ I prayed' },
          { action: 'snooze', title: 'Remind in 15m' },
        ]
      : [],
  };

  event.waitUntil(
    Promise.all([
      self.registration.showNotification(payload.title || 'Waqt', options),
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
        clients.forEach((c) => c.postMessage({ type: 'PUSH_RECEIVED', payload }));
      }),
    ])
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  const action = event.action;

  event.waitUntil(
    (async () => {
      const token = await loadAuthToken();

      if (action === 'prayed' && token && data.prayer) {
        try {
          const resp = await fetch('/api/prayers/confirm', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ prayer: data.prayer, date: data.date }),
          });
          if (resp.ok) {
            const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
            clients.forEach((c) => c.postMessage({ type: 'REFRESH_STATE' }));
            return;
          }
        } catch {
          // Fall through to opening the app window with action query params
        }
      }

      if (action === 'snooze' && token && data.prayer) {
        try {
          const resp = await fetch('/api/prayers/snooze', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ prayer: data.prayer, minutes: 15 }),
          });
          if (resp.ok) {
            const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
            clients.forEach((c) => c.postMessage({ type: 'REFRESH_STATE' }));
            return;
          }
        } catch {
          // Fall through to opening the app window
        }
      }

      let targetUrl = data.url || '/';
      if (action === 'prayed' && data.prayer) {
        targetUrl = `/?action=prayed&prayer=${encodeURIComponent(data.prayer)}&date=${encodeURIComponent(data.date || '')}`;
      } else if (action === 'snooze' && data.prayer) {
        targetUrl = `/?action=snooze&prayer=${encodeURIComponent(data.prayer)}`;
      }

      const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clients) {
        if ('focus' in client) {
          await client.focus();
          client.postMessage({ type: 'NAVIGATE_URL', url: targetUrl });
          return;
        }
      }
      await self.clients.openWindow(targetUrl);
    })()
  );
});
