# Waqt (وقت) — Step-by-Step Family Setup Guide
### Option A: 100% Card-Free Deployment ($0 Forever · No Credit Card Needed)

Follow these steps once (~10 minutes) to put your private family Waqt app online with HTTPS, cross-device family circles, per-minute prayer reminders, lock-screen notifications, and 1-tap WhatsApp/FaceTime check-ins.

---

## Prerequisites (2 Minutes)

1. **A computer with Node.js 18 or newer** (`node -v` prints `v18.x`, `v20.x`, or `v22.x`).
   - Download free from [nodejs.org](https://nodejs.org/) if you don't have it yet.
2. **A free Cloudflare account** — Sign up at [dash.cloudflare.com/sign-up](https://dash.cloudflare.com/sign-up) with just an email and password.
   - Select the **$0 Free Plan** (Cloudflare Workers, D1 SQLite, Static Assets, and Cron Triggers are all included on Free **without entering a credit card**).

---

## Step 1 — Unzip & Sign In to Cloudflare

Open Terminal (Mac/Linux) or PowerShell (Windows), unzip `waqt-family-pwa.zip`, and enter the folder:

```bash
unzip waqt-family-pwa.zip
cd waqt-family-pwa
```

Sign in to your free Cloudflare account (this opens a browser window to click **Allow**):

```bash
npx wrangler login
```

*(Note: When `npx` asks `Ok to proceed? (y)` to run `wrangler`, press `y`.)*

---

## Step 2 — Create Your Free Family Database (Cloudflare D1)

Run this single command to create your private serverless SQLite database:

```bash
npx wrangler d1 create waqt-family-db
```

Wrangler will print output ending with a `database_id` UUID, like:

```toml
[[d1_databases]]
binding = "DB"
database_name = "waqt-family-db"
database_id = "12345678-abcd-efgh-ijkl-1234567890ab"
```

1. Open **`wrangler.toml`** in any text editor.
2. Replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with the `database_id` printed in your terminal, and save `wrangler.toml`.
3. Initialize the database tables (`users`, `circles`, `prayer_logs`, `nudges`, `messages`, `push_subscriptions`):

```bash
npx wrangler d1 execute waqt-family-db --remote --file=./schema.sql
```

---

## Step 3 — Generate Your Free Lock-Screen Push Keys (VAPID)

Waqt uses open-standard Web Push (RFC 8292 + RFC 8291) — no Firebase account or paid Apple Developer account needed!

Generate your unique key pair locally:

```bash
node scripts/generate-vapid-keys.mjs
```

It will print:
- **`VAPID_PUBLIC_KEY`** (safe to put in `wrangler.toml`)
- **`VAPID_PRIVATE_KEY`** (keep secret!)

1. Copy the **`VAPID_PUBLIC_KEY`** string into `wrangler.toml`:
   ```toml
   [vars]
   VAPID_SUBJECT = "mailto:your-email@example.com"
   VAPID_PUBLIC_KEY = "PASTE_YOUR_PUBLIC_KEY_HERE"
   ```
2. Save the **`VAPID_PRIVATE_KEY`** as an encrypted Cloudflare Worker secret:
   ```bash
   npx wrangler secret put VAPID_PRIVATE_KEY
   ```
   *(When prompted, paste your private key and press Enter.)*

> **Optional Extra Privacy**: Want to make sure nobody outside your family can register even if they guess your URL? Set a shared family word:
> ```bash
> npx wrangler secret put FAMILY_ACCESS_CODE
> ```
> When set, the Welcome screen automatically reveals a *"Family access word"* box for first-time sign-ups.

---

## Step 4 — Deploy Live to HTTPS!

Deploy the PWA frontend, API routes, D1 binding, and `* * * * *` per-minute prayer scheduler in one command:

```bash
npx wrangler deploy
```

Wrangler will print your live HTTPS link, for example:
```text
Published waqt-family
  https://waqt-family.<your-subdomain>.workers.dev
```

---

## Step 5 — Install on Your Family's Phones (Lock-Screen Push + 1-Tap Calls)

Share your `https://waqt-family.<your-subdomain>.workers.dev` link in your family WhatsApp group!

### On iPhone (iOS 16.4 or newer) — **Important for Lock-Screen Push!**
Apple requires web apps to be added to the Home Screen before enabling lock-screen notifications:
1. Open your `workers.dev` link in **Safari** on iPhone.
2. Tap the **Share** button (square with up arrow at the bottom of Safari).
3. Scroll down and tap **Add to Home Screen** → tap **Add**.
4. Open **Waqt** from its emerald crescent icon on your Home Screen.
5. Complete the 20-second Welcome screen (Name + City + optional 4-digit PIN).
6. Go to **Settings → Lock-screen push → Enable** and tap **Allow**.
   - Tap the row again anytime to send yourself a live test push!

### On Android (Chrome / Edge / Samsung Internet)
1. Open your `workers.dev` link in **Chrome**.
2. Tap the browser menu (`⋮`) → **Install app** (or **Add to Home screen**).
3. Open **Waqt**, finish Welcome, and tap **Settings → Lock-screen push → Enable**.

---

## Step 6 — Create Your Family Circle & Add WhatsApp / FaceTime Shortcuts

1. **Create & Share Your Circle Code (Link, WhatsApp, or Offline QR Code)**:
   - On the first person's phone, Waqt automatically creates your **Family** circle with an invite code like `FAM-4821` (or tap **Circle → + New circle** to create another circle like *"Friends"*).
   - Tap the gold **`Invite`** button (or **`Share invite on WhatsApp`**) on the **Circle** tab to share or copy your invite code & link — or tap **`QR Code`** when sitting with family at home to display an instant on-device SVG QR code (`/?join=FAM-4821`) that relatives can scan with their phone camera!
   - Everyone else enters that code on Welcome (`+ Have an invite code or PIN?`, which auto-fills when opened from an invite link or QR code) or via **Circle → Join code**.
2. **Enable 1-Tap WhatsApp & FaceTime Check-Ins**:
   - Each family member opens **Settings → WhatsApp, FaceTime & PIN** and enters their phone number with country code (e.g., `+971501234567` or `+353871234567`) and/or Apple ID email for FaceTime, plus an optional **4+ digit PIN** (so they can sign back in if they ever switch phones).
   - Now, tapping any family member in **Circle** → **`Video call`** (or tapping the video icon in the **Chat** header) opens a 1-tap sheet for:
     - **WhatsApp Message / Call** (pre-filled with *"Assalamu alaikum …, checking in with love for Asr!"*)
     - **FaceTime Video** (`facetime://`)
     - **FaceTime Audio** (`facetime-audio://`)
     - **Regular Phone Call** (`tel:`)

---

## Everyday Tips & Privacy Controls

- **Today's Full Prayer Timetable (`Fajr`, `Sunrise / Shuruq`, `Dhuhr`, `Asr`, `Maghrib`, `Isha`)**: Each of the 5 prayer pills on Home shows its exact local start time, and tapping the time window pill inside the gold progress ring opens Today's complete timetable including **Sunrise (`الشروق`)**.
- **Works Offline on Flights & Bad Signal**: Signed-in users who open Waqt while offline stay signed in with their cached family circle and live on-device solar recalculation, automatically syncing as soon as connectivity returns.
- **Zero Guilt Design**: There are **no streaks, no scores, no red missed badges, and no leaderboards** anywhere in Waqt. Every local midnight starts fresh.
- **Cross-Timezone Translation**: When Mama in Abu Dhabi taps Ahmed in Dublin, Waqt calculates **Ahmed's** local prayer window (*"In Dublin it's Dhuhr · 1:15 PM — 1h 32m left"*) and sends at most **1 gentle nudge per prayer per day** per sender. Multiple family nudges group cleanly into a single notification (*"Mama and Teta are thinking of you for Asr"*).
- **Quiet Mode Today**: Travelling, unwell, or unable to pray today? Toggle **Settings → Quiet mode today**. Incoming nudges are silenced until midnight **without telling the sender**, so you never have to explain.
- **Private Prayer Status & City Redaction**: Toggle **Settings → Share when I've prayed** off at any time to keep using personal prayer countdowns and family chat while hiding your confirmation checkmarks (`"Private"`), or toggle **Settings → Show my city** off to hide your city, time zone, and local clock times from your circle.

