// Waqt Astronomical Prayer-Time Engine (ES Module, zero external dependencies).
// Implements Jean Meeus (Astronomical Algorithms) solar coordinates & Batoul Apps `adhan` v4
// presets, juristic Asr shadow rules, Umm al-Qura Ramadan 120-min Isha, Tehran 4.5-deg Maghrib,
// Moonsighting Committee seasonal twilight, and high-latitude rules across any IANA time zone.

export const PRAYERS = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

export const PRAYER_ARABIC = {
  Fajr: 'الفجر',
  Dhuhr: 'الظهر',
  Asr: 'العصر',
  Maghrib: 'المغرب',
  Isha: 'العشاء',
};

export const METHOD_PRESETS = {
  Dubai: {
    label: 'UAE (Dubai)',
    shortLabel: 'UAE (Dubai)',
    fajrAngle: 18.2,
    ishaAngle: 18.2,
    adjustments: { sunrise: -3, dhuhr: 3, asr: 3, maghrib: 3, isha: 0, fajr: 0 },
  },
  UmmAlQura: {
    label: 'Umm al-Qura (Makkah)',
    shortLabel: 'Umm al-Qura',
    fajrAngle: 18.5,
    ishaAngle: 0,
    ishaInterval: 90,
    ramadanIshaInterval: 120,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  },
  Egyptian: {
    label: 'Egyptian General Authority of Survey',
    shortLabel: 'Egyptian',
    fajrAngle: 19.5,
    ishaAngle: 17.5,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 1, asr: 0, maghrib: 0, isha: 0 },
  },
  Karachi: {
    label: 'University of Islamic Sciences, Karachi',
    shortLabel: 'Karachi',
    fajrAngle: 18,
    ishaAngle: 18,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 1, asr: 0, maghrib: 0, isha: 0 },
  },
  Turkey: {
    label: 'Diyanet (Turkey)',
    shortLabel: 'Diyanet',
    fajrAngle: 18,
    ishaAngle: 17,
    adjustments: { fajr: 0, sunrise: -7, dhuhr: 5, asr: 4, maghrib: 7, isha: 0 },
  },
  Tehran: {
    label: 'Institute of Geophysics, University of Tehran',
    shortLabel: 'Tehran',
    fajrAngle: 17.7,
    maghribAngle: 4.5,
    ishaAngle: 14,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  },
  Kuwait: {
    label: 'Kuwait',
    shortLabel: 'Kuwait',
    fajrAngle: 18,
    ishaAngle: 17.5,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  },
  Qatar: {
    label: 'Qatar',
    shortLabel: 'Qatar',
    fajrAngle: 18,
    ishaAngle: 0,
    ishaInterval: 90,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  },
  Singapore: {
    label: 'Singapore (MUIS)',
    shortLabel: 'Singapore',
    fajrAngle: 20,
    ishaAngle: 18,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 1, asr: 0, maghrib: 0, isha: 0 },
  },
  NorthAmerica: {
    label: 'ISNA (North America)',
    shortLabel: 'ISNA',
    fajrAngle: 15,
    ishaAngle: 15,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 1, asr: 0, maghrib: 0, isha: 0 },
  },
  MuslimWorldLeague: {
    label: 'Muslim World League',
    shortLabel: 'MWL',
    fajrAngle: 18,
    ishaAngle: 17,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 1, asr: 0, maghrib: 0, isha: 0 },
  },
  MoonsightingCommittee: {
    label: 'Moonsighting Committee',
    shortLabel: 'Moonsighting',
    fajrAngle: 18,
    ishaAngle: 18,
    moonsighting: true,
    adjustments: { fajr: 0, sunrise: 0, dhuhr: 5, asr: 0, maghrib: 3, isha: 0 },
  },
};

const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;

function dtr(d) {
  return d * DEG2RAD;
}

function rtd(r) {
  return r * RAD2DEG;
}

function unwindAngle(angle) {
  const m = angle % 360;
  return m < 0 ? m + 360 : m;
}

function quadrantShiftAngle(angle) {
  const a = unwindAngle(angle);
  return a > 180 ? a - 360 : a;
}

export function julianDay(year, month, day, hours = 0) {
  let Y = year;
  let M = month;
  if (M <= 2) {
    Y -= 1;
    M += 12;
  }
  const A = Math.floor(Y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return (
    Math.floor(365.25 * (Y + 4716)) +
    Math.floor(30.6001 * (M + 1)) +
    day +
    hours / 24 +
    B -
    1524.5
  );
}

// Meeus Ch. 25 solar coordinates (apparent declination + equation of time in hours).
export function solarCoordinates(jd) {
  const T = (jd - 2451545.0) / 36525.0;
  const L0 = unwindAngle(280.4664567 + 36000.76983 * T + 0.0003032 * T * T);
  const M = unwindAngle(357.52911 + 35999.05029 * T - 0.0001537 * T * T);
  const Mrad = dtr(M);

  const C =
    (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(Mrad) +
    (0.019993 - 0.000101 * T) * Math.sin(2 * Mrad) +
    0.000289 * Math.sin(3 * Mrad);

  const theta = L0 + C;
  const omega = unwindAngle(125.04 - 1934.136 * T);
  const lambda = theta - 0.00569 - 0.00478 * Math.sin(dtr(omega));

  const eps0 =
    23 +
    26 / 60 +
    21.448 / 3600 -
    (46.815 * T + 0.00059 * T * T - 0.001813 * T * T * T) / 3600;
  const eps = eps0 + 0.00256 * Math.cos(dtr(omega));

  const epsRad = dtr(eps);
  const lambdaRad = dtr(lambda);

  const declination = rtd(Math.asin(Math.sin(epsRad) * Math.sin(lambdaRad)));
  const rightAscension = unwindAngle(
    rtd(Math.atan2(Math.cos(epsRad) * Math.sin(lambdaRad), Math.cos(lambdaRad)))
  );

  const eqtHours = quadrantShiftAngle(L0 - rightAscension) / 15;
  return { declination, rightAscension, eqtHours };
}

function altitudeTimeUT(jd0, lat, lon, altitudeDeg, transitUT, afterTransit) {
  let ut = transitUT + (afterTransit ? 6 : -6);
  for (let i = 0; i < 2; i += 1) {
    const { declination, eqtHours } = solarCoordinates(jd0 + ut / 24);
    const localTransit = 12 - eqtHours - lon / 15;
    const num = Math.sin(dtr(altitudeDeg)) - Math.sin(dtr(lat)) * Math.sin(dtr(declination));
    const den = Math.cos(dtr(lat)) * Math.cos(dtr(declination));
    const cosH = num / den;
    if (cosH < -1 || cosH > 1) return NaN;
    const hourAngleHours = rtd(Math.acos(cosH)) / 15;
    ut = localTransit + (afterTransit ? hourAngleHours : -hourAngleHours);
  }
  return ut;
}

function transitTimeUT(jd0, lon) {
  let ut = 12 - lon / 15;
  for (let i = 0; i < 2; i += 1) {
    const { eqtHours } = solarCoordinates(jd0 + ut / 24);
    ut = 12 - eqtHours - lon / 15;
  }
  return ut;
}

function asrTimeUT(jd0, lat, lon, shadowFactor, transitUT) {
  const { declination: noonDecl } = solarCoordinates(jd0 + transitUT / 24);
  let ut = transitUT + 3.5;
  for (let i = 0; i < 2; i += 1) {
    const { declination, eqtHours } = solarCoordinates(jd0 + ut / 24);
    const localTransit = 12 - eqtHours - lon / 15;
    const altitudeRad = Math.atan(1 / (shadowFactor + Math.tan(dtr(Math.abs(lat - noonDecl)))));
    const num = Math.sin(altitudeRad) - Math.sin(dtr(lat)) * Math.sin(dtr(declination));
    const den = Math.cos(dtr(lat)) * Math.cos(dtr(declination));
    const cosH = num / den;
    if (cosH < -1 || cosH > 1) return NaN;
    const hourAngleHours = rtd(Math.acos(cosH)) / 15;
    ut = localTransit + hourAngleHours;
  }
  return ut;
}

export function isRamadanUmmAlQura(instant) {
  try {
    const parts = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
      month: 'numeric',
      timeZone: 'Asia/Riyadh',
    }).formatToParts(instant);
    const monthPart = parts.find((p) => p.type === 'month');
    return monthPart ? Number(monthPart.value) === 9 : false;
  } catch {
    return false;
  }
}

function daysSinceSolstice(year, month, day, lat) {
  const target = Date.UTC(year, month - 1, day);
  let solstice;
  if (lat >= 0) {
    solstice =
      month === 12 && day >= 21
        ? Date.UTC(year, 11, 21)
        : Date.UTC(year - 1, 11, 21);
  } else {
    solstice =
      month > 6 || (month === 6 && day >= 21)
        ? Date.UTC(year, 5, 21)
        : Date.UTC(year - 1, 5, 21);
  }
  return Math.max(0, Math.round((target - solstice) / 86400000));
}

function interpolateSeasonal(doy, a, b, c, d) {
  if (doy < 91) return a + ((b - a) / 91) * doy;
  if (doy < 137) return b + ((c - b) / 46) * (doy - 91);
  if (doy < 183) return c + ((d - c) / 46) * (doy - 137);
  if (doy < 229) return d + ((c - d) / 46) * (doy - 183);
  if (doy < 275) return c + ((b - c) / 46) * (doy - 229);
  return b + ((a - b) / 91) * (doy - 275);
}

function moonsightingFajrMinutes(lat, year, month, day) {
  const absLat = Math.abs(lat);
  const a = 75 + (28.65 / 55) * absLat;
  const b = 75 + (19.44 / 55) * absLat;
  const c = 75 + (32.74 / 55) * absLat;
  const d = 75 + (48.1 / 55) * absLat;
  return Math.round(interpolateSeasonal(daysSinceSolstice(year, month, day, lat), a, b, c, d));
}

function moonsightingIshaMinutes(lat, year, month, day) {
  const absLat = Math.abs(lat);
  const a = 75 + (25.6 / 55) * absLat;
  const b = 75 + (2.05 / 55) * absLat;
  const c = 75 - (9.21 / 55) * absLat;
  const d = 75 + (6.14 / 55) * absLat;
  return Math.round(interpolateSeasonal(daysSinceSolstice(year, month, day, lat), a, b, c, d));
}

export function resolveHighLatitudeRule(lat, requestedRule = 'auto') {
  if (
    requestedRule === 'middleOfTheNight' ||
    requestedRule === 'seventhOfTheNight' ||
    requestedRule === 'twilightAngle'
  ) {
    return requestedRule;
  }
  return Math.abs(Number(lat) || 0) > 48 ? 'seventhOfTheNight' : 'middleOfTheNight';
}

function nightPortions(rule, fajrAngle, ishaAngle) {
  switch (rule) {
    case 'seventhOfTheNight':
      return { fajr: 1 / 7, isha: 1 / 7 };
    case 'twilightAngle':
      return { fajr: (fajrAngle || 18) / 60, isha: (ishaAngle || 18) / 60 };
    case 'middleOfTheNight':
    default:
      return { fajr: 1 / 2, isha: 1 / 2 };
  }
}

export function validateTimeZone(tz) {
  if (!tz || typeof tz !== 'string') return false;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz }).format(new Date(0));
    return true;
  } catch {
    return false;
  }
}

export function localDateString(instant, tz) {
  const safeTz = validateTimeZone(tz) ? tz : 'UTC';
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: safeTz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(instant);
  const y = parts.find((p) => p.type === 'year').value;
  const m = parts.find((p) => p.type === 'month').value;
  const d = parts.find((p) => p.type === 'day').value;
  return `${y}-${m}-${d}`;
}

export function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + n));
  return t.toISOString().slice(0, 10);
}

export function timesForDate(user, dateOrStr) {
  const dateStr =
    dateOrStr instanceof Date ? localDateString(dateOrStr, user.tz) : String(dateOrStr);
  const [y, m, d] = dateStr.split('-').map(Number);
  const lat = Number(user.lat);
  const lon = Number(user.lon);
  const preset = METHOD_PRESETS[user.method] || METHOD_PRESETS.MuslimWorldLeague;
  const shadowFactor = user.asrMethod === 'hanafi' ? 2 : 1;

  const baseUtcMs = Date.UTC(y, m - 1, d, 0, 0, 0);
  const jdPrev = julianDay(y, m, d - 1, 0);
  const jd0 = julianDay(y, m, d, 0);
  const jdNext = julianDay(y, m, d + 1, 0);

  const prevTransitUT = transitTimeUT(jdPrev, lon);
  const prevSunsetRaw = altitudeTimeUT(jdPrev, lat, lon, -0.833333, prevTransitUT, true);
  const transitUT = transitTimeUT(jd0, lon);
  const sunriseUT = altitudeTimeUT(jd0, lat, lon, -0.833333, transitUT, false);
  const sunsetUT = altitudeTimeUT(jd0, lat, lon, -0.833333, transitUT, true);

  const nextTransitUT = transitTimeUT(jdNext, lon);
  const nextSunriseRaw = altitudeTimeUT(jdNext, lat, lon, -0.833333, nextTransitUT, false);
  const nextSunriseUT = Number.isNaN(nextSunriseRaw) ? NaN : nextSunriseRaw + 24;

  const { declination: noonDecl } = solarCoordinates(jd0 + transitUT / 24);
  const polarWinter = Number.isNaN(sunriseUT) && lat * noonDecl < 0;
  const fallbackHalfDay = polarWinter ? 2.5 : 6;

  const safePrevSunsetUT = (Number.isNaN(prevSunsetRaw) ? prevTransitUT + fallbackHalfDay : prevSunsetRaw) - 24;
  const safeSunriseUT = Number.isNaN(sunriseUT) ? transitUT - fallbackHalfDay : sunriseUT;
  const safeSunsetUT = Number.isNaN(sunsetUT) ? transitUT + fallbackHalfDay : sunsetUT;
  const safeNextSunriseUT = Number.isNaN(nextSunriseUT)
    ? nextTransitUT + 24 - fallbackHalfDay
    : nextSunriseUT;

  const prevNightHours = Math.max(1, safeSunriseUT - safePrevSunsetUT);
  const nightHours = Math.max(1, safeNextSunriseUT - safeSunsetUT);

  let fajrUT = altitudeTimeUT(jd0, lat, lon, -preset.fajrAngle, transitUT, false);
  const asrUT = asrTimeUT(jd0, lat, lon, shadowFactor, transitUT);
  const safeAsrUT = Number.isNaN(asrUT)
    ? transitUT + Math.max(0.5, (safeSunsetUT - transitUT) * 0.55)
    : asrUT;

  let maghribUT = safeSunsetUT;
  if (preset.maghribAngle) {
    const rawMaghrib = altitudeTimeUT(jd0, lat, lon, -preset.maghribAngle, transitUT, true);
    if (!Number.isNaN(rawMaghrib) && rawMaghrib > safeSunsetUT) {
      maghribUT = rawMaghrib;
    }
  }

  let ishaUT;
  const noonInstant = new Date(baseUtcMs + transitUT * 3600000);
  if (preset.moonsighting) {
    if (Math.abs(lat) >= 55) {
      fajrUT = safeSunriseUT - prevNightHours / 7;
      ishaUT = maghribUT + Math.max(1, safeNextSunriseUT - maghribUT) / 7;
    } else {
      const seasonFajrUT = safeSunriseUT - moonsightingFajrMinutes(lat, y, m, d) / 60;
      fajrUT = Number.isNaN(fajrUT) ? seasonFajrUT : Math.max(fajrUT, seasonFajrUT);
      ishaUT = safeSunsetUT + moonsightingIshaMinutes(lat, y, m, d) / 60;
    }
  } else if (preset.ishaInterval) {
    const intervalMin =
      preset.ramadanIshaInterval && isRamadanUmmAlQura(noonInstant)
        ? preset.ramadanIshaInterval
        : preset.ishaInterval;
    ishaUT = maghribUT + intervalMin / 60;
  } else {
    ishaUT = altitudeTimeUT(jd0, lat, lon, -preset.ishaAngle, transitUT, true);
  }

  const rule = resolveHighLatitudeRule(lat, user.highLatitudeRule || user.highLatRule);
  const portions = nightPortions(rule, preset.fajrAngle, preset.ishaAngle);
  const applyHighLat =
    Math.abs(lat) > 48 || Number.isNaN(fajrUT) || Number.isNaN(ishaUT);

  if (applyHighLat && !preset.moonsighting) {
    const earliestFajrUT = safeSunriseUT - prevNightHours * portions.fajr;
    if (Number.isNaN(fajrUT) || fajrUT < earliestFajrUT) {
      fajrUT = earliestFajrUT;
    }
    if (!preset.ishaInterval) {
      const latestIshaUT = Math.max(
        maghribUT + 10 / 60,
        safeSunsetUT + nightHours * portions.isha
      );
      if (Number.isNaN(ishaUT) || ishaUT > latestIshaUT) {
        ishaUT = latestIshaUT;
      }
    }
  }

  if (fajrUT >= safeSunriseUT - 5 / 60) {
    fajrUT = safeSunriseUT - prevNightHours * portions.fajr;
  }
  if (ishaUT <= maghribUT + 5 / 60) {
    ishaUT = maghribUT + Math.max(10 / 60, (safeNextSunriseUT - maghribUT) * portions.isha);
  }

  // Compute tomorrow's Fajr lower bound so today's Isha never collides with or exceeds tomorrow's Fajr
  let nextFajrBoundUT;
  if (preset.moonsighting) {
    const nextDateStr = addDays(dateStr, 1);
    const [ny, nm, nd] = nextDateStr.split('-').map(Number);
    if (Math.abs(lat) >= 55) {
      nextFajrBoundUT = safeNextSunriseUT - nightHours / 7;
    } else {
      const nextRawFajr = altitudeTimeUT(jdNext, lat, lon, -preset.fajrAngle, nextTransitUT, false);
      const nextSeasonFajr = safeNextSunriseUT - moonsightingFajrMinutes(lat, ny, nm, nd) / 60;
      nextFajrBoundUT = Number.isNaN(nextRawFajr)
        ? nextSeasonFajr
        : Math.max(nextRawFajr + 24, nextSeasonFajr);
    }
  } else {
    const nextRawFajr = altitudeTimeUT(jdNext, lat, lon, -preset.fajrAngle, nextTransitUT, false);
    const nextEarliestFajr = safeNextSunriseUT - nightHours * portions.fajr;
    if (Math.abs(lat) > 48 || Number.isNaN(nextRawFajr)) {
      nextFajrBoundUT = Number.isNaN(nextRawFajr)
        ? nextEarliestFajr
        : Math.max(nextRawFajr + 24, nextEarliestFajr);
    } else {
      nextFajrBoundUT = nextRawFajr + 24;
    }
  }

  if (Number.isFinite(nextFajrBoundUT) && ishaUT >= nextFajrBoundUT - 2 / 60) {
    ishaUT = Math.max(maghribUT + 5 / 60, nextFajrBoundUT - 2 / 60);
  }

  const adj = preset.adjustments || {};
  const toMs = (utHours, adjMin = 0) =>
    Math.round((baseUtcMs + (utHours + adjMin / 60) * 3600000) / 60000) * 60000;

  const fajrMs = toMs(fajrUT, adj.fajr || 0);
  const sunriseMs = Math.max(fajrMs + 60000, toMs(safeSunriseUT, adj.sunrise || 0));
  const dhuhrMs = Math.max(sunriseMs + 60000, toMs(transitUT, adj.dhuhr || 0));
  const asrMs = Math.max(dhuhrMs + 60000, toMs(safeAsrUT, adj.asr || 0));
  const maghribMs = Math.max(asrMs + 60000, toMs(maghribUT, adj.maghrib || 0));
  const ishaMs = Math.max(maghribMs + 60000, toMs(ishaUT, adj.isha || 0));

  return {
    Fajr: new Date(fajrMs),
    Sunrise: new Date(sunriseMs),
    Dhuhr: new Date(dhuhrMs),
    Asr: new Date(asrMs),
    Maghrib: new Date(maghribMs),
    Isha: new Date(ishaMs),
  };
}

function buildThreeDayTimeline(user, now) {
  const today = localDateString(now, user.tz);
  const dates = [addDays(today, -1), today, addDays(today, 1)];
  const schedules = new Map();
  const events = [];
  for (const dateStr of dates) {
    const sched = timesForDate(user, dateStr);
    schedules.set(dateStr, sched);
    for (const name of PRAYERS) {
      events.push({ name, date: dateStr, at: sched[name] });
    }
  }
  return { today, schedules, events };
}

export function nextPrayer(user, now = new Date()) {
  const { events } = buildThreeDayTimeline(user, now);
  for (const ev of events) {
    if (ev.at.getTime() > now.getTime()) {
      return { name: ev.name, at: ev.at, date: ev.date };
    }
  }
  return null;
}

// Computes the next reminder trigger UTC instant, factoring in optional remindOffsetMinutes (0, 5, 10, 15; <0 means Off).
export function nextReminderSchedule(user, now = new Date()) {
  const offsetMin = Number(user.remindOffsetMinutes ?? 0);
  if (offsetMin < 0) return null;
  const leadMs = offsetMin * 60000;
  const { events } = buildThreeDayTimeline(user, now);
  for (const ev of events) {
    const remindAt = new Date(ev.at.getTime() - leadMs);
    if (remindAt.getTime() > now.getTime()) {
      return { name: ev.name, at: remindAt, prayerAt: ev.at, date: ev.date };
    }
  }
  return null;
}

export function currentPrayerWindow(user, now = new Date()) {
  const { today, schedules, events } = buildThreeDayTimeline(user, now);
  let idx = 0;
  for (let i = 0; i < events.length; i += 1) {
    if (events[i].at.getTime() <= now.getTime()) {
      idx = i;
    }
  }
  const curr = events[idx];
  const next = events[Math.min(idx + 1, events.length - 1)];
  return {
    name: curr.name,
    arabic: PRAYER_ARABIC[curr.name],
    date: curr.date,
    start: curr.at,
    end: next.at,
    nextName: next.name,
    nextStart: next.at,
    todayDate: today,
    schedule: schedules.get(curr.date),
    todaySchedule: schedules.get(today),
  };
}

export function currentPrayer(user, now = new Date()) {
  const win = currentPrayerWindow(user, now);
  return { name: win.name, date: win.date, start: win.start, end: win.end };
}

export function formatTimeInZone(date, tz) {
  const safeTz = validateTimeZone(tz) ? tz : 'UTC';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: safeTz,
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

export function formatDuration(ms) {
  const clamped = Math.max(0, ms);
  const totalMin = Math.ceil(clamped / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h <= 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function endOfLocalDayUtc(now, tz) {
  const safeTz = validateTimeZone(tz) ? tz : 'UTC';
  const today = localDateString(now, safeTz);
  const tomorrow = addDays(today, 1);
  const [y, m, d] = tomorrow.split('-').map(Number);
  let lo = Date.UTC(y, m - 1, d) - 15 * 3600000;
  let hi = Date.UTC(y, m - 1, d) + 15 * 3600000;
  while (hi - lo > 1000) {
    const mid = Math.floor((lo + hi) / 2);
    if (localDateString(new Date(mid), safeTz) < tomorrow) {
      lo = mid;
    } else {
      hi = mid;
    }
  }
  return new Date(hi);
}

export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = dtr(lat2 - lat1);
  const dLon = dtr(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(dtr(lat1)) * Math.cos(dtr(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function nearestCity(lat, lon, cities) {
  if (!Array.isArray(cities) || cities.length === 0) return null;
  let best = cities[0];
  let bestDist = Infinity;
  for (const c of cities) {
    const dist = haversineKm(lat, lon, c.lat, c.lon);
    if (dist < bestDist) {
      bestDist = dist;
      best = c;
    }
  }
  return { city: best, distanceKm: Math.round(bestDist) };
}
