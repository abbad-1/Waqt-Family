#!/usr/bin/env node
// Standalone astronomical prayer-time verification script across the 9 required validation cities
// (Abu Dhabi, Mecca, Cairo, Karachi, Istanbul, London, Dublin, Toronto, New York) + extreme latitudes
// across 12 dates throughout the year (winter/summer solstices, equinoxes, US/EU DST transitions, Ramadan).

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  PRAYERS,
  timesForDate,
  formatTimeInZone,
  currentPrayerWindow,
  validateTimeZone,
} from '../shared/prayer-engine.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const VALIDATION_CITIES = [
  { city: 'Abu Dhabi', method: 'Dubai', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Mecca', method: 'UmmAlQura', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Cairo', method: 'Egyptian', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Karachi', method: 'Karachi', asrMethod: 'hanafi', highLatitudeRule: 'auto' },
  { city: 'Istanbul', method: 'Turkey', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'London', method: 'MuslimWorldLeague', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Dublin', method: 'MuslimWorldLeague', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Toronto', method: 'NorthAmerica', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'New York', method: 'NorthAmerica', asrMethod: 'standard', highLatitudeRule: 'auto' },
  { city: 'Stockholm', method: 'MuslimWorldLeague', asrMethod: 'standard', highLatitudeRule: 'seventhOfTheNight' },
  { city: 'Auckland', method: 'MuslimWorldLeague', asrMethod: 'standard', highLatitudeRule: 'auto' },
];

const TEST_DATES = [
  '2026-01-15', // Mid-winter
  '2026-02-19', // Start of Ramadan 1447 AH
  '2026-03-08', // US/Canada DST spring-forward
  '2026-03-20', // Vernal equinox
  '2026-03-29', // UK/Ireland/EU DST spring-forward
  '2026-05-15', // Late spring high-latitude twilight
  '2026-06-21', // Summer solstice (peak high-latitude stress test)
  '2026-07-15', // Mid-summer
  '2026-09-22', // Autumnal equinox
  '2026-10-25', // UK/Ireland/EU DST fall-back
  '2026-11-01', // US/Canada DST fall-back
  '2026-12-21', // Winter solstice
];

export async function runPrayerVerification({ quiet = false } = {}) {
  const citiesRaw = await fs.readFile(path.resolve(__dirname, '../public/cities.json'), 'utf8');
  const citiesDoc = JSON.parse(citiesRaw);
  const cities = Array.isArray(citiesDoc) ? citiesDoc : citiesDoc.cities;

  let checks = 0;
  const sampleRows = [];

  for (const spec of VALIDATION_CITIES) {
    const cityObj = cities.find((c) => (c.name || c.city) === spec.city);
    if (!cityObj) throw new Error(`Validation city missing from cities.json: ${spec.city}`);
    if (!validateTimeZone(cityObj.tz)) throw new Error(`Invalid tz for ${spec.city}: ${cityObj.tz}`);

    const user = {
      ...cityObj,
      method: spec.method,
      asrMethod: spec.asrMethod,
      highLatitudeRule: spec.highLatitudeRule,
    };

    for (const dateStr of TEST_DATES) {
      const sched = timesForDate(user, dateStr);
      const nextDayDate = (() => {
        const [y, m, d] = dateStr.split('-').map(Number);
        const dt = new Date(Date.UTC(y, m - 1, d + 1));
        return dt.toISOString().slice(0, 10);
      })();
      const tomorrowSched = timesForDate(user, nextDayDate);

      const ordered = [
        ['Fajr', sched.Fajr],
        ['Sunrise', sched.Sunrise],
        ['Dhuhr', sched.Dhuhr],
        ['Asr', sched.Asr],
        ['Maghrib', sched.Maghrib],
        ['Isha', sched.Isha],
        ['TomorrowFajr', tomorrowSched.Fajr],
      ];

      for (const [label, dt] of ordered) {
        if (!(dt instanceof Date) || Number.isNaN(dt.getTime())) {
          throw new Error(`NaN time for ${spec.city} on ${dateStr} (${label})`);
        }
      }

      for (let i = 0; i + 1 < ordered.length; i += 1) {
        const [aName, aTime] = ordered[i];
        const [bName, bTime] = ordered[i + 1];
        if (bTime.getTime() <= aTime.getTime()) {
          throw new Error(
            `Non-monotonic prayer order in ${spec.city} on ${dateStr}: ${aName} (${aTime.toISOString()}) >= ${bName} (${bTime.toISOString()})`
          );
        }
      }

      // Check currentPrayerWindow mid-afternoon
      const midAfternoon = new Date(sched.Asr.getTime() + 15 * 60000);
      const win = currentPrayerWindow(user, midAfternoon);
      if (win.name !== 'Asr') {
        throw new Error(`Expected Asr window 15m after Asr in ${spec.city} on ${dateStr}, got ${win.name}`);
      }

      checks += 1;

      if (dateStr === '2026-03-08' || dateStr === '2026-06-21' || dateStr === '2026-12-21') {
        sampleRows.push({
          city: `${spec.city} (${cityObj.tz})`,
          method: spec.method,
          date: dateStr,
          Fajr: formatTimeInZone(sched.Fajr, cityObj.tz),
          Sunrise: formatTimeInZone(sched.Sunrise, cityObj.tz),
          Dhuhr: formatTimeInZone(sched.Dhuhr, cityObj.tz),
          Asr: formatTimeInZone(sched.Asr, cityObj.tz),
          Maghrib: formatTimeInZone(sched.Maghrib, cityObj.tz),
          Isha: formatTimeInZone(sched.Isha, cityObj.tz),
        });
      }
    }
  }

  if (!quiet) {
    console.log(`✓ Verified ${checks} city-date schedules across ${VALIDATION_CITIES.length} cities & ${TEST_DATES.length} dates (0 NaN, 100% monotonic).`);
    console.table(sampleRows);
  }

  return { checks, sampleRows };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  runPrayerVerification().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
