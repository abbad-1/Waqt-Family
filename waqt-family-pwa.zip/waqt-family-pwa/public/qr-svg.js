// Zero-dependency ISO/IEC 18004 QR Code SVG generator (Versions 1–6, ECC Level L, Byte Mode).
// Used for 100% offline/private family circle invite QR codes (Flow A.4) with zero external network calls.

const VERSION_SPECS = [
  null,
  { size: 21, totalData: 19, ecPerBlock: 7, blocks: 1, align: [] },
  { size: 25, totalData: 34, ecPerBlock: 10, blocks: 1, align: [6, 18] },
  { size: 29, totalData: 55, ecPerBlock: 15, blocks: 1, align: [6, 22] },
  { size: 33, totalData: 80, ecPerBlock: 20, blocks: 1, align: [6, 26] },
  { size: 37, totalData: 108, ecPerBlock: 26, blocks: 1, align: [6, 30] },
  { size: 41, totalData: 136, ecPerBlock: 18, blocks: 2, align: [6, 34] },
];

// GF(256) log/exp tables for Reed-Solomon (primitive polynomial 0x11d)
const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i += 1) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i += 1) {
    GF_EXP[i] = GF_EXP[i - 255];
  }
})();

function gfMul(a, b) {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}

function rsGeneratorPoly(degree) {
  let poly = new Uint8Array([1]);
  for (let i = 0; i < degree; i += 1) {
    const next = new Uint8Array(poly.length + 1);
    const root = GF_EXP[i];
    for (let j = 0; j < poly.length; j += 1) {
      next[j] ^= poly[j];
      next[j + 1] ^= gfMul(poly[j], root);
    }
    poly = next;
  }
  return poly;
}

function rsEncode(dataBytes, ecCount) {
  const gen = rsGeneratorPoly(ecCount);
  const rem = new Uint8Array(ecCount);
  for (let i = 0; i < dataBytes.length; i += 1) {
    const factor = dataBytes[i] ^ rem[0];
    for (let j = 0; j < ecCount - 1; j += 1) {
      rem[j] = rem[j + 1] ^ gfMul(gen[j + 1], factor);
    }
    rem[ecCount - 1] = gfMul(gen[ecCount], factor);
  }
  return rem;
}

function computeFormatBits(maskPattern) {
  // ECC Level L = 01
  const data = (0b01 << 3) | (maskPattern & 0b111);
  let d = data << 10;
  for (let i = 14; i >= 10; i -= 1) {
    if ((d >> i) & 1) {
      d ^= 0x537 << (i - 10);
    }
  }
  return ((data << 10) | d) ^ 0x5412;
}

function maskBit(mask, r, c) {
  switch (mask) {
    case 0:
      return (r + c) % 2 === 0;
    case 1:
      return r % 2 === 0;
    case 2:
      return c % 3 === 0;
    case 3:
      return (r + c) % 3 === 0;
    case 4:
      return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
    case 5:
      return ((r * c) % 2) + ((r * c) % 3) === 0;
    case 6:
      return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
    case 7:
      return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
    default:
      return false;
  }
}

function penaltyScore(modules, size) {
  let score = 0;
  // Rule 1: 5+ consecutive modules of same color in row/col
  for (let r = 0; r < size; r += 1) {
    let runColor = modules[r][0];
    let runLen = 1;
    for (let c = 1; c < size; c += 1) {
      if (modules[r][c] === runColor) {
        runLen += 1;
      } else {
        if (runLen >= 5) score += 3 + (runLen - 5);
        runColor = modules[r][c];
        runLen = 1;
      }
    }
    if (runLen >= 5) score += 3 + (runLen - 5);
  }
  for (let c = 0; c < size; c += 1) {
    let runColor = modules[0][c];
    let runLen = 1;
    for (let r = 1; r < size; r += 1) {
      if (modules[r][c] === runColor) {
        runLen += 1;
      } else {
        if (runLen >= 5) score += 3 + (runLen - 5);
        runColor = modules[r][c];
        runLen = 1;
      }
    }
    if (runLen >= 5) score += 3 + (runLen - 5);
  }
  // Rule 2: 2x2 blocks of same color
  for (let r = 0; r < size - 1; r += 1) {
    for (let c = 0; c < size - 1; c += 1) {
      const val = modules[r][c];
      if (
        modules[r][c + 1] === val &&
        modules[r + 1][c] === val &&
        modules[r + 1][c + 1] === val
      ) {
        score += 3;
      }
    }
  }
  return score;
}

export function generateQrMatrix(text) {
  const bytes = new TextEncoder().encode(String(text || ''));
  let version = 0;
  for (let v = 1; v < VERSION_SPECS.length; v += 1) {
    if (bytes.length + 2 <= VERSION_SPECS[v].totalData) {
      version = v;
      break;
    }
  }
  if (!version) {
    throw new Error('QR payload exceeds offline generator capacity (max 134 bytes).');
  }

  const spec = VERSION_SPECS[version];
  const size = spec.size;

  // Build bit stream: Byte mode (0100) + 8-bit count + bytes + terminator + pad
  const bits = [];
  const pushBits = (val, len) => {
    for (let i = len - 1; i >= 0; i -= 1) {
      bits.push((val >> i) & 1);
    }
  };
  pushBits(0b0100, 4);
  pushBits(bytes.length, 8);
  for (const b of bytes) pushBits(b, 8);

  const maxBits = spec.totalData * 8;
  const term = Math.min(4, maxBits - bits.length);
  pushBits(0, term);
  while (bits.length % 8 !== 0) bits.push(0);

  const dataCodewords = new Uint8Array(spec.totalData);
  for (let i = 0; i < bits.length / 8; i += 1) {
    let byte = 0;
    for (let b = 0; b < 8; b += 1) {
      byte = (byte << 1) | bits[i * 8 + b];
    }
    dataCodewords[i] = byte;
  }
  const pads = [0xec, 0x11];
  for (let i = bits.length / 8, p = 0; i < spec.totalData; i += 1, p += 1) {
    dataCodewords[i] = pads[p % 2];
  }

  // Split into blocks & compute Reed-Solomon EC
  const blockDataSize = spec.totalData / spec.blocks;
  const dataBlocks = [];
  const ecBlocks = [];
  for (let b = 0; b < spec.blocks; b += 1) {
    const slice = dataCodewords.slice(b * blockDataSize, (b + 1) * blockDataSize);
    dataBlocks.push(slice);
    ecBlocks.push(rsEncode(slice, spec.ecPerBlock));
  }

  const finalCodewords = [];
  for (let i = 0; i < blockDataSize; i += 1) {
    for (let b = 0; b < spec.blocks; b += 1) {
      finalCodewords.push(dataBlocks[b][i]);
    }
  }
  for (let i = 0; i < spec.ecPerBlock; i += 1) {
    for (let b = 0; b < spec.blocks; b += 1) {
      finalCodewords.push(ecBlocks[b][i]);
    }
  }

  const allBits = [];
  for (const cw of finalCodewords) {
    for (let i = 7; i >= 0; i -= 1) {
      allBits.push((cw >> i) & 1);
    }
  }
  // Remainder bits (7 for V2-V6)
  if (version >= 2) {
    for (let i = 0; i < 7; i += 1) allBits.push(0);
  }

  // Initialize matrix & reserved map
  const modules = Array.from({ length: size }, () => new Uint8Array(size));
  const reserved = Array.from({ length: size }, () => new Uint8Array(size));

  const setFunctionModule = (r, c, dark) => {
    if (r < 0 || r >= size || c < 0 || c >= size) return;
    modules[r][c] = dark ? 1 : 0;
    reserved[r][c] = 1;
  };

  // Finder patterns + separators
  const placeFinder = (topR, leftC) => {
    for (let dr = -1; dr <= 7; dr += 1) {
      for (let dc = -1; dc <= 7; dc += 1) {
        const r = topR + dr;
        const c = leftC + dc;
        if (r < 0 || r >= size || c < 0 || c >= size) continue;
        const inOuter = dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6;
        const onBorder = dr === 0 || dr === 6 || dc === 0 || dc === 6;
        const inInner = dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4;
        setFunctionModule(r, c, inOuter && (onBorder || inInner));
      }
    }
  };
  placeFinder(0, 0);
  placeFinder(0, size - 7);
  placeFinder(size - 7, 0);

  // Alignment patterns
  const alignCoords = spec.align;
  for (const ar of alignCoords) {
    for (const ac of alignCoords) {
      // Skip if overlapping finder pattern
      if (
        (ar <= 8 && ac <= 8) ||
        (ar <= 8 && ac >= size - 8) ||
        (ar >= size - 8 && ac <= 8)
      ) {
        continue;
      }
      for (let dr = -2; dr <= 2; dr += 1) {
        for (let dc = -2; dc <= 2; dc += 1) {
          const dark = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
          setFunctionModule(ar + dr, ac + dc, dark);
        }
      }
    }
  }

  // Timing patterns
  for (let i = 8; i < size - 8; i += 1) {
    const dark = i % 2 === 0;
    if (!reserved[6][i]) setFunctionModule(6, i, dark);
    if (!reserved[i][6]) setFunctionModule(i, 6, dark);
  }

  // Dark module & reserve format info slots
  setFunctionModule(size - 8, 8, true);
  for (let i = 0; i < 9; i += 1) {
    if (!reserved[8][i]) reserved[8][i] = 1;
    if (!reserved[i][8]) reserved[i][8] = 1;
  }
  for (let i = 0; i < 8; i += 1) {
    reserved[8][size - 1 - i] = 1;
    reserved[size - 1 - i][8] = 1;
  }

  // Place data bits in upward/downward 2-col zigzag
  let bitIdx = 0;
  let upward = true;
  for (let rightCol = size - 1; rightCol >= 1; rightCol -= 2) {
    if (rightCol === 6) rightCol = 5;
    for (let step = 0; step < size; step += 1) {
      const r = upward ? size - 1 - step : step;
      for (let dc = 0; dc < 2; dc += 1) {
        const c = rightCol - dc;
        if (!reserved[r][c]) {
          modules[r][c] = bitIdx < allBits.length ? allBits[bitIdx] : 0;
          bitIdx += 1;
        }
      }
    }
    upward = !upward;
  }

  const writeFormatBits = (grid, mask) => {
    const fmt = computeFormatBits(mask);
    const topCols = [0, 1, 2, 3, 4, 5, 7, 8];
    for (let i = 0; i < 8; i += 1) {
      grid[8][topCols[i]] = (fmt >> (14 - i)) & 1;
    }
    const leftRows = [7, 5, 4, 3, 2, 1, 0];
    for (let i = 0; i < 7; i += 1) {
      grid[leftRows[i]][8] = (fmt >> (6 - i)) & 1;
    }
    for (let i = 0; i < 7; i += 1) {
      grid[size - 1 - i][8] = (fmt >> (14 - i)) & 1;
    }
    for (let i = 0; i < 8; i += 1) {
      grid[8][size - 8 + i] = (fmt >> (7 - i)) & 1;
    }
  };

  // Pick best mask pattern (0..7)
  let bestGrid = null;
  let bestScore = Infinity;
  for (let mask = 0; mask < 8; mask += 1) {
    const candidate = modules.map((row) => new Uint8Array(row));
    for (let r = 0; r < size; r += 1) {
      for (let c = 0; c < size; c += 1) {
        if (!reserved[r][c] && maskBit(mask, r, c)) {
          candidate[r][c] ^= 1;
        }
      }
    }
    writeFormatBits(candidate, mask);
    const sc = penaltyScore(candidate, size);
    if (sc < bestScore) {
      bestScore = sc;
      bestGrid = candidate;
    }
  }

  return { size, version, modules: bestGrid };
}

export function renderQrSvg(text, options = {}) {
  const { size, modules } = generateQrMatrix(text);
  const margin = options.margin ?? 3;
  const total = size + margin * 2;
  const fg = options.fg || '#1F1B16';
  const bg = options.bg || '#F6F1E7';

  let pathData = '';
  for (let r = 0; r < size; r += 1) {
    for (let c = 0; c < size; c += 1) {
      if (modules[r][c]) {
        pathData += `M${c + margin} ${r + margin}h1v1h-1z`;
      }
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" shape-rendering="crispEdges" role="img" aria-label="Circle invite QR code"><rect width="${total}" height="${total}" rx="2.5" fill="${bg}"/><path d="${pathData}" fill="${fg}"/></svg>`;
}

export function renderInviteQrSvg(inviteUrl, fallbackCode = '', options = {}) {
  try {
    return renderQrSvg(inviteUrl, options);
  } catch (err) {
    if (fallbackCode) {
      return renderQrSvg(fallbackCode, options);
    }
    throw err;
  }
}
