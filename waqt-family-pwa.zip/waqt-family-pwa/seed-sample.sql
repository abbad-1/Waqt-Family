-- Optional sample seed data for local D1 testing (Al-Mansoor Family across 6 time zones)
-- Default recovery PIN for all seeded family members: 2468
-- Usage: npx wrangler d1 execute waqt-family-db --local --file=./seed-sample.sql

INSERT OR IGNORE INTO users (
  uid, display_name, pin_hash, pin_salt, phone, facetime_id, city, country, lat, lon, tz,
  method, asr_method, high_latitude_rule, remind_offset_minutes,
  share_status, show_city, circle_reminders, quiet_until_ms, evening_summary,
  character_style, preferred_character, created_at_ms
) VALUES
  ('uid_you',    'Yusuf',  '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+971501234567', '+971501234567',      'Abu Dhabi', 'UAE',     24.4539,  54.3773, 'Asia/Dubai',      'Dubai',             'standard', 'auto', 0,  1, 1, 1, NULL, 1, 'characters', 'teta',   1710000000000),
  ('uid_mama',   'Mama',   '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+971509876543', '+971509876543',      'Abu Dhabi', 'UAE',     24.4539,  54.3773, 'Asia/Dubai',      'Dubai',             'standard', 'auto', 0,  1, 1, 1, NULL, 1, 'characters', 'teta',   1710000001000),
  ('uid_ahmed',  'Ahmed',  '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+353871234567', '+353871234567',      'Dublin',    'Ireland', 53.3498,  -6.2603, 'Europe/Dublin',   'MuslimWorldLeague', 'standard', 'auto', 10, 1, 1, 1, NULL, 0, 'characters', 'sami',   1710000002000),
  ('uid_teta',   'Teta',   '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+201001234567', '',                   'Cairo',     'Egypt',   30.0444,  31.2357, 'Africa/Cairo',    'Egyptian',          'standard', 'auto', 0,  1, 1, 1, NULL, 1, 'characters', 'teta',   1710000003000),
  ('uid_khalid', 'Khalid', '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+14165550199',  'khalid@example.com', 'Toronto',   'Canada',  43.6532, -79.3832, 'America/Toronto', 'NorthAmerica',      'standard', 'auto', 5,  1, 1, 1, NULL, 0, 'symbols',    'hilal',  1710000004000),
  ('uid_layla',  'Layla',  '1dbc3bf1f4e80e39c60efbca00a871fb1f5f72d82d746023ec9f8d46d5549d32', 'salt_seed_family', '+447700900123', '+447700900123',      'London',    'UK',      51.5074,  -0.1278, 'Europe/London',   'MuslimWorldLeague', 'standard', 'auto', 0,  0, 1, 1, NULL, 0, 'symbols',    'fanous', 1710000005000);

INSERT OR IGNORE INTO circles (circle_id, name, owner_uid, invite_code, created_at_ms)
VALUES ('cir_almansoor', 'Al-Mansoor Family', 'uid_you', 'FAM-4821', 1710000000000);

INSERT OR IGNORE INTO circle_members (circle_id, uid, joined_at_ms) VALUES
  ('cir_almansoor', 'uid_you',    1710000000000),
  ('cir_almansoor', 'uid_mama',   1710000001000),
  ('cir_almansoor', 'uid_ahmed',  1710000002000),
  ('cir_almansoor', 'uid_teta',   1710000003000),
  ('cir_almansoor', 'uid_khalid', 1710000004000),
  ('cir_almansoor', 'uid_layla',  1710000005000);

INSERT OR IGNORE INTO messages (message_id, circle_id, from_uid, to_uid, kind, prayer, body, created_at_ms) VALUES
  ('msg_seed_1', 'cir_almansoor', 'uid_mama',  'uid_ahmed', 'text', NULL, 'Habibi, hope Dublin is treating you well today. Don''t forget your prayer between lectures!', 1710000010000),
  ('msg_seed_2', 'cir_almansoor', 'uid_ahmed', 'uid_mama',  'text', NULL, 'Shukran Mama, heading to the prayer room right now!', 1710000020000);
