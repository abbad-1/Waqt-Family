// Comprehensive automated test suite for Waqt Family PWA (Option A: Card-Free Stack)
// Covers:
//   1. Asset parity & HTML/JS DOM ID integrity across all 8 screens
//   2. All 126 cities IANA timezone accuracy, longitude plausibility, DST vs non-DST, Haversine nearestCity
//   3. Astronomical prayer engine (12 presets, Hanafi Asr, Umm al-Qura 120m Ramadan Isha, high-latitude summer solstice, after-midnight rollover, DST)
//   4. Native VAPID ES256 JWT + RFC 8291 aes128gcm Web Push encryption/decryption round-trip & 410 cleanup
//   5. Worker API + Privacy + Cross-timezone Nudges + Cron Scheduler against REAL SQLite (D1WaqtStore)
//   6. 1-tap WhatsApp & FaceTime deep-link builder
//   7. Live HTTP server E2E test (static assets + onboarding + circle join)

import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  PRAYERS,
  METHOD_PRESETS,
  validateTimeZone,
  resolveHighLatitudeRule,
  localDateString,
  timesForDate,
  nextPrayer,
  nextReminderSchedule,
  currentPrayerWindow,
  formatTimeInZone,
  formatDuration,
  endOfLocalDayUtc,
  nearestCity,
} from '../shared/prayer-engine.mjs';
import {
  getWebCrypto,
  base64UrlEncode,
  base64UrlDecode,
  generateVapidKeys,
  createVapidAuthHeader,
  encryptWebPushPayload,
  decryptWebPushPayload,
  normalizeVapidSubject,
} from '../worker/webpush.mjs';
import { D1WaqtStore } from '../worker/store-d1.mjs';
import { MemoryWaqtStore } from '../worker/store-memory.mjs';
import { handleApiRequest, runPrayerCron } from '../worker/index.mjs';
import { buildCallShortcuts, revalidateCachedLiveState } from '../public/app.js';
import { generateQrMatrix, renderQrSvg, renderInviteQrSvg } from '../shared/qr-svg.mjs';
import { runPrayerVerification } from '../scripts/verify-prayers.mjs';
import { startLocalServer } from '../scripts/local-dev-server.mjs';
import { SqliteD1Database } from './sqlite-d1-shim.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const webcrypto = getWebCrypto();

// Helper: create a simulated browser PushSubscription with real ECDH P-256 keys
async function createMockBrowserPushSubscription(endpointUrl = 'https://web.push.apple.com/QTEST_DEVICE_1') {
  const keyPair = await webcrypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits']
  );
  const pubRaw = new Uint8Array(await webcrypto.subtle.exportKey('raw', keyPair.publicKey));
  const privJwk = await webcrypto.subtle.exportKey('jwk', keyPair.privateKey);
  const authBytes = webcrypto.getRandomValues(new Uint8Array(16));

  return {
    subscription: {
      endpoint: endpointUrl,
      keys: {
        p256dh: base64UrlEncode(pubRaw),
        auth: base64UrlEncode(authBytes),
      },
    },
    privateJwk: privJwk,
    publicKeyBytes: pubRaw,
    authSecretBytes: authBytes,
  };
}

// ============================================================================
// 1. ASSET PARITY & DOM INTEGRITY ACROSS ALL 8 UI SCREENS
// ============================================================================

test('Static module copies and cities JSON are byte-identical and all app.js DOM IDs exist in index.html', async () => {
  const [sharedEngine, publicEngine, sharedQr, publicQr, publicCities, dataCities, indexHtml, appJs] = await Promise.all([
    fs.readFile(path.join(ROOT, 'shared/prayer-engine.mjs'), 'utf8'),
    fs.readFile(path.join(ROOT, 'public/prayer-engine.js'), 'utf8'),
    fs.readFile(path.join(ROOT, 'shared/qr-svg.mjs'), 'utf8'),
    fs.readFile(path.join(ROOT, 'public/qr-svg.js'), 'utf8'),
    fs.readFile(path.join(ROOT, 'public/cities.json'), 'utf8'),
    fs.readFile(path.join(ROOT, 'data/cities.json'), 'utf8'),
    fs.readFile(path.join(ROOT, 'public/index.html'), 'utf8'),
    fs.readFile(path.join(ROOT, 'public/app.js'), 'utf8'),
  ]);

  assert.equal(publicEngine, sharedEngine, 'public/prayer-engine.js must match shared/prayer-engine.mjs');
  assert.equal(publicQr, sharedQr, 'public/qr-svg.js must match shared/qr-svg.mjs');
  assert.equal(publicCities, dataCities, 'public/cities.json must match data/cities.json');

  // Collect every id="..." defined in public/index.html
  const htmlIds = new Set();
  for (const m of indexHtml.matchAll(/\bid="([^"]+)"/g)) {
    htmlIds.add(m[1]);
  }

  // Verify all 8 core UI screens + sheets exist
  const requiredScreens = [
    'screen-welcome',
    'authenticated-shell',
    'view-home',
    'view-circle',
    'view-chat',
    'view-characters',
    'view-settings',
    'sheet-nudge',
    'overlay-reminder',
    'sheet-call',
    'sheet-Dynamic',
  ];
  for (const screenId of requiredScreens) {
    assert.ok(htmlIds.has(screenId), `Missing required screen/sheet #${screenId} in public/index.html`);
  }

  // Every literal $('...') call in public/app.js must correspond to a real id="..." in public/index.html!
  const missingIds = [];
  for (const m of appJs.matchAll(/\$\(\s*['"]([^'"]+)['"]\s*\)/g)) {
    const id = m[1];
    if (!htmlIds.has(id)) missingIds.push(id);
  }
  assert.deepEqual(missingIds, [], `app.js references missing HTML IDs: ${missingIds.join(', ')}`);
});

// ============================================================================
// 2. 126 CITIES & IANA TIMEZONES
// ============================================================================

test('All 126 cities have valid IANA time zones, country defaults, and accurate multi-zone country mappings', async () => {
  const citiesDoc = JSON.parse(await fs.readFile(path.join(ROOT, 'public/cities.json'), 'utf8'));
  const methodsDoc = JSON.parse(await fs.readFile(path.join(ROOT, 'public/prayer-methods.json'), 'utf8'));
  const cities = citiesDoc.cities;
  assert.equal(cities.length, 126, 'Expected all 126 world cities');
  assert.equal(citiesDoc.count, 126);

  for (const c of cities) {
    assert.ok(c.name && typeof c.name === 'string');
    assert.ok(c.country && typeof c.country === 'string');
    assert.ok(Number.isFinite(c.lat) && c.lat >= -90 && c.lat <= 90);
    assert.ok(Number.isFinite(c.lon) && c.lon >= -180 && c.lon <= 180);
    assert.ok(c.tz && validateTimeZone(c.tz), `Invalid IANA tz for ${c.name}: ${c.tz}`);
    const def = methodsDoc.defaultsByCountry[c.country] || methodsDoc.defaultsByCountry.default;
    assert.ok(METHOD_PRESETS[def.method], `Unknown calculation preset for ${c.name}: ${def.method}`);
  }

  const byCity = Object.fromEntries(cities.map((c) => [c.name, c]));
  assert.equal(byCity['Abu Dhabi'].tz, 'Asia/Dubai');
  assert.equal(byCity['Dublin'].tz, 'Europe/Dublin');
  assert.equal(byCity['Phoenix'].tz, 'America/Phoenix');
  assert.equal(byCity['New York'].tz, 'America/New_York');
  assert.equal(byCity['Chicago'].tz, 'America/Chicago');
  assert.equal(byCity['Los Angeles'].tz, 'America/Los_Angeles');
  assert.equal(byCity['Calgary'].tz, 'America/Edmonton');
  assert.equal(byCity['Vancouver'].tz, 'America/Vancouver');
  assert.equal(byCity['Hong Kong'].tz, 'Asia/Hong_Kong');
  assert.equal(byCity['Perth'].tz, 'Australia/Perth');
  assert.equal(byCity['Sydney'].tz, 'Australia/Sydney');

  // Verify Phoenix has NO DST shift between Jan 15 and Jul 15 (stays UTC-7)
  const phxWinter = formatTimeInZone(new Date('2026-01-15T19:00:00Z'), byCity['Phoenix'].tz);
  const phxSummer = formatTimeInZone(new Date('2026-07-15T19:00:00Z'), byCity['Phoenix'].tz);
  assert.equal(phxWinter, phxSummer, 'America/Phoenix must not observe DST');

  // Nearest-city Haversine matching
  const nearAbuDhabi = nearestCity(24.47, 54.36, cities);
  assert.equal(nearAbuDhabi.city.name, 'Abu Dhabi');
  assert.ok(nearAbuDhabi.distanceKm < 10);
  assert.equal(nearestCity(0, 0, []), null);
});

// ============================================================================
// 3. ASTRONOMICAL PRAYER ENGINE & EDGE CASES
// ============================================================================

test('9+ validation cities across 12 solstice/equinox/DST/Ramadan dates pass strict monotonicity', async () => {
  const { checks } = await runPrayerVerification({ quiet: true });
  assert.equal(checks, 132);
});

test('All 12 regional presets, Hanafi Asr shift, and Umm al-Qura 120m Ramadan Isha rule work accurately', () => {
  // Every preset produces 5 valid monotonic prayers
  for (const method of Object.keys(METHOD_PRESETS)) {
    const sched = timesForDate(
      { lat: 24.4539, lon: 54.3773, tz: 'Asia/Dubai', method, asrMethod: 'standard' },
      '2026-04-15'
    );
    assert.ok(sched.Fajr < sched.Sunrise && sched.Sunrise < sched.Dhuhr);
    assert.ok(sched.Dhuhr < sched.Asr && sched.Asr < sched.Maghrib && sched.Maghrib < sched.Isha);
  }

  // Hanafi Asr vs Standard Asr in Karachi
  const karachiStd = timesForDate(
    { lat: 24.8607, lon: 67.0011, tz: 'Asia/Karachi', method: 'Karachi', asrMethod: 'standard' },
    '2026-05-10'
  );
  const karachiHanafi = timesForDate(
    { lat: 24.8607, lon: 67.0011, tz: 'Asia/Karachi', method: 'Karachi', asrMethod: 'hanafi' },
    '2026-05-10'
  );
  const diffMin = (karachiHanafi.Asr.getTime() - karachiStd.Asr.getTime()) / 60000;
  assert.ok(diffMin >= 35 && diffMin <= 75, `Expected Hanafi Asr 35-75m later, got ${diffMin}m`);

  // Umm al-Qura: 120m Isha interval during Ramadan vs 90m outside Ramadan
  const meccaRamadan = timesForDate(
    { lat: 21.3891, lon: 39.8579, tz: 'Asia/Riyadh', method: 'UmmAlQura' },
    '2026-03-01' // 12 Ramadan 1447 AH
  );
  const meccaNonRamadan = timesForDate(
    { lat: 21.3891, lon: 39.8579, tz: 'Asia/Riyadh', method: 'UmmAlQura' },
    '2026-06-21' // Muharram 1448 AH
  );
  assert.equal((meccaRamadan.Isha.getTime() - meccaRamadan.Maghrib.getTime()) / 60000, 120);
  assert.equal((meccaNonRamadan.Isha.getTime() - meccaNonRamadan.Maghrib.getTime()) / 60000, 90);
});

test('High-latitude summer solstice (>50°N to 69.6°N) & after-midnight Isha rollover never produce NaN or 0-min windows', () => {
  const northernCities = [
    { name: 'London', lat: 51.5074, lon: -0.1278, tz: 'Europe/London' },
    { name: 'Dublin', lat: 53.3498, lon: -6.2603, tz: 'Europe/Dublin' },
    { name: 'Stockholm', lat: 59.3293, lon: 18.0686, tz: 'Europe/Stockholm' },
    { name: 'Oslo', lat: 59.9139, lon: 10.7522, tz: 'Europe/Oslo' },
    { name: 'Helsinki', lat: 60.1699, lon: 24.9384, tz: 'Europe/Helsinki' },
    { name: 'Tromso', lat: 69.6492, lon: 18.9553, tz: 'Europe/Oslo' },
  ];

  const extraCities = [
    ...northernCities,
    { name: 'Reykjavik', lat: 64.1466, lon: -21.9426, tz: 'Atlantic/Reykjavik' },
  ];
  assert.equal(resolveHighLatitudeRule(51.5074, 'auto'), 'seventhOfTheNight');
  assert.equal(resolveHighLatitudeRule(24.4539, 'auto'), 'middleOfTheNight');

  for (const c of extraCities) {
    for (const method of Object.keys(METHOD_PRESETS)) {
      for (const highLatitudeRule of ['auto', 'middleOfTheNight', 'seventhOfTheNight', 'twilightAngle']) {
        const user = { ...c, method, asrMethod: 'standard', highLatitudeRule };
        for (const [d1, d2] of [['2026-06-21', '2026-06-22'], ['2026-12-21', '2026-12-22']]) {
          const t1 = timesForDate(user, d1);
          const t2 = timesForDate(user, d2);
          const seq = [t1.Fajr, t1.Sunrise, t1.Dhuhr, t1.Asr, t1.Maghrib, t1.Isha, t2.Fajr];
          for (let i = 0; i < seq.length - 1; i += 1) {
            assert.ok(
              !Number.isNaN(seq[i].getTime()) && seq[i] < seq[i + 1],
              `Schedule inversion in ${c.name} (${method}, ${highLatitudeRule}, ${d1}) step ${i}: ${seq[i]} >= ${seq[i + 1]}`
            );
          }
          if (method === 'MuslimWorldLeague' && d1 === '2026-06-21' && c.lat < 65 && (highLatitudeRule === 'auto' || highLatitudeRule === 'seventhOfTheNight')) {
            assert.ok(
              t2.Fajr.getTime() - t1.Isha.getTime() >= 25 * 60000,
              `Seventh-of-night window >=25m in ${c.name} (${highLatitudeRule})`
            );
          }
        }
      }
    }
  }

  // London May 20: astronomical -17 deg Isha (~23:53 BST) must NOT be prematurely clamped under middleOfTheNight
  const londonMid = timesForDate(
    { lat: 51.5074, lon: -0.1278, tz: 'Europe/London', method: 'MuslimWorldLeague', asrMethod: 'standard', highLatitudeRule: 'middleOfTheNight' },
    '2026-05-20'
  );
  const londonIshaStr = londonMid.Isha.toLocaleTimeString('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit' });
  assert.ok(londonIshaStr >= '23:50', `Expected astronomical London Isha >= 23:50 on May 20, got ${londonIshaStr}`);

  // After-midnight before-Fajr rollover: 01:30 UTC in Dublin on 2026-01-15 (Fajr is ~06:25)
  const dublinUser = {
    lat: 53.3498,
    lon: -6.2603,
    tz: 'Europe/Dublin',
    method: 'MuslimWorldLeague',
    asrMethod: 'standard',
    highLatitudeRule: 'middleOfTheNight',
  };
  const win = currentPrayerWindow(dublinUser, new Date('2026-01-15T01:30:00Z'));
  assert.equal(win.name, 'Isha');
  assert.equal(win.date, '2026-01-14', 'Before Fajr, active Isha window belongs to yesterday');
  assert.equal(win.todayDate, '2026-01-15');
  assert.equal(win.nextName, 'Fajr');

  // Lead-time scheduling (`remindOffsetMinutes: 10` vs `-1` Off)
  const rem = nextReminderSchedule({ ...dublinUser, remindOffsetMinutes: 10 }, new Date('2026-01-15T01:30:00Z'));
  assert.equal(rem.name, 'Fajr');
  assert.equal(rem.prayerAt.getTime() - rem.at.getTime(), 10 * 60000);
  assert.equal(nextReminderSchedule({ ...dublinUser, remindOffsetMinutes: -1 }, new Date()), null);
  assert.equal(formatDuration(92 * 60000), '1h 32m');
});

// ============================================================================
// 4. STANDARDS-BASED VAPID ES256 + RFC 8291 AES128GCM WEB PUSH CRYPTO
// ============================================================================

test('VAPID ES256 JWT verifies cryptographically and RFC 8291 aes128gcm encrypts & decrypts UTF-8/Arabic payloads', async () => {
  const vapidKeys = await generateVapidKeys();
  const pubBytes = base64UrlDecode(vapidKeys.publicKey);
  const privBytes = base64UrlDecode(vapidKeys.privateKey);
  assert.equal(pubBytes.length, 65);
  assert.equal(pubBytes[0], 0x04);
  assert.equal(privBytes.length, 32);

  // Verify ES256 JWT signature via Web Crypto
  const { authorization } = await createVapidAuthHeader(
    'https://fcm.googleapis.com/fcm/send/abc123',
    vapidKeys.publicKey,
    vapidKeys.privateKey,
    'mailto:family@waqt.local'
  );
  const match = authorization.match(/^vapid t=([^,]+), k=(.+)$/);
  assert.ok(match, 'Malformed VAPID Authorization header');
  const [hB64, pB64, sB64] = match[1].split('.');
  const verifyKey = await webcrypto.subtle.importKey(
    'raw',
    pubBytes,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['verify']
  );
  const sigValid = await webcrypto.subtle.verify(
    { name: 'ECDSA', hash: 'SHA-256' },
    verifyKey,
    base64UrlDecode(sB64),
    new TextEncoder().encode(`${hB64}.${pB64}`)
  );
  assert.equal(sigValid, true, 'VAPID JWT ES256 signature must verify');
  const claims = JSON.parse(new TextDecoder().decode(base64UrlDecode(pB64)));
  assert.equal(claims.aud, 'https://fcm.googleapis.com');
  assert.equal(claims.sub, 'mailto:family@waqt.app'); // .local normalized for Apple Push compatibility

  // Encrypt & decrypt Web Push payload with Arabic + emoji + metadata
  const mockSub = await createMockBrowserPushSubscription();
  const payloadObj = {
    type: 'nudge',
    title: 'Waqt · وقت',
    body: 'Mama and Teta are thinking of you for العصر — "Habibi, have you prayed yet?"',
    prayer: 'Asr',
    date: '2026-03-20',
  };
  const plaintext = JSON.stringify(payloadObj);
  const ciphertext = await encryptWebPushPayload(plaintext, mockSub.subscription);
  assert.ok(ciphertext.length > plaintext.length + 86);

  const decrypted = await decryptWebPushPayload(
    ciphertext,
    mockSub.privateJwk,
    mockSub.publicKeyBytes,
    mockSub.authSecretBytes
  );
  assert.deepEqual(JSON.parse(decrypted), payloadObj);

  // Reject oversized payloads (>3800 bytes)
  await assert.rejects(
    () => encryptWebPushPayload('x'.repeat(4000), mockSub.subscription),
    /exceeds 3800 bytes/
  );
});

// ============================================================================
// 5. FULL WORKER API, PRIVACY, CROSS-TZ NUDGES & CRON ON REAL SQLITE (D1)
// ============================================================================

test('Full family lifecycle on REAL SQLite (D1WaqtStore): PIN auth, cross-TZ nudges, grouping, quiet mode, privacy, snooze & cron', async (t) => {
  const sqliteDb = new SqliteD1Database();
  t.after(() => sqliteDb.close());

  const schemaSql = await fs.readFile(path.join(ROOT, 'schema.sql'), 'utf8');
  await sqliteDb.exec(schemaSql);

  const store = new D1WaqtStore(sqliteDb);
  const vapid = await generateVapidKeys();
  const env = {
    DB: sqliteDb,
    VAPID_PUBLIC_KEY: vapid.publicKey,
    VAPID_PRIVATE_KEY: vapid.privateKey,
    VAPID_SUBJECT: 'mailto:family@waqt.local',
    FAMILY_ACCESS_CODE: 'habibi',
  };

  // Capture outgoing encrypted Web Push requests and decrypt them per device!
  const deviceSubs = new Map();
  const deliveredPushes = [];
  const deadEndpoints = new Set();

  const mockFetch = async (url, init) => {
    if (deadEndpoints.has(url)) {
      return new Response('Gone', { status: 410 });
    }
    const dev = deviceSubs.get(url);
    assert.ok(dev, `Unexpected push endpoint ${url}`);
    assert.equal(init.headers['Content-Encoding'], 'aes128gcm');
    assert.ok(init.headers.Authorization.startsWith('vapid t='));
    const decryptedJson = await decryptWebPushPayload(
      new Uint8Array(init.body),
      dev.privateJwk,
      dev.publicKeyBytes,
      dev.authSecretBytes
    );
    deliveredPushes.push({ endpoint: url, uid: dev.uid, payload: JSON.parse(decryptedJson) });
    return new Response('', { status: 201 });
  };

  let currentNow = new Date('2026-03-20T14:40:00Z'); // 18:40 in Abu Dhabi (Maghrib), 14:40 in Dublin (Dhuhr)

  const api = async (method, route, body = null, token = null) => {
    const headers = {};
    if (body !== null) headers['Content-Type'] = 'application/json';
    if (token) headers.Authorization = `Bearer ${token}`;
    const req = new Request(`https://waqt.family${route}`, {
      method,
      headers,
      body: body !== null ? JSON.stringify(body) : undefined,
    });
    const res = await handleApiRequest(req, env, { store, now: currentNow, fetchImpl: mockFetch });
    const data = await res.json();
    return { status: res.status, data };
  };

  // 5a. Access code gate check
  const blockedReg = await api('POST', '/api/auth/register', {
    displayName: 'Stranger',
    city: 'London',
    country: 'United Kingdom',
    lat: 51.5074,
    lon: -0.1278,
    tz: 'Europe/London',
    accessCode: 'wrong',
  });
  assert.equal(blockedReg.status, 403);

  // 5b. Register Mama (Abu Dhabi, UTC+4, PIN 2468), Ahmed (Dublin, UTC+0), Teta (Cairo, UTC+2), Layla (London, private)
  const mamaReg = await api('POST', '/api/auth/register', {
    displayName: 'Mama',
    city: 'Abu Dhabi',
    country: 'United Arab Emirates',
    lat: 24.4539,
    lon: 54.3773,
    tz: 'Asia/Dubai',
    method: 'Dubai',
    pin: '2468',
    phone: '+971509876543',
    circleName: 'Al-Mansoor Family',
    accessCode: 'habibi',
  });
  assert.equal(mamaReg.status, 201);
  const mamaToken = mamaReg.data.token;
  const mamaUid = mamaReg.data.state.me.uid;
  const inviteCode = mamaReg.data.state.circles[0].inviteCode;
  const circleId = mamaReg.data.state.circles[0].circleId;

  // Test PIN login for Mama (wrong PIN -> 401, right PIN -> 200)
  const badLogin = await api('POST', '/api/auth/login', { displayName: 'Mama', pin: '0000' });
  assert.equal(badLogin.status, 401);
  const okLogin = await api('POST', '/api/auth/login', { displayName: 'Mama', pin: '2468' });
  assert.equal(okLogin.status, 200);
  assert.ok(okLogin.data.token);

  const ahmedReg = await api('POST', '/api/auth/register', {
    displayName: 'Ahmed',
    city: 'Dublin',
    country: 'Ireland',
    lat: 53.3498,
    lon: -6.2603,
    tz: 'Europe/Dublin',
    method: 'MuslimWorldLeague',
    inviteCode,
    accessCode: 'habibi',
  });
  assert.equal(ahmedReg.status, 201);
  const ahmedToken = ahmedReg.data.token;
  const ahmedUid = ahmedReg.data.state.me.uid;

  const tetaReg = await api('POST', '/api/auth/register', {
    displayName: 'Teta',
    city: 'Cairo',
    country: 'Egypt',
    lat: 30.0444,
    lon: 31.2357,
    tz: 'Africa/Cairo',
    method: 'Egyptian',
    inviteCode,
    accessCode: 'habibi',
  });
  assert.equal(tetaReg.status, 201);
  const tetaToken = tetaReg.data.token;

  const laylaReg = await api('POST', '/api/auth/register', {
    displayName: 'Layla',
    city: 'London',
    country: 'United Kingdom',
    lat: 51.5074,
    lon: -0.1278,
    tz: 'Europe/London',
    method: 'MuslimWorldLeague',
    inviteCode,
    accessCode: 'habibi',
  });
  assert.equal(laylaReg.status, 201);
  const laylaToken = laylaReg.data.token;
  const laylaUid = laylaReg.data.state.me.uid;

  // Turn Layla's shareStatus=false and showCity=false
  const laylaPriv = await api('PATCH', '/api/me', { shareStatus: false, showCity: false }, laylaToken);
  assert.equal(laylaPriv.status, 200);

  // Register Web Push subscriptions for Mama, Ahmed, Teta, plus a stale endpoint for Ahmed
  for (const [uid, token, ep] of [
    [mamaUid, mamaToken, 'https://web.push.apple.com/MAMA_1'],
    [ahmedUid, ahmedToken, 'https://web.push.apple.com/AHMED_1'],
    [ahmedUid, ahmedToken, 'https://web.push.apple.com/AHMED_DEAD'],
    [tetaReg.data.state.me.uid, tetaToken, 'https://web.push.apple.com/TETA_1'],
  ]) {
    const sub = await createMockBrowserPushSubscription(ep);
    deviceSubs.set(ep, { ...sub, uid });
    const subRes = await api('POST', '/api/push/subscribe', { subscription: sub.subscription }, token);
    assert.equal(subRes.status, 200);
  }
  deadEndpoints.add('https://web.push.apple.com/AHMED_DEAD');

  // 5c. Verify privacy serialization on Mama's /api/state
  const mamaState = await api('GET', '/api/state', null, mamaToken);
  assert.equal(mamaState.data.state.me.currentWindow.name, 'Maghrib'); // 18:40 in Abu Dhabi
  const circleMembers = mamaState.data.state.circles[0].members;
  const laylaView = circleMembers.find((m) => m.uid === laylaUid);
  assert.equal(laylaView.isPrivate, true);
  assert.equal(laylaView.prayerLog, null, 'Private member prayerLog must never leak');
  assert.equal(laylaView.currentPrayer.prayed, null);
  assert.equal(laylaView.city, null, 'showCity=false must hide city');
  assert.equal(laylaView.country, null, 'showCity=false must hide country');
  assert.equal(laylaView.tz, null, 'showCity=false must hide tz');
  assert.equal(laylaView.localTimeFormatted, null, 'showCity=false must hide localTimeFormatted to prevent timezone leak');
  assert.equal(laylaView.currentPrayer.startFormatted, null, 'showCity=false must hide startFormatted');
  assert.equal(laylaView.currentPrayer.endFormatted, null, 'showCity=false must hide endFormatted');
  assert.equal(laylaView.currentPrayer.nextStartFormatted, null, 'showCity=false must hide nextStartFormatted');
  assert.equal(laylaView.alreadyNudgedByMe, false);

  // Pinless login check: Ahmed registered without a PIN -> 401 no_pin_set
  const pinlessLogin = await api('POST', '/api/auth/login', { displayName: 'Ahmed', pin: '1234' });
  assert.equal(pinlessLogin.status, 401);
  assert.equal(pinlessLogin.data.code, 'no_pin_set');

  // 5d. Cross-timezone Nudge + Rate Limiting + Multi-Sender Grouping + 410 Dead Sub Cleanup
  // Mama (in Maghrib) nudges Ahmed (in Dhuhr in Dublin!)
  const nudge1 = await api(
    'POST',
    '/api/nudges',
    { toUid: ahmedUid, circleId, characterId: 'teta' },
    mamaToken
  );
  assert.equal(nudge1.status, 200);
  assert.equal(nudge1.data.prayer, 'Dhuhr', 'Nudge must target recipient local prayer (Dhuhr), not sender Maghrib');
  const ahmedViewAfterNudge = nudge1.data.state.circles[0].members.find((m) => m.uid === ahmedUid);
  assert.equal(ahmedViewAfterNudge.alreadyNudgedByMe, true, 'alreadyNudgedByMe must be true after nudging');
  assert.equal(deliveredPushes.length, 1);
  assert.equal(deliveredPushes[0].uid, ahmedUid);
  assert.match(deliveredPushes[0].payload.body, /Mama is thinking of you for Dhuhr/);

  // Verify dead 410 subscription was automatically pruned from SQLite!
  const remainingAhmedSubs = await store.getPushSubscriptions(ahmedUid);
  assert.equal(remainingAhmedSubs.length, 1);
  assert.equal(remainingAhmedSubs[0].endpoint, 'https://web.push.apple.com/AHMED_1');

  // Mama tries to nudge Ahmed again for Dhuhr -> 409 rate limit
  const nudgeDup = await api(
    'POST',
    '/api/nudges',
    { toUid: ahmedUid, circleId, characterId: 'teta' },
    mamaToken
  );
  assert.equal(nudgeDup.status, 409);
  assert.equal(nudgeDup.data.code, 'already_nudged');

  // Teta also nudges Ahmed -> grouped notification with same tag
  const nudge2 = await api(
    'POST',
    '/api/nudges',
    { toUid: ahmedUid, circleId, characterId: 'jiddo' },
    tetaToken
  );
  assert.equal(nudge2.status, 200);
  assert.equal(deliveredPushes.length, 2);
  assert.equal(deliveredPushes[1].payload.tag, 'nudge-Dhuhr-2026-03-20');
  assert.match(deliveredPushes[1].payload.body, /Mama and Teta are thinking of you for Dhuhr/);

  // Ahmed sees grouped activeNudge on his state
  const ahmedState = await api('GET', '/api/state', null, ahmedToken);
  assert.equal(ahmedState.data.state.activeNudge.prayer, 'Dhuhr');
  assert.equal(ahmedState.data.state.activeNudge.summaryLine, 'Mama and Teta are thinking of you');

  // 5e. Quiet mode invisibility: Ahmed enables quietToday -> Layla nudges Ahmed -> 200 to Layla, 0 push to Ahmed!
  await api('PATCH', '/api/me', { quietToday: true }, ahmedToken);
  const pushesBeforeQuietNudge = deliveredPushes.length;
  const quietNudge = await api(
    'POST',
    '/api/nudges',
    { toUid: ahmedUid, circleId, characterId: 'fanous' },
    laylaToken
  );
  assert.equal(quietNudge.status, 200, 'Sender must not know recipient is in quiet mode');
  assert.equal(quietNudge.data.sent, true);
  assert.equal(deliveredPushes.length, pushesBeforeQuietNudge, 'Quiet mode must suppress push');
  await api('PATCH', '/api/me', { quietToday: false }, ahmedToken);

  // 5f. Privacy check on confirmation: Layla (shareStatus=false) confirms Dhuhr -> 0 push sent to circle
  const pushesBeforeLaylaConfirm = deliveredPushes.length;
  const laylaConfirm = await api('POST', '/api/prayers/confirm', { prayer: 'Dhuhr' }, laylaToken);
  assert.equal(laylaConfirm.status, 200);
  assert.equal(deliveredPushes.length, pushesBeforeLaylaConfirm, 'Private user confirmation must not notify circle');

  // Nudging Layla (shareStatus=false) after she already prayed Dhuhr must return 200 (never leaking private status!) while suppressing push
  const nudgePrivatePrayed = await api(
    'POST',
    '/api/nudges',
    { toUid: laylaUid, circleId, characterId: 'teta' },
    mamaToken
  );
  assert.equal(nudgePrivatePrayed.status, 200, 'Nudging private member who already prayed must not leak status via 409');
  assert.equal(deliveredPushes.length, pushesBeforeLaylaConfirm, 'Push to already-prayed private member must be suppressed');

  // Ahmed (shareStatus=true) confirms Dhuhr -> Mama and Teta receive "Ahmed prayed Dhuhr."
  const ahmedConfirm = await api('POST', '/api/prayers/confirm', { prayer: 'Dhuhr' }, ahmedToken);
  assert.equal(ahmedConfirm.status, 200);
  const confirmPushes = deliveredPushes.slice(pushesBeforeLaylaConfirm);
  assert.equal(confirmPushes.length, 2, 'Both nudgers (Mama & Teta) should receive confirmation push');
  assert.match(confirmPushes[0].payload.body, /^Ahmed prayed Dhuhr\.$/);

  // Nudging Ahmed (shareStatus=true) after he confirmed Dhuhr returns 409 already_prayed
  const thirdNudgerReg = await api('POST', '/api/auth/register', {
    displayName: 'Yusuf',
    city: 'Toronto',
    country: 'Canada',
    lat: 43.6532,
    lon: -79.3832,
    tz: 'America/Toronto',
    method: 'NorthAmerica',
    inviteCode,
    accessCode: 'habibi',
  });
  const nudgePublicPrayed = await api(
    'POST',
    '/api/nudges',
    { toUid: ahmedUid, circleId, characterId: 'sami' },
    thirdNudgerReg.data.token
  );
  assert.equal(nudgePublicPrayed.status, 409);
  assert.equal(nudgePublicPrayed.data.code, 'already_prayed');

  // Undo confirmation works cleanly
  const ahmedUndo = await api(
    'POST',
    '/api/prayers/confirm',
    { prayer: 'Dhuhr', undo: true },
    ahmedToken
  );
  assert.equal(ahmedUndo.status, 200);
  assert.equal(Boolean(ahmedUndo.data.state.me.activePrayerLog.Dhuhr), false);

  // 5g. 15-minute Snooze + Cron Scheduler (`runPrayerCron`)
  const snoozeRes = await api('POST', '/api/prayers/snooze', { prayer: 'Dhuhr' }, ahmedToken);
  assert.equal(snoozeRes.status, 200);

  // Advance clock 16 minutes -> snooze cron fires once, and does not double-fire
  currentNow = new Date(currentNow.getTime() + 16 * 60000);
  const cron1 = await runPrayerCron(env, { store, now: currentNow, fetchImpl: mockFetch });
  assert.equal(cron1.snoozeSent, 1);
  const cron1Repeat = await runPrayerCron(env, { store, now: currentNow, fetchImpl: mockFetch });
  assert.equal(cron1Repeat.snoozeSent, 0, 'Snooze must clear after firing once');

  // Personal prayer cron: jump to Ahmed's Asr reminder time and run cron
  const ahmedUser = await store.getUser(ahmedUid);
  currentNow = new Date(ahmedUser.nextPrayerAtMs + 10000);
  const cron2 = await runPrayerCron(env, { store, now: currentNow, fetchImpl: mockFetch });
  assert.ok(cron2.ownSent >= 1, 'Expected due personal prayer push to fire');
  const cron2Repeat = await runPrayerCron(
    env,
    { store, now: new Date(currentNow.getTime() + 20000), fetchImpl: mockFetch }
  );
  assert.equal(cron2Repeat.ownSent, 0, 'Cursor must advance so same prayer never double-fires');

  // Evening family summary cron (~48m after Mama's Maghrib when Mama opted into eveningSummary)
  await api('PATCH', '/api/me', { eveningSummary: true }, mamaToken);
  const mamaUser = await store.getUser(mamaUid);
  const mamaSched = timesForDate(mamaUser, '2026-03-20');
  await store.setPrayerConfirmed(mamaUid, '2026-03-20', 'Maghrib', mamaSched.Maghrib.getTime() + 5 * 60000);
  const summaryTime = new Date(mamaSched.Maghrib.getTime() + 48 * 60000);
  const cronSummary = await runPrayerCron(env, { store, now: summaryTime, fetchImpl: mockFetch });
  assert.equal(cronSummary.summariesSent, 1);
  const cronSummaryDup = await runPrayerCron(env, { store, now: summaryTime, fetchImpl: mockFetch });
  assert.equal(cronSummaryDup.summariesSent, 0, 'Evening summary must send at most once per local day');

  // 5h. 1:1 Family Chat & circle authorization
  const chatPost = await api(
    'POST',
    '/api/messages',
    { toUid: ahmedUid, circleId, body: 'Taqabbal Allah habibi!' },
    mamaToken
  );
  assert.equal(chatPost.status, 201);
  const chatGet = await api('GET', `/api/messages?peerUid=${mamaUid}`, null, ahmedToken);
  assert.equal(chatGet.status, 200);
  assert.ok(chatGet.data.messages.some((m) => m.body === 'Taqabbal Allah habibi!'));
});

// ============================================================================
// 6. 1-TAP WHATSAPP & FACETIME CALL SHORTCUTS
// ============================================================================

test('buildCallShortcuts generates clean WhatsApp wa.me, FaceTime Video/Audio, and tel: deep-links', () => {
  const links = buildCallShortcuts(
    {
      displayName: 'Ahmed',
      phone: '+353 (87) 123-4567',
      facetimeId: 'ahmed@icloud.com',
      currentPrayer: { name: 'Asr' },
    },
    'Mama'
  );
  assert.equal(links.hasSavedContact, true);
  assert.match(links.whatsappUrl, /^https:\/\/wa\.me\/353871234567\?text=/);
  assert.ok(decodeURIComponent(links.whatsappUrl).includes('checking in with love for Asr! — Mama'));
  assert.equal(links.facetimeVideoUrl, 'facetime://ahmed@icloud.com');
  assert.equal(links.facetimeAudioUrl, 'facetime-audio://ahmed@icloud.com');
  assert.equal(links.telUrl, 'tel:+353871234567');

  // 00-prefixed international phone without separate FaceTime ID
  const links00 = buildCallShortcuts({
    displayName: 'Teta',
    phone: '0020 100 123 4567',
    facetimeId: '',
    currentPrayer: { name: 'Maghrib' },
  });
  assert.match(links00.whatsappUrl, /^https:\/\/wa\.me\/201001234567\?text=/);
  assert.equal(links00.facetimeVideoUrl, 'facetime://00201001234567');

  // Unconfigured contact fallback
  const emptyLinks = buildCallShortcuts({ displayName: 'Khalid', phone: '', facetimeId: '' });
  assert.equal(emptyLinks.hasSavedContact, false);
  assert.match(emptyLinks.whatsappUrl, /^https:\/\/wa\.me\/\?text=/);
  assert.equal(emptyLinks.facetimeVideoUrl, null);
  assert.equal(emptyLinks.telUrl, null);
});

// ============================================================================
// 7. SEED-SAMPLE.SQL & CIRCLE CAPACITY / OWNERSHIP EDGE CASES
// ============================================================================

test('seed-sample.sql loads cleanly into SQLite and enforces 20-member cap, ownership transfer & empty cleanup', async (t) => {
  const sqliteDb = new SqliteD1Database();
  t.after(() => sqliteDb.close());

  const [schemaSql, seedSql] = await Promise.all([
    fs.readFile(path.join(ROOT, 'schema.sql'), 'utf8'),
    fs.readFile(path.join(ROOT, 'seed-sample.sql'), 'utf8'),
  ]);
  await sqliteDb.exec(schemaSql);
  await sqliteDb.exec(seedSql);

  const store = new D1WaqtStore(sqliteDb);
  const seeded = await store.getCircleByInviteCode('FAM-4821');
  assert.ok(seeded);
  assert.equal(seeded.name, 'Al-Mansoor Family');
  assert.equal(seeded.memberUids.length, 6);

  // Fill circle up to 20 members, then verify 21st registration is rejected with 409 circle_full
  for (let i = 7; i <= 20; i += 1) {
    const uid = `uid_extra_${i}`;
    await store.createUser({
      uid,
      displayName: `Cousin ${i}`,
      city: 'Amman',
      country: 'Jordan',
      lat: 31.9539,
      lon: 35.9106,
      tz: 'Asia/Amman',
      method: 'MuslimWorldLeague',
      asrMethod: 'standard',
      highLatitudeRule: 'middleOfTheNight',
      remindOffsetMinutes: 0,
      shareStatus: true,
      showCity: true,
      circleReminders: true,
      eveningSummary: false,
      createdAtMs: 1710000000000 + i * 1000,
    });
    await store.addCircleMember('cir_almansoor', uid, 1710000000000 + i * 1000);
  }

  const fullCircle = await store.getCircle('cir_almansoor');
  assert.equal(fullCircle.memberUids.length, 20);

  const reg21 = await handleApiRequest(
    new Request('https://waqt.family/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        displayName: 'Member 21',
        city: 'Amman',
        country: 'Jordan',
        lat: 31.9539,
        lon: 35.9106,
        tz: 'Asia/Amman',
        inviteCode: 'FAM-4821',
      }),
    }),
    { DB: sqliteDb },
    { store }
  );
  assert.equal(reg21.status, 409);

  // Owner leaving transfers ownership to next member; last member leaving deletes circle
  await store.createCircle({
    circleId: 'cir_temp',
    name: 'Temp Circle',
    ownerUid: 'uid_you',
    inviteCode: 'TMP-9999',
    createdAtMs: 1710000090000,
  });
  await store.addCircleMember('cir_temp', 'uid_mama', 1710000091000);
  await store.removeCircleMember('cir_temp', 'uid_you');
  const afterTransfer = await store.getCircle('cir_temp');
  assert.equal(afterTransfer.ownerUid, 'uid_mama', 'Ownership must transfer when owner leaves');
  await store.removeCircleMember('cir_temp', 'uid_mama');
  assert.equal(await store.getCircle('cir_temp'), null, 'Empty circle must be deleted');
});

// ============================================================================
// 8. LIVE LOCAL HTTP SERVER END-TO-END TEST
// ============================================================================

test('Local HTTP + API server serves PWA assets, manifest, service worker, and onboarding flow end-to-end', async (t) => {
  const srv = await startLocalServer({
    port: 0,
    seed: true,
    enableCron: false,
    disableKeepAlive: true,
    store: new MemoryWaqtStore(),
  });
  t.after(() => srv.close());

  const [htmlRes, swRes, manifestRes, cfgRes] = await Promise.all([
    fetch(`${srv.url}/`),
    fetch(`${srv.url}/sw.js`),
    fetch(`${srv.url}/manifest.webmanifest`),
    fetch(`${srv.url}/api/config`),
  ]);

  assert.equal(htmlRes.status, 200);
  const html = await htmlRes.text();
  assert.ok(html.includes('Waqt'));
  assert.equal(swRes.status, 200);
  assert.equal(manifestRes.status, 200);

  const cfg = await cfgRes.json();
  assert.equal(cfg.ok, true);
  assert.equal(cfg.mode, 'live');
  assert.ok(cfg.vapidPublicKey && cfg.vapidPublicKey.length > 40);

  // Join the pre-seeded Al-Mansoor Family circle (`FAM-4821`) over real HTTP
  const regRes = await fetch(`${srv.url}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      displayName: 'Yusuf',
      city: 'Abu Dhabi',
      country: 'United Arab Emirates',
      lat: 24.4539,
      lon: 54.3773,
      tz: 'Asia/Dubai',
      method: 'Dubai',
      inviteCode: 'FAM-4821',
    }),
  });
  assert.equal(regRes.status, 201);
  const regJson = await regRes.json();
  assert.equal(regJson.state.circles[0].name, 'Al-Mansoor Family');
  assert.equal(regJson.state.circles[0].members.length, 6);
});

test('Regression: Apple Web Push VAPID subject normalization, seed-sample NULL cron healing, snooze rollover safety, logout push cleanup & admin remove-member', async () => {
  // 0. Exhaustive astronomical monotonicity across all 12 presets x 7 high-latitude/polar cities x 4 rules
  const hiLatCities = [
    ["London", 51.5074, -0.1278, "Europe/London"],
    ["Dublin", 53.3498, -6.2603, "Europe/Dublin"],
    ["Stockholm", 59.3293, 18.0686, "Europe/Stockholm"],
    ["Oslo", 59.9139, 10.7522, "Europe/Oslo"],
    ["Helsinki", 60.1699, 24.9384, "Europe/Helsinki"],
    ["Reykjavik", 64.1466, -21.9426, "Atlantic/Reykjavik"],
    ["Tromso", 69.6492, 18.9553, "Europe/Oslo"],
  ];
  for (const [city, lat, lon, tz] of hiLatCities) {
    for (const method of Object.keys(METHOD_PRESETS)) {
      for (const highLatitudeRule of ["auto", "middleOfTheNight", "seventhOfTheNight", "twilightAngle"]) {
        for (const [d1, d2] of [["2026-06-21", "2026-06-22"], ["2026-12-21", "2026-12-22"]]) {
          const t1 = timesForDate({ lat, lon, tz, method, highLatitudeRule }, d1);
          const t2 = timesForDate({ lat, lon, tz, method, highLatitudeRule }, d2);
          const seq = [t1.Fajr, t1.Sunrise, t1.Dhuhr, t1.Asr, t1.Maghrib, t1.Isha, t2.Fajr].map((d) => d.getTime());
          for (let i = 0; i < seq.length - 1; i++) {
            assert.ok(
              Number.isFinite(seq[i]) && seq[i] < seq[i + 1],
              `Monotonicity failed for ${city} / ${method} / ${highLatitudeRule} on ${d1} at step ${i}`
            );
          }
        }
      }
    }
  }

  // 1. Apple Web Push rejects .local/.localhost pseudo-TLDs; normalizeVapidSubject sanitizes them
  assert.equal(normalizeVapidSubject('mailto:family@waqt.local'), 'mailto:family@waqt.app');
  assert.equal(normalizeVapidSubject('mailto:test@mybox.localhost'), 'mailto:family@waqt.app');
  assert.equal(normalizeVapidSubject('noor@example.com'), 'mailto:noor@example.com');
  assert.equal(normalizeVapidSubject('https://waqt-family.workers.dev'), 'https://waqt-family.workers.dev');
  assert.equal(normalizeVapidSubject('https://waqt.local'), 'mailto:family@waqt.app');

  // 2. Zero leaked internal paths anywhere in deliverable files
  const buildCitiesSrc = await fs.readFile(path.join(ROOT, 'scripts/build-cities.mjs'), 'utf8');
  assert.ok(!buildCitiesSrc.includes('/usr/local/google'), 'build-cities.mjs must not contain workstation paths');
  const stylesSrc = await fs.readFile(path.join(ROOT, 'public/styles.css'), 'utf8');
  assert.ok(!stylesSrc.includes('@import url('), 'styles.css must not use render-blocking @import');

  // 3. Seeded SQLite users with NULL next_prayer_at_ms self-heal on first cron tick without firing stale pushes
  const db = new SqliteD1Database();
  try {
    await db.exec(await fs.readFile(path.join(ROOT, 'schema.sql'), 'utf8'));
    await db.exec(await fs.readFile(path.join(ROOT, 'seed-sample.sql'), 'utf8'));
    const store = new D1WaqtStore(db);
    const keys = await generateVapidKeys();
    const env = { DB: db, VAPID_PUBLIC_KEY: keys.publicKey, VAPID_PRIVATE_KEY: keys.privateKey, VAPID_SUBJECT: 'mailto:family@waqt.local' };

    const beforeMama = await store.getUser('uid_mama');
    assert.equal(beforeMama.nextPrayerAtMs, null);

    let pushCount = 0;
    await runPrayerCron(env, {
      store,
      now: new Date('2026-03-08T10:00:00Z'),
      fetchImpl: async () => { pushCount += 1; return new Response('', { status: 201 }); },
    });
    assert.equal(pushCount, 0, 'Healing NULL next_prayer_at_ms must not emit stale pushes');
    const afterMama = await store.getUser('uid_mama');
    assert.ok(afterMama.nextPrayerAtMs > 0 && afterMama.nextPrayerName, 'Cron must initialize nextPrayerAtMs for seeded users');

    // 4. Snooze across prayer-window boundary (Isha snooze firing after Fajr started) must NOT fire for tonight's future Isha
    const uaKeys = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
    const p256dh = Buffer.from(await crypto.subtle.exportKey('raw', uaKeys.publicKey)).toString('base64url');
    const auth = Buffer.from(crypto.getRandomValues(new Uint8Array(16))).toString('base64url');
    await store.upsertPushSubscription({
      endpoint: 'https://web.push.apple.com/QTestEndpoint1',
      uid: 'uid_mama',
      p256dh,
      auth,
      userAgent: 'iPhone',
      createdAtMs: Date.now(),
    });
    await store.updateUser('uid_mama', {
      snoozePrayerName: 'Isha',
      snoozeAtMs: new Date('2026-03-08T01:30:00Z').getTime(), // 05:30 AM Dubai -> Fajr (05:22 AM) already started!
    });
    const snoozeRes = await runPrayerCron(env, {
      store,
      now: new Date('2026-03-08T01:31:00Z'),
      fetchImpl: async () => { pushCount += 1; return new Response('', { status: 201 }); },
    });
    assert.equal(snoozeRes.snoozeSent, 0, 'Expired Isha snooze must not fire during Fajr window');

    // 5. Admin remove-member & Logout push-endpoint cleanup
    const callApi = async (pathname, method, body, token) => {
      const headers = { 'Content-Type': 'application/json' };
      if (token) headers.Authorization = `Bearer ${token}`;
      const req = new Request(`https://waqt.example${pathname}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
      });
      const res = await handleApiRequest(req, env, { store });
      return { status: res.status, json: await res.json() };
    };

    const ownerReg = await callApi('/api/auth/register', 'POST', {
      displayName: 'OwnerNoor',
      city: 'Abu Dhabi',
      country: 'UAE',
      lat: 24.4539,
      lon: 54.3773,
      tz: 'Asia/Dubai',
      method: 'Dubai',
    });
    assert.equal(ownerReg.status, 201);
    const ownerToken = ownerReg.json.token;
    const ownerCircle = ownerReg.json.state.circles[0];

    const guestReg = await callApi('/api/auth/register', 'POST', {
      displayName: 'GuestSami',
      city: 'Dublin',
      country: 'Ireland',
      lat: 53.3498,
      lon: -6.2603,
      tz: 'Europe/Dublin',
      method: 'MuslimWorldLeague',
      inviteCode: ownerCircle.inviteCode,
    });
    assert.equal(guestReg.status, 201);
    const guestToken = guestReg.json.token;
    const guestUid = guestReg.json.state.me.uid;

    // Non-admin cannot remove owner
    const forbiddenRem = await callApi('/api/circles/remove-member', 'POST', {
      circleId: ownerCircle.circleId,
      memberUid: ownerReg.json.state.me.uid,
    }, guestToken);
    assert.equal(forbiddenRem.status, 403);

    // Owner removes guest cleanly
    const okRem = await callApi('/api/circles/remove-member', 'POST', {
      circleId: ownerCircle.circleId,
      memberUid: guestUid,
    }, ownerToken);
    assert.equal(okRem.status, 200);
    assert.equal(okRem.json.state.circles[0].members.length, 1);

    // Subscribe guest push, then logout with endpoint -> push subscription removed
    await callApi('/api/push/subscribe', 'POST', {
      subscription: { endpoint: 'https://web.push.apple.com/QGuestEndpoint', keys: { p256dh, auth } },
    }, guestToken);
    assert.equal((await store.getPushSubscriptions(guestUid)).length, 1);
    const outRes = await callApi('/api/auth/logout', 'POST', {
      endpoint: 'https://web.push.apple.com/QGuestEndpoint',
    }, guestToken);
    assert.equal(outRes.status, 200);
    assert.equal((await store.getPushSubscriptions(guestUid)).length, 0, 'Logout must remove device push endpoint');
  } finally {
    db.close();
  }
});

test('Offline ISO/IEC 18004 QR Code SVG generator (Versions 1-6) and seeded local server PIN login + messages', async (t) => {
  // 1. Version 1 (<=17 bytes): short invite code
  const v1 = generateQrMatrix('FAM-4821');
  assert.equal(v1.version, 1);
  assert.equal(v1.size, 21);

  // Verify 7x7 Finder Patterns at (0,0), (0, size-7), (size-7, 0)
  for (const [r0, c0] of [[0, 0], [0, v1.size - 7], [v1.size - 7, 0]]) {
    assert.equal(v1.modules[r0][c0], 1, 'Finder top-left corner must be dark');
    assert.equal(v1.modules[r0 + 3][c0 + 3], 1, 'Finder center 3x3 must be dark');
    assert.equal(v1.modules[r0 + 1][c0 + 1], 0, 'Finder inner ring must be light');
  }
  // Verify timing pattern alternation at row 6 / col 6 between finder patterns
  for (let i = 8; i < v1.size - 8; i++) {
    assert.equal(v1.modules[6][i], i % 2 === 0 ? 1 : 0, `Row 6 timing module ${i}`);
    assert.equal(v1.modules[i][6], i % 2 === 0 ? 1 : 0, `Col 6 timing module ${i}`);
  }
  // Verify dark module at (4 * V + 9, 8)
  assert.equal(v1.modules[4 * v1.version + 9][8], 1, 'Dark module must be 1');

  // 2. Version 2, Version 3 & Version 4-6 URLs
  const v2 = generateQrMatrix('https://waqt.app/?join=FAM-4821');
  assert.equal(v2.version, 2);
  assert.equal(v2.size, 25);

  const v3 = generateQrMatrix('https://waqt.example.com/?join=FAM-4821');
  assert.equal(v3.version, 3);
  assert.equal(v3.size, 29);

  const v5 = generateQrMatrix('https://waqt-family-pwa.example.workers.dev/?join=FAM-4821&circle=Al-Mansoor');
  assert.ok(v5.version >= 4 && v5.version <= 6);
  const svg = renderQrSvg('https://waqt.app/?join=FAM-4821');
  assert.ok(svg.startsWith('<svg ') && svg.includes('<path d="M') && svg.endsWith('</svg>'));

  // 3. Reject payloads > 134 bytes
  assert.throws(() => generateQrMatrix('x'.repeat(140)), /max 134 bytes/);

  // 4. Seeded local dev server supports PIN 2468 login for Mama/Ahmed/Teta/Khalid/Layla & includes seeded messages
  const srv = await startLocalServer({
    port: 0,
    seed: true,
    enableCron: false,
    disableKeepAlive: true,
    store: new MemoryWaqtStore(),
  });
  t.after(() => srv.close());

  const loginRes = await fetch(`${srv.url}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ displayName: 'Mama', pin: '2468' }),
  });
  assert.equal(loginRes.status, 200);
  const loginJson = await loginRes.json();
  assert.equal(loginJson.state.me.displayName, 'Mama');
  const circle0 = loginJson.state.circles[0];
  const ahmedFromMama = circle0.members.find((m) => m.displayName === 'Ahmed');
  assert.equal(ahmedFromMama.alreadyNudgedByMe, true, 'Mama seeded nudge to Ahmed must set alreadyNudgedByMe=true');

  const msgRes = await fetch(
    `${srv.url}/api/messages?peerUid=uid_ahmed&circleId=${encodeURIComponent(circle0.circleId)}`,
    { headers: { Authorization: `Bearer ${loginJson.token}` } }
  );
  assert.equal(msgRes.status, 200);
  const msgJson = await msgRes.json();
  assert.ok(msgJson.messages.length >= 2, 'Seeded local server must include initial 1:1 family messages');

  const ahmedLoginRes = await fetch(`${srv.url}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ displayName: 'Ahmed', pin: '2468' }),
  });
  assert.equal(ahmedLoginRes.status, 200);
  const ahmedJson = await ahmedLoginRes.json();
  assert.ok(ahmedJson.state.activeNudge, 'Ahmed must see seeded activeNudge from Mama');
});

test('Offline revalidateCachedLiveState rollover (same-day, pre-Fajr to post-Fajr, quietToday expiry, pending confirms), renderInviteQrSvg fallback & seed-sample.sql PIN login', async (t) => {
  // 1. Verify no .metadata.json artifact sidecars exist anywhere in the project tree
  async function findSidecars(dir) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const found = [];
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) found.push(...(await findSidecars(full)));
      else if (e.name.endsWith('.metadata.json')) found.push(full);
    }
    return found;
  }
  assert.deepEqual(await findSidecars(ROOT), [], 'Project tree must not contain .metadata.json sidecar files');

  // 2. renderInviteQrSvg falls back to rendering a valid QR SVG for the short invite code when URL > 134 bytes
  const longUrl = 'https://extremely-long-subdomain-preview-deployment.waqt-family-pwa.pages.cloudflare.example.com/invite/circle/join?join=FAM-4821&utm_source=family_share_sheet_qrcode';
  assert.ok(longUrl.length > 134);
  const fallbackSvg = renderInviteQrSvg(longUrl, 'FAM-4821');
  assert.equal(fallbackSvg, renderQrSvg('FAM-4821'), 'Oversized invite URL must fall back to valid QR SVG of inviteCode');

  // 3. Offline revalidateCachedLiveState across window & day rollovers
  const baseCached = {
    serverTimeMs: new Date('2026-01-14T13:00:00Z').getTime(),
    me: {
      uid: 'uid_ahmed',
      displayName: 'Ahmed',
      city: 'Dublin',
      country: 'Ireland',
      lat: 53.3498,
      lon: -6.2603,
      tz: 'Europe/Dublin',
      method: 'MuslimWorldLeague',
      asrMethod: 'standard',
      highLatitudeRule: 'auto',
      quietToday: true,
      quietUntilMs: new Date('2026-01-14T23:59:59Z').getTime(),
      currentWindow: {
        name: 'Dhuhr',
        arabic: 'الظهر',
        date: '2026-01-14',
        todayDate: '2026-01-14',
        startMs: new Date('2026-01-14T12:34:00Z').getTime(),
        endMs: new Date('2026-01-14T14:22:00Z').getTime(),
      },
      activePrayerLog: { Fajr: 1768371000000 },
      todayPrayerLog: { Fajr: 1768371000000 },
    },
    circles: [
      {
        circleId: 'cir_almansoor',
        name: 'Al-Mansoor Family',
        members: [
          {
            uid: 'uid_ahmed',
            displayName: 'Ahmed',
            isSelf: true,
            tz: 'Europe/Dublin',
            showCity: true,
            currentPrayer: { name: 'Dhuhr', date: '2026-01-14', endMs: new Date('2026-01-14T14:22:00Z').getTime(), prayed: false },
            prayerLog: { Fajr: 1768371000000 },
            todayPrayerLog: { Fajr: 1768371000000 },
          },
          {
            uid: 'uid_mama',
            displayName: 'Mama',
            isSelf: false,
            tz: 'Asia/Dubai',
            showCity: true,
            alreadyNudgedByMe: true,
            currentPrayer: { name: 'Asr', date: '2026-01-14', endMs: new Date('2026-01-14T14:30:00Z').getTime(), prayed: false },
          },
        ],
      },
    ],
    activeNudge: {
      prayer: 'Dhuhr',
      arabic: 'الظهر',
      date: '2026-01-14',
      summaryLine: 'Mama is thinking of you',
      latestCharacterId: 'teta',
    },
  };

  // 3a. Rollover to Asr on 2026-01-14 at 15:00Z (still quietUntilMs > now, and window changed Dhuhr -> Asr)
  const atAsr = revalidateCachedLiveState(baseCached, new Date('2026-01-14T15:00:00Z'));
  assert.equal(atAsr.me.currentWindow.name, 'Asr');
  assert.equal(atAsr.me.quietToday, true);
  assert.equal(atAsr.activeNudge, null, 'Stale Dhuhr nudge must clear when rolling into Asr');
  assert.equal(atAsr.me.todayPrayerLog.Fajr, 1768371000000, 'Same-day Fajr log must be preserved');
  assert.equal(atAsr.circles[0].members[1].alreadyNudgedByMe, false, 'Expired peer prayer window must clear alreadyNudgedByMe');

  // 3b. Pre-Fajr (01:30Z on 2026-01-15: win.date='2026-01-14', win.todayDate='2026-01-15') -> Post-Fajr (07:30Z on 2026-01-15: win.date='2026-01-15', win.todayDate='2026-01-15')
  const preFajrCached = revalidateCachedLiveState(
    {
      ...baseCached,
      me: {
        ...baseCached.me,
        currentWindow: { name: 'Isha', date: '2026-01-14', todayDate: '2026-01-15' },
        activePrayerLog: { Fajr: 1768371000000, Isha: 1768420000000 },
        todayPrayerLog: { Fajr: 1768458000000 },
      },
    },
    new Date('2026-01-15T07:30:00Z')
  );
  assert.equal(preFajrCached.me.currentWindow.name, 'Fajr');
  assert.equal(preFajrCached.me.currentWindow.date, '2026-01-15');
  assert.equal(preFajrCached.me.quietToday, false, 'quietToday must expire after quietUntilMs passes');
  assert.equal(preFajrCached.me.todayPrayerLog.Fajr, 1768458000000, 'Crossing Fajr from pre-Fajr must preserve todayPrayerLog');
  assert.equal(preFajrCached.me.activePrayerLog.Fajr, 1768458000000, 'Crossing Fajr must promote todayPrayerLog to activePrayerLog');

  // 3c. Offline pending confirm queue merges into revalidateCachedLiveState and clears activeNudge
  const prevStorage = globalThis.localStorage;
  const memStorage = new Map();
  globalThis.localStorage = {
    getItem: (k) => (memStorage.has(k) ? memStorage.get(k) : null),
    setItem: (k, v) => memStorage.set(k, String(v)),
    removeItem: (k) => memStorage.delete(k),
  };
  try {
    memStorage.set(
      'waqt_pending_confirms_v1',
      JSON.stringify([{ uid: 'uid_ahmed', prayer: 'Dhuhr', date: '2026-01-14', unconfirm: false, atMs: 1768396000000 }])
    );
    const unquietDhuhr = {
      ...baseCached,
      me: { ...baseCached.me, quietToday: false, quietUntilMs: null },
    };
    const afterOfflineConfirm = revalidateCachedLiveState(unquietDhuhr, new Date('2026-01-14T13:15:00Z'));
    assert.equal(afterOfflineConfirm.me.activePrayerLog.Dhuhr, 1768396000000);
    assert.equal(afterOfflineConfirm.activeNudge, null, 'Offline prayer confirmation must clear activeNudge');
    assert.equal(afterOfflineConfirm.circles[0].members[0].currentPrayer.prayed, true);
  } finally {
    globalThis.localStorage = prevStorage;
  }

  // 4. seed-sample.sql supports PIN 2468 login for all seeded members on SQLite (D1WaqtStore)
  const sqliteDb = new SqliteD1Database();
  t.after(() => sqliteDb.close());
  await sqliteDb.exec(await fs.readFile(path.join(ROOT, 'schema.sql'), 'utf8'));
  await sqliteDb.exec(await fs.readFile(path.join(ROOT, 'seed-sample.sql'), 'utf8'));
  const store = new D1WaqtStore(sqliteDb);

  for (const name of ['Yusuf', 'Mama', 'Ahmed', 'Teta', 'Khalid', 'Layla']) {
    const res = await handleApiRequest(
      new Request('https://waqt.family/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: name, pin: '2468' }),
      }),
      { DB: sqliteDb },
      { store }
    );
    assert.equal(res.status, 200, `Expected seed-sample.sql user ${name} to log in with PIN 2468`);
    const body = await res.json();
    assert.equal(body.state.me.hasPin, true);
  }
});

after(() => {
  setTimeout(() => process.exit(process.exitCode || 0), 25);
});





