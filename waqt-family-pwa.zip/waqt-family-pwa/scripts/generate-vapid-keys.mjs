#!/usr/bin/env node
// Generates a fresh P-256 VAPID keypair for Waqt lock-screen Web Push notifications (zero npm packages needed).
import { generateVapidKeys } from '../worker/webpush.mjs';

const keys = await generateVapidKeys();
console.log('\n=== Waqt Web Push VAPID Keys (100% Free, No Firebase Needed) ===\n');
console.log(`VAPID_PUBLIC_KEY=${keys.publicKey}`);
console.log(`VAPID_PRIVATE_KEY=${keys.privateKey}`);
console.log('\nSave these into Cloudflare Worker secrets (or .dev.vars locally):');
console.log(`  npx wrangler secret put VAPID_PUBLIC_KEY   # paste: ${keys.publicKey}`);
console.log(`  npx wrangler secret put VAPID_PRIVATE_KEY  # paste: ${keys.privateKey}\n`);
