// Cloudflare D1 (SQLite) storage adapter for Waqt Worker.
// All queries use strict parameterized bindings (`?`) against schema.sql.

function rowToUser(r) {
  if (!r) return null;
  return {
    uid: r.uid,
    displayName: r.display_name,
    pinHash: r.pin_hash || null,
    pinSalt: r.pin_salt || null,
    phone: r.phone || '',
    facetimeId: r.facetime_id || '',
    city: r.city,
    country: r.country,
    lat: Number(r.lat),
    lon: Number(r.lon),
    tz: r.tz,
    method: r.method,
    asrMethod: r.asr_method,
    highLatitudeRule: r.high_latitude_rule,
    remindOffsetMinutes: Number(r.remind_offset_minutes ?? 0),
    shareStatus: Boolean(r.share_status),
    showCity: Boolean(r.show_city),
    circleReminders: Boolean(r.circle_reminders),
    quietUntilMs: r.quiet_until_ms !== null && r.quiet_until_ms !== undefined ? Number(r.quiet_until_ms) : null,
    eveningSummary: Boolean(r.evening_summary),
    lastSummaryDate: r.last_summary_date || null,
    characterStyle: r.character_style || 'characters',
    preferredCharacter: r.preferred_character || 'teta',
    nextPrayerName: r.next_prayer_name || null,
    nextPrayerAtMs: r.next_prayer_at_ms !== null && r.next_prayer_at_ms !== undefined ? Number(r.next_prayer_at_ms) : null,
    nextPrayerDate: r.next_prayer_date || null,
    snoozePrayerName: r.snooze_prayer_name || null,
    snoozeAtMs: r.snooze_at_ms !== null && r.snooze_at_ms !== undefined ? Number(r.snooze_at_ms) : null,
    createdAtMs: Number(r.created_at_ms),
  };
}

export class D1WaqtStore {
  constructor(db) {
    this.db = db;
  }

  async createUser(u) {
    await this.db
      .prepare(
        `INSERT INTO users (
          uid, display_name, pin_hash, pin_salt, phone, facetime_id,
          city, country, lat, lon, tz, method, asr_method, high_latitude_rule,
          remind_offset_minutes, share_status, show_city, circle_reminders,
          quiet_until_ms, evening_summary, last_summary_date, character_style,
          preferred_character, next_prayer_name, next_prayer_at_ms, next_prayer_date,
          snooze_prayer_name, snooze_at_ms, created_at_ms
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        u.uid,
        u.displayName,
        u.pinHash || null,
        u.pinSalt || null,
        u.phone || '',
        u.facetimeId || '',
        u.city,
        u.country,
        u.lat,
        u.lon,
        u.tz,
        u.method,
        u.asrMethod,
        u.highLatitudeRule,
        u.remindOffsetMinutes ?? 0,
        u.shareStatus ? 1 : 0,
        u.showCity ? 1 : 0,
        u.circleReminders ? 1 : 0,
        u.quietUntilMs ?? null,
        u.eveningSummary ? 1 : 0,
        u.lastSummaryDate ?? null,
        u.characterStyle || 'characters',
        u.preferredCharacter || 'teta',
        u.nextPrayerName ?? null,
        u.nextPrayerAtMs ?? null,
        u.nextPrayerDate ?? null,
        u.snoozePrayerName ?? null,
        u.snoozeAtMs ?? null,
        u.createdAtMs
      )
      .run();
    return this.getUser(u.uid);
  }

  async getUser(uid) {
    const r = await this.db.prepare('SELECT * FROM users WHERE uid = ?').bind(uid).first();
    return rowToUser(r);
  }

  async findUsersByName(displayName) {
    const res = await this.db
      .prepare('SELECT * FROM users WHERE LOWER(display_name) = LOWER(?)')
      .bind(displayName.trim())
      .all();
    return (res.results || []).map(rowToUser);
  }

  async updateUser(uid, patch) {
    const current = await this.getUser(uid);
    if (!current) return null;
    const merged = { ...current, ...patch };
    await this.db
      .prepare(
        `UPDATE users SET
          display_name = ?, pin_hash = ?, pin_salt = ?, phone = ?, facetime_id = ?,
          city = ?, country = ?, lat = ?, lon = ?, tz = ?, method = ?, asr_method = ?,
          high_latitude_rule = ?, remind_offset_minutes = ?, share_status = ?, show_city = ?,
          circle_reminders = ?, quiet_until_ms = ?, evening_summary = ?, last_summary_date = ?,
          character_style = ?, preferred_character = ?, next_prayer_name = ?, next_prayer_at_ms = ?,
          next_prayer_date = ?, snooze_prayer_name = ?, snooze_at_ms = ?
        WHERE uid = ?`
      )
      .bind(
        merged.displayName,
        merged.pinHash || null,
        merged.pinSalt || null,
        merged.phone || '',
        merged.facetimeId || '',
        merged.city,
        merged.country,
        merged.lat,
        merged.lon,
        merged.tz,
        merged.method,
        merged.asrMethod,
        merged.highLatitudeRule,
        merged.remindOffsetMinutes ?? 0,
        merged.shareStatus ? 1 : 0,
        merged.showCity ? 1 : 0,
        merged.circleReminders ? 1 : 0,
        merged.quietUntilMs ?? null,
        merged.eveningSummary ? 1 : 0,
        merged.lastSummaryDate ?? null,
        merged.characterStyle || 'characters',
        merged.preferredCharacter || 'teta',
        merged.nextPrayerName ?? null,
        merged.nextPrayerAtMs ?? null,
        merged.nextPrayerDate ?? null,
        merged.snoozePrayerName ?? null,
        merged.snoozeAtMs ?? null,
        uid
      )
      .run();
    return this.getUser(uid);
  }

  async createSession(tokenHash, uid, createdAtMs) {
    await this.db
      .prepare('INSERT INTO sessions (token_hash, uid, created_at_ms) VALUES (?, ?, ?)')
      .bind(tokenHash, uid, createdAtMs)
      .run();
  }

  async getUidBySession(tokenHash) {
    const r = await this.db
      .prepare('SELECT uid FROM sessions WHERE token_hash = ?')
      .bind(tokenHash)
      .first();
    return r ? r.uid : null;
  }

  async deleteSession(tokenHash) {
    await this.db.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(tokenHash).run();
  }

  async getCircleByInviteCode(inviteCode) {
    const r = await this.db
      .prepare('SELECT * FROM circles WHERE invite_code = ?')
      .bind(inviteCode)
      .first();
    if (!r) return null;
    return this.getCircle(r.circle_id);
  }

  async getCircle(circleId) {
    const c = await this.db.prepare('SELECT * FROM circles WHERE circle_id = ?').bind(circleId).first();
    if (!c) return null;
    const membersRes = await this.db
      .prepare('SELECT uid FROM circle_members WHERE circle_id = ? ORDER BY joined_at_ms ASC')
      .bind(circleId)
      .all();
    return {
      circleId: c.circle_id,
      name: c.name,
      ownerUid: c.owner_uid,
      inviteCode: c.invite_code,
      createdAtMs: Number(c.created_at_ms),
      memberUids: (membersRes.results || []).map((m) => m.uid),
    };
  }

  async createCircle({ circleId, name, ownerUid, inviteCode, createdAtMs }) {
    await this.db.batch([
      this.db
        .prepare('INSERT INTO circles (circle_id, name, owner_uid, invite_code, created_at_ms) VALUES (?, ?, ?, ?, ?)')
        .bind(circleId, name, ownerUid, inviteCode, createdAtMs),
      this.db
        .prepare('INSERT INTO circle_members (circle_id, uid, joined_at_ms) VALUES (?, ?, ?)')
        .bind(circleId, ownerUid, createdAtMs),
    ]);
    return this.getCircle(circleId);
  }

  async addCircleMember(circleId, uid, joinedAtMs) {
    await this.db
      .prepare('INSERT OR IGNORE INTO circle_members (circle_id, uid, joined_at_ms) VALUES (?, ?, ?)')
      .bind(circleId, uid, joinedAtMs)
      .run();
  }

  async removeCircleMember(circleId, uid) {
    await this.db
      .prepare('DELETE FROM circle_members WHERE circle_id = ? AND uid = ?')
      .bind(circleId, uid)
      .run();
    const circle = await this.getCircle(circleId);
    if (!circle) return;
    if (circle.memberUids.length === 0) {
      await this.db.prepare('DELETE FROM circles WHERE circle_id = ?').bind(circleId).run();
    } else if (circle.ownerUid === uid) {
      await this.db
        .prepare('UPDATE circles SET owner_uid = ? WHERE circle_id = ?')
        .bind(circle.memberUids[0], circleId)
        .run();
    }
  }

  async getCirclesForUser(uid) {
    const res = await this.db
      .prepare(
        `SELECT c.circle_id FROM circles c
         INNER JOIN circle_members cm ON c.circle_id = cm.circle_id
         WHERE cm.uid = ?
         ORDER BY cm.joined_at_ms ASC`
      )
      .bind(uid)
      .all();
    const ids = (res.results || []).map((r) => r.circle_id);
    const out = [];
    for (const id of ids) {
      const c = await this.getCircle(id);
      if (c) out.push(c);
    }
    return out;
  }

  async sharesCircle(uidA, uidB) {
    if (uidA === uidB) return true;
    const r = await this.db
      .prepare(
        `SELECT 1 AS ok FROM circle_members a
         INNER JOIN circle_members b ON a.circle_id = b.circle_id
         WHERE a.uid = ? AND b.uid = ? LIMIT 1`
      )
      .bind(uidA, uidB)
      .first();
    return Boolean(r);
  }

  async setPrayerConfirmed(uid, localDate, prayer, confirmedAtMs) {
    await this.db
      .prepare(
        `INSERT INTO prayer_logs (uid, local_date, prayer, confirmed_at_ms)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(uid, local_date, prayer) DO UPDATE SET confirmed_at_ms = excluded.confirmed_at_ms`
      )
      .bind(uid, localDate, prayer, confirmedAtMs)
      .run();
  }

  async removePrayerConfirmed(uid, localDate, prayer) {
    await this.db
      .prepare('DELETE FROM prayer_logs WHERE uid = ? AND local_date = ? AND prayer = ?')
      .bind(uid, localDate, prayer)
      .run();
  }

  async getPrayerLog(uid, localDate) {
    const res = await this.db
      .prepare('SELECT prayer, confirmed_at_ms FROM prayer_logs WHERE uid = ? AND local_date = ?')
      .bind(uid, localDate)
      .all();
    const map = {};
    for (const r of res.results || []) {
      map[r.prayer] = Number(r.confirmed_at_ms);
    }
    return map;
  }

  async createNudge(n) {
    const existing = await this.db
      .prepare('SELECT nudge_id FROM nudges WHERE nudge_id = ?')
      .bind(n.nudgeId)
      .first();
    if (existing) return { duplicate: true };
    await this.db
      .prepare(
        `INSERT INTO nudges (
          nudge_id, from_uid, to_uid, circle_id, prayer, local_date,
          character_id, created_at_ms, delivered_at_ms, suppressed
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        n.nudgeId,
        n.fromUid,
        n.toUid,
        n.circleId,
        n.prayer,
        n.localDate,
        n.characterId || 'teta',
        n.createdAtMs,
        n.deliveredAtMs ?? null,
        n.suppressed ? 1 : 0
      )
      .run();
    return { duplicate: false };
  }

  async getNudgesForRecipientPrayer(toUid, localDate, prayer) {
    const res = await this.db
      .prepare(
        `SELECT * FROM nudges
         WHERE to_uid = ? AND local_date = ? AND prayer = ?
         ORDER BY created_at_ms ASC`
      )
      .bind(toUid, localDate, prayer)
      .all();
    return (res.results || []).map((r) => ({
      nudgeId: r.nudge_id,
      fromUid: r.from_uid,
      toUid: r.to_uid,
      circleId: r.circle_id,
      prayer: r.prayer,
      localDate: r.local_date,
      characterId: r.character_id,
      createdAtMs: Number(r.created_at_ms),
      deliveredAtMs: r.delivered_at_ms ? Number(r.delivered_at_ms) : null,
      suppressed: Boolean(r.suppressed),
    }));
  }

  async getRecentNudgesForRecipient(toUid, sinceMs) {
    const res = await this.db
      .prepare(
        `SELECT * FROM nudges
         WHERE to_uid = ? AND suppressed = 0 AND created_at_ms >= ?
         ORDER BY created_at_ms DESC LIMIT 20`
      )
      .bind(toUid, sinceMs)
      .all();
    return (res.results || []).map((r) => ({
      nudgeId: r.nudge_id,
      fromUid: r.from_uid,
      toUid: r.to_uid,
      circleId: r.circle_id,
      prayer: r.prayer,
      localDate: r.local_date,
      characterId: r.character_id,
      createdAtMs: Number(r.created_at_ms),
    }));
  }

  async createMessage(m) {
    await this.db
      .prepare(
        `INSERT INTO messages (message_id, circle_id, from_uid, to_uid, kind, prayer, body, created_at_ms)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(m.messageId, m.circleId, m.fromUid, m.toUid, m.kind || 'text', m.prayer || null, m.body, m.createdAtMs)
      .run();
  }

  async getMessagesBetween(uidA, uidB, limit = 60) {
    const res = await this.db
      .prepare(
        `SELECT * FROM messages
         WHERE (from_uid = ? AND to_uid = ?) OR (from_uid = ? AND to_uid = ?)
         ORDER BY created_at_ms DESC LIMIT ?`
      )
      .bind(uidA, uidB, uidB, uidA, limit)
      .all();
    return (res.results || [])
      .map((r) => ({
        messageId: r.message_id,
        circleId: r.circle_id,
        fromUid: r.from_uid,
        toUid: r.to_uid,
        kind: r.kind,
        prayer: r.prayer || null,
        body: r.body,
        createdAtMs: Number(r.created_at_ms),
      }))
      .reverse();
  }

  async upsertPushSubscription({ endpoint, uid, p256dh, auth, userAgent, createdAtMs }) {
    await this.db
      .prepare(
        `INSERT INTO push_subscriptions (endpoint, uid, p256dh, auth, user_agent, created_at_ms)
         VALUES (?, ?, ?, ?, ?, ?)
         ON CONFLICT(endpoint) DO UPDATE SET uid = excluded.uid, p256dh = excluded.p256dh, auth = excluded.auth, user_agent = excluded.user_agent`
      )
      .bind(endpoint, uid, p256dh, auth, userAgent || '', createdAtMs)
      .run();
  }

  async getPushSubscriptions(uid) {
    const res = await this.db
      .prepare('SELECT * FROM push_subscriptions WHERE uid = ?')
      .bind(uid)
      .all();
    return (res.results || []).map((r) => ({
      endpoint: r.endpoint,
      uid: r.uid,
      keys: { p256dh: r.p256dh, auth: r.auth },
      userAgent: r.user_agent,
    }));
  }

  async deletePushSubscription(endpoint) {
    await this.db
      .prepare('DELETE FROM push_subscriptions WHERE endpoint = ?')
      .bind(endpoint)
      .run();
  }

  async getDuePrayerUsers(nowMs) {
    const res = await this.db
      .prepare('SELECT * FROM users WHERE next_prayer_at_ms IS NULL OR next_prayer_at_ms <= ? LIMIT 500')
      .bind(nowMs)
      .all();
    return (res.results || []).map(rowToUser);
  }

  async getDueSnoozeUsers(nowMs) {
    const res = await this.db
      .prepare('SELECT * FROM users WHERE snooze_at_ms IS NOT NULL AND snooze_at_ms <= ? LIMIT 500')
      .bind(nowMs)
      .all();
    return (res.results || []).map(rowToUser);
  }

  async getEveningSummaryUsers() {
    const res = await this.db
      .prepare('SELECT * FROM users WHERE evening_summary = 1 LIMIT 500')
      .all();
    return (res.results || []).map(rowToUser);
  }
}
