// Waqt Production PWA Client (ES Module)
// Wires all 8 emerald & gold screens from design/source/*.dc.html to the Cloudflare Worker + D1 + Web Push backend,
// with automatic fallback to Local Family Sandbox Mode (seeded from sample-data.json) when opened without a server.

import {
  PRAYERS,
  PRAYER_ARABIC,
  METHOD_PRESETS,
  currentPrayerWindow,
  formatTimeInZone,
  formatDuration,
  endOfLocalDayUtc,
  nearestCity,
} from './prayer-engine.js';
import { renderQrSvg, renderInviteQrSvg } from './qr-svg.js';

const RING_CIRCUMFERENCE = 2 * Math.PI * 92; // 578.053
const TOKEN_KEY = 'waqt_auth_token_v1';
const LIVE_STATE_CACHE_KEY = 'waqt_last_live_state_v1';
const PENDING_CONFIRMS_KEY = 'waqt_pending_confirms_v1';
const SANDBOX_KEY = 'waqt_family_sandbox_v2';
const PEER_CONTACTS_KEY = 'waqt_peer_contacts_v1';

const CHARACTERS = [
  { id: 'little-noor', name: 'Little Noor', role: 'FAJR WAKE-UP', line: 'Wakey wakey, Fajr is here!', symbol: false },
  { id: 'teta', name: 'Teta', role: 'WARM NUDGE', line: 'Habibi, have you prayed yet?', symbol: false },
  { id: 'jiddo', name: 'Jiddo', role: 'GENTLE NUDGE', line: 'Come, we pray together.', symbol: false },
  { id: 'sami', name: 'Sami', role: 'CHEEKY NUDGE', line: 'Race you to the prayer mat!', symbol: false },
  { id: 'hilal', name: 'Hilal', role: 'CELEBRATION', line: 'Mashallah! {prayer} is done.', symbol: true },
  { id: 'fanous', name: 'Fanous', role: 'QUIET REMINDER', line: 'Your light is waiting.', symbol: true },
];

// Trusted static SVG artwork directly from design/source/Characters.dc.html
const CHARACTER_SVGS = {
  'little-noor': `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Little Noor"><path d="M28 120c0-20 14-30 32-30s32 10 32 30z" fill="#1A4A40"/><path d="M66 104a8 8 0 1 1-5-7 6 6 0 0 0 5 7z" fill="#D4B46A"/><circle cx="26" cy="60" r="6" fill="#F2CDA6"/><circle cx="94" cy="60" r="6" fill="#F2CDA6"/><circle cx="60" cy="58" r="34" fill="#F2CDA6"/><path d="M52 27c-2-9 11-12 14-3 1 3-1 5-4 5" fill="none" stroke="#5B3A29" stroke-width="3.5" stroke-linecap="round"/><circle cx="47" cy="58" r="4" fill="#241F19"/><circle cx="73" cy="58" r="4" fill="#241F19"/><circle cx="48.4" cy="56.6" r="1.4" fill="#fff"/><circle cx="74.4" cy="56.6" r="1.4" fill="#fff"/><circle cx="39" cy="71" r="6.5" fill="#EFA08F" opacity="0.65"/><circle cx="81" cy="71" r="6.5" fill="#EFA08F" opacity="0.65"/><path d="M54 72q6 6 12 0" fill="none" stroke="#241F19" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  teta: `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Teta"><path d="M24 120c0-20 14-30 36-30s36 10 36 30z" fill="#1A4A40"/><path d="M60 14c-26 0-38 18-38 42 0 22 8 36 14 42h48c6-6 14-20 14-42 0-24-12-42-38-42z" fill="#F3ECDB" stroke="#D4B46A" stroke-width="2"/><ellipse cx="60" cy="58" rx="26" ry="28" fill="#E8B98A"/><circle cx="49" cy="56" r="8.5" fill="none" stroke="#0B2420" stroke-width="2"/><circle cx="71" cy="56" r="8.5" fill="none" stroke="#0B2420" stroke-width="2"/><path d="M57.5 56h5" stroke="#0B2420" stroke-width="2" stroke-linecap="round"/><circle cx="49" cy="56" r="2.6" fill="#241F19"/><circle cx="71" cy="56" r="2.6" fill="#241F19"/><circle cx="42" cy="72" r="6" fill="#E08E7C" opacity="0.6"/><circle cx="78" cy="72" r="6" fill="#E08E7C" opacity="0.6"/><path d="M52 74q8 8 16 0" fill="none" stroke="#241F19" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  jiddo: `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Jiddo"><path d="M24 120c0-20 14-30 36-30s36 10 36 30z" fill="#1A4A40"/><circle cx="29" cy="58" r="6" fill="#C98B5E"/><circle cx="91" cy="58" r="6" fill="#C98B5E"/><circle cx="60" cy="56" r="31" fill="#C98B5E"/><path d="M29 62c0 26 13 40 31 40s31-14 31-40c-6 8-15 11-31 11s-25-3-31-11z" fill="#F3ECDB"/><path d="M29 46c0-21 13-30 31-30s31 9 31 30c-10-5-19-7-31-7s-21 2-31 7z" fill="#F3ECDB" stroke="#D4B46A" stroke-width="1.8"/><path d="M44 24q16-5 32 0" fill="none" stroke="#D4B46A" stroke-width="1.6" stroke-linecap="round"/><path d="M41 49q7-5 14 0M65 49q7-5 14 0" fill="none" stroke="#F3ECDB" stroke-width="4" stroke-linecap="round"/><path d="M43 58q5-5 10 0M67 58q5-5 10 0" fill="none" stroke="#241F19" stroke-width="2.4" stroke-linecap="round"/><circle cx="60" cy="63" r="5" fill="#B87449"/><path d="M45 72q7-5 15 0q8-5 15 0q-7 7-15 4q-8 3-15-4z" fill="#F3ECDB" stroke="#D8D0BC" stroke-width="1"/><path d="M52 82q8 6 16 0" fill="none" stroke="#241F19" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  sami: `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Sami"><path d="M26 120c0-20 14-30 34-30s34 10 34 30z" fill="#1A4A40"/><polygon points="60,94 63,101 70.5,101 64.5,105.5 66.5,113 60,108.5 53.5,113 55.5,105.5 49.5,101 57,101" fill="#D4B46A"/><circle cx="28" cy="62" r="6" fill="#D9A074"/><circle cx="92" cy="62" r="6" fill="#D9A074"/><circle cx="60" cy="60" r="32" fill="#D9A074"/><path d="M27 56c-3-25 13-34 33-34s36 9 33 34c-8-10-19-15-33-15s-25 5-33 15z" fill="#2B1B14"/><circle cx="47" cy="60" r="4" fill="#241F19"/><circle cx="73" cy="60" r="4" fill="#241F19"/><circle cx="48.4" cy="58.6" r="1.4" fill="#fff"/><circle cx="74.4" cy="58.6" r="1.4" fill="#fff"/><circle cx="38" cy="72" r="6" fill="#E08E7C" opacity="0.6"/><circle cx="82" cy="72" r="6" fill="#E08E7C" opacity="0.6"/><path d="M47 71q13 18 26 0z" fill="#7A2E2A"/><rect x="58" y="71" width="6" height="6" rx="1.2" fill="#fff"/></svg>`,
  hilal: `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Hilal"><circle cx="56" cy="62" r="46" fill="#D4B46A"/><circle cx="82" cy="50" r="40" fill="#102F29"/><path d="M20 62q4-5 8 0M33 56q4-5 8 0" fill="none" stroke="#241F19" stroke-width="2.6" stroke-linecap="round"/><circle cx="19" cy="72" r="4.5" fill="#E08E7C" opacity="0.65"/><circle cx="40" cy="68" r="4.5" fill="#E08E7C" opacity="0.65"/><path d="M24 74q5 6 11 1" fill="none" stroke="#241F19" stroke-width="2.4" stroke-linecap="round"/><polygon points="96,22 99,30 107,30 100.5,35 103,43 96,38 89,43 91.5,35 85,30 93,30" fill="#D4B46A"/></svg>`,
  fanous: `<svg width="96" height="96" viewBox="0 0 120 120" role="img" aria-label="Fanous"><circle cx="60" cy="60" r="52" fill="#D4B46A" opacity="0.12"/><circle cx="60" cy="9" r="4" fill="none" stroke="#D4B46A" stroke-width="2"/><polygon points="38,34 60,16 82,34" fill="#D4B46A"/><path d="M40 34h40c5 14 5 42 0 56H40c-5-14-5-42 0-56z" fill="#F7E3A5"/><path d="M51 34c-3 14-3 42 0 56M69 34c3 14 3 42 0 56" fill="none" stroke="#D4B46A" stroke-width="2"/><path d="M37 90h46l-6 10H43z" fill="#D4B46A"/><path d="M60 100v10" stroke="#D4B46A" stroke-width="2"/><circle cx="60" cy="112" r="3.2" fill="#D4B46A"/><circle cx="55" cy="58" r="2.8" fill="#241F19"/><circle cx="65" cy="58" r="2.8" fill="#241F19"/><circle cx="50.5" cy="66" r="3.4" fill="#E08E7C" opacity="0.65"/><circle cx="69.5" cy="66" r="3.4" fill="#E08E7C" opacity="0.65"/><path d="M55.5 66q4.5 5 9 0" fill="none" stroke="#241F19" stroke-width="2.2" stroke-linecap="round"/></svg>`,
};

const NUMBER_WORDS = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'];

// Pure helper for 1-tap WhatsApp, FaceTime Video, FaceTime Audio, and Phone Call deep-links
export function buildCallShortcuts(member, senderName = '') {
  const rawPhone = String(member.phone || '').trim();
  const rawFaceTime = String(member.facetimeId || rawPhone || '').trim();

  // Normalize digits for WhatsApp wa.me (requires international digits without + or leading 00)
  let waDigits = rawPhone.replace(/[^\d+]/g, '');
  if (waDigits.startsWith('+')) waDigits = waDigits.slice(1);
  else if (waDigits.startsWith('00')) waDigits = waDigits.slice(2);
  waDigits = waDigits.replace(/\D/g, '');

  const prayerName = (member.currentPrayer && member.currentPrayer.name) || 'prayer';
  const greeting = senderName
    ? `Assalamu alaikum ${member.displayName}, checking in with love for ${prayerName}! — ${senderName}`
    : `Assalamu alaikum ${member.displayName}, checking in with love for ${prayerName}!`;

  const whatsappUrl = waDigits
    ? `https://wa.me/${waDigits}?text=${encodeURIComponent(greeting)}`
    : `https://wa.me/?text=${encodeURIComponent(greeting)}`;

  const ftTarget = rawFaceTime.replace(/\s+/g, '');
  const telDigits = rawPhone.replace(/[^\d+]/g, '');

  return {
    hasSavedContact: Boolean(waDigits || ftTarget),
    whatsappUrl,
    facetimeVideoUrl: ftTarget ? `facetime://${ftTarget}` : null,
    facetimeAudioUrl: ftTarget ? `facetime-audio://${ftTarget}` : null,
    telUrl: telDigits ? `tel:${telDigits}` : null,
  };
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; i += 1) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

const $ = (id) => document.getElementById(id);

function createCheckSvg(size = 11, strokeWidth = 3.2) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(size));
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', String(strokeWidth));
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS(ns, 'path');
  p.setAttribute('d', 'M5 12.5l4.5 4.5L19 7.5');
  svg.appendChild(p);
  return svg;
}

// ==================== APPLICATION STATE ====================
let citiesData = [];
let methodsData = null;
let sampleData = null;

let backendMode = 'live'; // 'live' (Cloudflare Worker + D1) or 'sandbox' (local preview)
let serverConfig = { vapidPublicKey: null, requiresAccessCode: false };
let authToken =
  typeof localStorage !== 'undefined' ? localStorage.getItem(TOKEN_KEY) || null : null;
let appState = null;

let activeTab = 'home'; // 'home' | 'circle' | 'chat' | 'settings' | 'characters'
let selectedCircleId = null;
let selectedWelcomeCity = null;
let selectedNudgeMember = null;
let selectedNudgeCharacter = 'teta';
let activeChatPeerUid = null;
let chatMessages = [];
let selectedCallMember = null;

let broadcastChannel = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    broadcastChannel = new BroadcastChannel('waqt_family_sync');
  }
} catch {
  broadcastChannel = null;
}

let toastTimer = null;
function toast(msg, durationMs = 2600) {
  const el = $('toast');
  if (!el) return;
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.hidden = true;
  }, durationMs);
}

function getLocalPeerContacts() {
  try {
    return JSON.parse(localStorage.getItem(PEER_CONTACTS_KEY) || '{}');
  } catch {
    return {};
  }
}

function saveLocalPeerContact(peerUid, contactValue) {
  const map = getLocalPeerContacts();
  map[peerUid] = String(contactValue || '').trim();
  localStorage.setItem(PEER_CONTACTS_KEY, JSON.stringify(map));
}

function mergeMemberContact(member) {
  const overrides = getLocalPeerContacts();
  const localVal = overrides[member.uid] || '';
  if (!localVal) return member;
  const isEmail = localVal.includes('@');
  return {
    ...member,
    phone: member.phone || (isEmail ? '' : localVal),
    facetimeId: member.facetimeId || localVal,
  };
}

// ==================== LOCAL SANDBOX ENGINE (WHEN NO SERVER ATTACHED) ====================
function loadSandboxDb() {
  try {
    const raw = localStorage.getItem(SANDBOX_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore corrupt local state
  }
  return null;
}

function saveSandboxDb(db) {
  localStorage.setItem(SANDBOX_KEY, JSON.stringify(db));
  if (broadcastChannel) {
    broadcastChannel.postMessage({ type: 'SANDBOX_UPDATED' });
  }
}

function seedSandboxFromSample(customMe = null) {
  const now = new Date();
  const users = {};
  const sampleUsers = (sampleData && sampleData.users) || {};
  for (const [id, u] of Object.entries(sampleUsers)) {
    users[id] = {
      uid: id,
      displayName: u.displayName,
      phone: id === 'uid_ahmed' ? '+353871234567' : id === 'uid_mama' ? '+971501234567' : '',
      facetimeId: id === 'uid_ahmed' ? '+353871234567' : '',
      city: u.city,
      country: u.country,
      lat: u.lat,
      lon: u.lon,
      tz: u.tz,
      method: u.method,
      asrMethod: u.asrMethod || 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 0,
      shareStatus: Boolean(u.shareStatus),
      showCity: u.showCity !== false,
      circleReminders: true,
      quietUntilMs: null,
      eveningSummary: false,
      characterStyle: u.characterStyle || 'characters',
      preferredCharacter: 'teta',
      snoozeAtMs: null,
      snoozePrayerName: null,
    };
  }

  let currentUid = 'uid_noor';
  if (customMe) {
    currentUid = 'uid_me';
    users[currentUid] = {
      uid: currentUid,
      displayName: customMe.displayName,
      phone: customMe.phone || '',
      facetimeId: customMe.facetimeId || '',
      city: customMe.city,
      country: customMe.country,
      lat: customMe.lat,
      lon: customMe.lon,
      tz: customMe.tz,
      method: customMe.method,
      asrMethod: customMe.asrMethod || 'standard',
      highLatitudeRule: 'auto',
      remindOffsetMinutes: 0,
      shareStatus: customMe.shareStatus !== false,
      showCity: true,
      circleReminders: true,
      quietUntilMs: null,
      eveningSummary: false,
      characterStyle: 'characters',
      preferredCharacter: 'teta',
      snoozeAtMs: null,
      snoozePrayerName: null,
    };
  }

  const memberUids = customMe
    ? ['uid_me', 'uid_layla', 'uid_mama', 'uid_ahmed', 'uid_yusuf', 'uid_sara']
    : ['uid_noor', 'uid_layla', 'uid_mama', 'uid_ahmed', 'uid_yusuf', 'uid_sara'];

  // Seed realistic today prayer logs for Layla & Mama so the circle feels alive immediately
  const prayerLogs = {};
  for (const id of ['uid_layla', 'uid_mama']) {
    const u = users[id];
    const win = currentPrayerWindow(u, now);
    const key = `${id}|${win.date}`;
    prayerLogs[key] = { Fajr: now.getTime() - 18000000 };
    if (win.name !== 'Fajr') prayerLogs[key][win.name] = now.getTime() - 900000;
  }
  const meWin = currentPrayerWindow(users[currentUid], now);
  if (meWin.name !== 'Fajr') {
    prayerLogs[`${currentUid}|${meWin.date}`] = { Fajr: now.getTime() - 21600000 };
  }

  // Seed an incoming nudge from Layla & Mama + sample Chat thread with Ahmed (matching Chat.dc.html)
  const nudges = [
    {
      nudgeId: `in_layla`,
      fromUid: 'uid_layla',
      toUid: currentUid,
      circleId: 'circle_family',
      prayer: meWin.name,
      localDate: meWin.date,
      characterId: 'teta',
      createdAtMs: now.getTime() - 600000,
      suppressed: false,
    },
    {
      nudgeId: `in_mama`,
      fromUid: 'uid_mama',
      toUid: currentUid,
      circleId: 'circle_family',
      prayer: meWin.name,
      localDate: meWin.date,
      characterId: 'teta',
      createdAtMs: now.getTime() - 300000,
      suppressed: false,
    },
  ];

  const messages = [
    {
      messageId: 'm1',
      circleId: 'circle_family',
      fromUid: currentUid,
      toUid: 'uid_ahmed',
      kind: 'nudge',
      prayer: 'Dhuhr',
      body: 'Sent a reminder for Dhuhr',
      createdAtMs: now.getTime() - 3600000,
    },
    {
      messageId: 'm2',
      circleId: 'circle_family',
      fromUid: currentUid,
      toUid: 'uid_ahmed',
      kind: 'text',
      prayer: null,
      body: "Dhuhr time, habibi. Go on, I'll wait.",
      createdAtMs: now.getTime() - 3500000,
    },
    {
      messageId: 'm3',
      circleId: 'circle_family',
      fromUid: 'uid_ahmed',
      toUid: currentUid,
      kind: 'text',
      prayer: null,
      body: 'Ha, perfect timing. Heading to pray now.',
      createdAtMs: now.getTime() - 3200000,
    },
    {
      messageId: 'm4',
      circleId: 'circle_family',
      fromUid: 'uid_ahmed',
      toUid: currentUid,
      kind: 'confirmed',
      prayer: 'Dhuhr',
      body: 'Ahmed prayed Dhuhr',
      createdAtMs: now.getTime() - 2400000,
    },
    {
      messageId: 'm5',
      circleId: 'circle_family',
      fromUid: 'uid_ahmed',
      toUid: currentUid,
      kind: 'text',
      prayer: null,
      body: 'Jazakallahu khairan for the nudge. Call later?',
      createdAtMs: now.getTime() - 1800000,
    },
    {
      messageId: 'm6',
      circleId: 'circle_family',
      fromUid: currentUid,
      toUid: 'uid_ahmed',
      kind: 'text',
      prayer: null,
      body: 'Always. Tonight after Isha.',
      createdAtMs: now.getTime() - 1500000,
    },
  ];

  const db = {
    currentUid,
    users,
    circles: [
      {
        circleId: 'circle_family',
        name: 'Family',
        ownerUid: currentUid,
        inviteCode: 'FAM-4K7Q',
        memberUids,
      },
      {
        circleId: 'circle_friends',
        name: 'Friends',
        ownerUid: currentUid,
        inviteCode: 'FRD-9M2P',
        memberUids: [currentUid, 'uid_yusuf', 'uid_sara'],
      },
    ],
    prayerLogs,
    nudges,
    messages,
  };
  saveSandboxDb(db);
  return db;
}

function buildSandboxState(db) {
  const now = new Date();
  const me = db.users[db.currentUid];
  if (!me) return null;

  const myWin = currentPrayerWindow(me, now);
  const myActiveLog = db.prayerLogs[`${me.uid}|${myWin.date}`] || {};
  const myTodayLog = db.prayerLogs[`${me.uid}|${myWin.todayDate}`] || {};
  const isQuietNow = Boolean(me.quietUntilMs && me.quietUntilMs > now.getTime());

  const makeMemberView = (u) => {
    const isSelf = u.uid === me.uid;
    const win = currentPrayerWindow(u, now);
    const canSeeStatus = isSelf || u.shareStatus;
    const log = canSeeStatus ? db.prayerLogs[`${u.uid}|${win.date}`] || {} : null;
    const todayLog =
      canSeeStatus && win.todayDate !== win.date
        ? db.prayerLogs[`${u.uid}|${win.todayDate}`] || {}
        : log;
    const canSeeCity = isSelf || u.showCity;
    const alreadyNudgedByMe =
      !isSelf &&
      db.nudges.some(
        (n) =>
          n.toUid === u.uid &&
          n.localDate === win.date &&
          n.prayer === win.name &&
          n.fromUid === me.uid
      );
    return {
      uid: u.uid,
      displayName: u.displayName,
      isSelf,
      city: canSeeCity ? u.city : null,
      country: canSeeCity ? u.country : null,
      tz: canSeeCity ? u.tz : null,
      shareStatus: u.shareStatus,
      showCity: u.showCity,
      isPrivate: !isSelf && !u.shareStatus,
      alreadyNudgedByMe,
      phone: u.phone || '',
      facetimeId: u.facetimeId || '',
      characterStyle: u.characterStyle,
      preferredCharacter: u.preferredCharacter,
      localTimeFormatted: canSeeCity ? formatTimeInZone(now, u.tz) : null,
      currentPrayer: {
        name: win.name,
        arabic: win.arabic,
        date: win.date,
        startMs: win.start.getTime(),
        endMs: win.end.getTime(),
        startFormatted: canSeeCity ? formatTimeInZone(win.start, u.tz) : null,
        endFormatted: canSeeCity ? formatTimeInZone(win.end, u.tz) : null,
        nextName: win.nextName,
        nextStartFormatted: canSeeCity ? formatTimeInZone(win.nextStart, u.tz) : null,
        prayed: canSeeStatus ? Boolean(log && log[win.name]) : null,
        prayedAtMs: canSeeStatus && log && log[win.name] ? log[win.name] : null,
      },
      prayerLog: log,
      todayPrayerLog: todayLog,
    };
  };

  const circles = db.circles
    .filter((c) => c.memberUids.includes(me.uid))
    .map((c) => ({
      ...c,
      members: c.memberUids.map((id) => db.users[id]).filter(Boolean).map(makeMemberView),
    }));

  const myNudges = db.nudges.filter(
    (n) => n.toUid === me.uid && n.localDate === myWin.date && n.prayer === myWin.name && !n.suppressed
  );
  const senders = [];
  const seen = new Set();
  for (const n of myNudges) {
    if (seen.has(n.fromUid)) continue;
    seen.add(n.fromUid);
    const s = db.users[n.fromUid];
    if (s) senders.push({ uid: s.uid, displayName: s.displayName, characterId: n.characterId || 'teta' });
  }
  const names = senders.map((s) => s.displayName);
  const join =
    names.length === 1
      ? names[0]
      : names.length === 2
      ? `${names[0]} and ${names[1]}`
      : `${names[0]}, ${names[1]} and ${names.length - 2} others`;

  const sched = myWin.todaySchedule;
  return {
    serverTimeMs: now.getTime(),
    me: {
      ...me,
      hasPin: Boolean(me.pin),
      quietToday: isQuietNow,
      pushEnabled: typeof Notification !== 'undefined' && Notification.permission === 'granted',
      currentWindow: {
        name: myWin.name,
        arabic: myWin.arabic,
        date: myWin.date,
        todayDate: myWin.todayDate,
        startMs: myWin.start.getTime(),
        endMs: myWin.end.getTime(),
        startFormatted: formatTimeInZone(myWin.start, me.tz),
        endFormatted: formatTimeInZone(myWin.end, me.tz),
        nextName: myWin.nextName,
        nextStartMs: myWin.nextStart.getTime(),
        nextStartFormatted: formatTimeInZone(myWin.nextStart, me.tz),
      },
      activePrayerLog: myActiveLog,
      todayPrayerLog: myTodayLog,
      todayScheduleMs: {
        Fajr: sched.Fajr.getTime(),
        Sunrise: sched.Sunrise.getTime(),
        Dhuhr: sched.Dhuhr.getTime(),
        Asr: sched.Asr.getTime(),
        Maghrib: sched.Maghrib.getTime(),
        Isha: sched.Isha.getTime(),
      },
    },
    circles,
    activeNudge:
      senders.length > 0 && !myActiveLog[myWin.name] && !isQuietNow
        ? {
            prayer: myWin.name,
            arabic: myWin.arabic,
            date: myWin.date,
            startFormatted: formatTimeInZone(myWin.start, me.tz),
            endFormatted: formatTimeInZone(myWin.end, me.tz),
            senders,
            summaryLine: `${join} ${senders.length === 1 ? 'is' : 'are'} thinking of you`,
            latestCharacterId: senders[senders.length - 1].characterId || 'teta',
          }
        : null,
  };
}

function loadPendingConfirms() {
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(PENDING_CONFIRMS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function savePendingConfirms(list) {
  try {
    if (typeof localStorage === 'undefined') return;
    if (!list || list.length === 0) {
      localStorage.removeItem(PENDING_CONFIRMS_KEY);
    } else {
      localStorage.setItem(PENDING_CONFIRMS_KEY, JSON.stringify(list));
    }
  } catch {
    // ignore storage quota errors
  }
}

function queuePendingConfirm(uid, prayer, date, unconfirm, atMs = Date.now()) {
  const list = loadPendingConfirms().filter(
    (item) => !(item.uid === uid && item.prayer === prayer && item.date === date)
  );
  list.push({ uid, prayer, date, unconfirm: Boolean(unconfirm), atMs });
  savePendingConfirms(list);
}

async function flushPendingConfirms() {
  const pending = loadPendingConfirms();
  if (pending.length === 0 || !authToken) return;
  const remaining = [];
  for (const item of pending) {
    try {
      await apiFetch('/api/prayers/confirm', {
        method: 'POST',
        body: JSON.stringify({
          prayer: item.prayer,
          date: item.date,
          unconfirm: Boolean(item.unconfirm),
        }),
      });
    } catch (err) {
      if (!err.status) {
        remaining.push(item);
      }
    }
  }
  savePendingConfirms(remaining);
}

function saveLiveStateCache(state) {
  if (!state || !state.me) return;
  try {
    localStorage.setItem(LIVE_STATE_CACHE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage quota errors
  }
}

function loadLiveStateCache() {
  try {
    const raw = localStorage.getItem(LIVE_STATE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return revalidateCachedLiveState(parsed, new Date());
  } catch {
    return null;
  }
}

export function revalidateCachedLiveState(cached, now = new Date()) {
  if (!cached || !cached.me) return null;
  try {
    const me = cached.me;
    const nowMs = now.getTime();
    const myWin = currentPrayerWindow(me, now);
    const sched = myWin.todaySchedule;
    const prevWinDate = me.currentWindow && me.currentWindow.date;
    const prevTodayDate = me.currentWindow && me.currentWindow.todayDate;

    const logsByDate = {};
    if (prevTodayDate && me.todayPrayerLog) {
      logsByDate[prevTodayDate] = { ...me.todayPrayerLog };
    }
    if (prevWinDate && me.activePrayerLog) {
      logsByDate[prevWinDate] = { ...(logsByDate[prevWinDate] || {}), ...me.activePrayerLog };
    }
    for (const item of loadPendingConfirms()) {
      if (item.uid === me.uid && item.date && item.prayer) {
        logsByDate[item.date] = { ...(logsByDate[item.date] || {}) };
        if (item.unconfirm) delete logsByDate[item.date][item.prayer];
        else logsByDate[item.date][item.prayer] = item.atMs || nowMs;
      }
    }

    const activeLog = logsByDate[myWin.date] ? { ...logsByDate[myWin.date] } : {};
    const todayLog = logsByDate[myWin.todayDate] ? { ...logsByDate[myWin.todayDate] } : {};

    const isQuietNow =
      me.quietUntilMs !== undefined
        ? Boolean(me.quietUntilMs && me.quietUntilMs > nowMs)
        : Boolean(me.quietToday && prevTodayDate === myWin.todayDate);

    const prevNudge = cached.activeNudge || null;
    const activeNudge =
      prevNudge &&
      !isQuietNow &&
      prevNudge.date === myWin.date &&
      prevNudge.prayer === myWin.name &&
      !activeLog[myWin.name]
        ? {
            ...prevNudge,
            startFormatted: formatTimeInZone(myWin.start, me.tz),
            endFormatted: formatTimeInZone(myWin.end, me.tz),
          }
        : null;

    const circles = Array.isArray(cached.circles)
      ? cached.circles.map((c) => ({
          ...c,
          members: Array.isArray(c.members)
            ? c.members.map((m) => {
                if (m.isSelf || m.uid === me.uid) {
                  return {
                    ...m,
                    localTimeFormatted: formatTimeInZone(now, me.tz),
                    currentPrayer: {
                      name: myWin.name,
                      arabic: myWin.arabic,
                      date: myWin.date,
                      startMs: myWin.start.getTime(),
                      endMs: myWin.end.getTime(),
                      startFormatted: formatTimeInZone(myWin.start, me.tz),
                      endFormatted: formatTimeInZone(myWin.end, me.tz),
                      nextName: myWin.nextName,
                      nextStartFormatted: formatTimeInZone(myWin.nextStart, me.tz),
                      prayed: Boolean(activeLog[myWin.name]),
                      prayedAtMs: activeLog[myWin.name] || null,
                    },
                    prayerLog: activeLog,
                    todayPrayerLog: todayLog,
                  };
                }
                const updatedMember = { ...m };
                if (m.tz && m.showCity !== false) {
                  updatedMember.localTimeFormatted = formatTimeInZone(now, m.tz);
                }
                if (m.currentPrayer && m.currentPrayer.endMs && nowMs >= m.currentPrayer.endMs) {
                  updatedMember.alreadyNudgedByMe = false;
                }
                return updatedMember;
              })
            : [],
        }))
      : cached.circles;

    return {
      ...cached,
      offlineCached: true,
      serverTimeMs: nowMs,
      me: {
        ...me,
        quietToday: isQuietNow,
        currentWindow: {
          name: myWin.name,
          arabic: myWin.arabic,
          date: myWin.date,
          todayDate: myWin.todayDate,
          startMs: myWin.start.getTime(),
          endMs: myWin.end.getTime(),
          startFormatted: formatTimeInZone(myWin.start, me.tz),
          endFormatted: formatTimeInZone(myWin.end, me.tz),
          nextName: myWin.nextName,
          nextStartMs: myWin.nextStart.getTime(),
          nextStartFormatted: formatTimeInZone(myWin.nextStart, me.tz),
        },
        activePrayerLog: activeLog,
        todayPrayerLog: todayLog,
        todayScheduleMs: {
          Fajr: sched.Fajr.getTime(),
          Sunrise: sched.Sunrise.getTime(),
          Dhuhr: sched.Dhuhr.getTime(),
          Asr: sched.Asr.getTime(),
          Maghrib: sched.Maghrib.getTime(),
          Isha: sched.Isha.getTime(),
        },
      },
      circles,
      activeNudge,
    };
  } catch {
    return cached;
  }
}

function renderModeBanner() {
  const banner = $('mode-banner');
  const textEl = $('mode-banner-text');
  const controls = $('demo-banner-controls');
  const select = $('demo-member-select');
  if (!banner) return;

  if (backendMode === 'sandbox') {
    banner.hidden = false;
    textEl.textContent = 'Sample Family Preview';
    if (controls) controls.hidden = false;
    const db = loadSandboxDb();
    if (db && select) {
      select.textContent = '';
      Object.values(db.users).forEach((u) => {
        const opt = document.createElement('option');
        opt.value = u.uid;
        opt.textContent = `${u.displayName} (${u.city})`;
        if (u.uid === db.currentUid) opt.selected = true;
        select.appendChild(opt);
      });
    }
  } else if (appState && appState.offlineCached) {
    banner.hidden = false;
    textEl.textContent = 'Offline · showing local solar prayer schedule';
    if (controls) controls.hidden = true;
  } else {
    banner.hidden = true;
  }
}

// ==================== API CLIENT (LIVE OR SANDBOX) ====================
async function apiFetch(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (authToken) headers.Authorization = `Bearer ${authToken}`;
  const resp = await fetch(path, { ...options, headers });
  const data = await resp.json().catch(() => ({ ok: false, error: 'Unexpected server response' }));
  if (!resp.ok || data.ok === false) {
    const err = new Error(data.error || `Request failed (${resp.status})`);
    err.status = resp.status;
    err.code = data.code;
    throw err;
  }
  return data;
}

function syncSwToken(token) {
  if (!('serviceWorker' in navigator)) return;
  const payload = { type: 'SET_AUTH_TOKEN', token: token || null };
  if (navigator.serviceWorker.controller) {
    navigator.serviceWorker.controller.postMessage(payload);
  }
  navigator.serviceWorker.ready
    .then((reg) => {
      if (reg && reg.active) reg.active.postMessage(payload);
    })
    .catch(() => {});
}

async function refreshState() {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    if (!db) {
      appState = null;
      return;
    }
    appState = buildSandboxState(db);
    renderModeBanner();
    renderAll();
    return;
  }
  if (!authToken) {
    appState = null;
    return;
  }
  try {
    await flushPendingConfirms();
    const res = await apiFetch('/api/state');
    appState = res.state;
    saveLiveStateCache(appState);
    renderModeBanner();
    renderAll();
  } catch (err) {
    if (err.status === 401) {
      authToken = null;
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(LIVE_STATE_CACHE_KEY);
      localStorage.removeItem(PENDING_CONFIRMS_KEY);
      syncSwToken(null);
      showWelcome();
      return;
    }
    // Network drop / offline: preserve signed-in user's cached state with recalculated solar window!
    const fallback = loadLiveStateCache();
    if (fallback) {
      appState = fallback;
      renderModeBanner();
      renderAll();
    }
  }
}

// ==================== BOOTSTRAP ====================
async function boot() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        if (reg && reg.active) {
          reg.active.postMessage({ type: 'SET_AUTH_TOKEN', token: authToken || null });
        }
        syncSwToken(authToken);
      })
      .catch(() => {});

    navigator.serviceWorker.addEventListener('controllerchange', () => {
      syncSwToken(authToken);
    });

    navigator.serviceWorker.addEventListener('message', (ev) => {
      const msg = ev.data || {};
      if (msg.type === 'PUSH_RECEIVED' || msg.type === 'REFRESH_STATE') {
        refreshState();
      } else if (msg.type === 'NAVIGATE_URL' && msg.url) {
        handleUrlParams(new URL(msg.url, window.location.origin).searchParams);
      }
    });
  }

  if (broadcastChannel) {
    broadcastChannel.addEventListener('message', () => {
      if (backendMode === 'sandbox') refreshState();
    });
  }

  const [citiesRes, methodsRes, sampleRes] = await Promise.all([
    fetch('/cities.json').then((r) => r.json()),
    fetch('/prayer-methods.json').then((r) => r.json()),
    fetch('/sample-data.json').then((r) => r.json()).catch(() => null),
  ]);
  citiesData = citiesRes.cities || [];
  methodsData = methodsRes;
  sampleData = sampleRes;

  const params = new URLSearchParams(window.location.search);
  const forceDemo = params.get('demo') === '1';

  if (forceDemo) {
    backendMode = 'sandbox';
  } else {
    try {
      const cfg = await fetch('/api/config', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null));
      if (cfg && cfg.ok) {
        backendMode = 'live';
        serverConfig = cfg;
      } else if (authToken && loadLiveStateCache()) {
        backendMode = 'live';
      } else {
        backendMode = 'sandbox';
      }
    } catch {
      // Never demote an authenticated user with a cached live session to sandbox when temporarily offline!
      if (authToken && loadLiveStateCache()) {
        backendMode = 'live';
      } else {
        backendMode = 'sandbox';
      }
    }
  }

  wireEvents();

  if (backendMode === 'live') {
    if (authToken) {
      await refreshState();
      if (appState) {
        enterAuthenticatedShell();
        await handleUrlParams(params);
      } else {
        showWelcome(params);
      }
    } else {
      showWelcome(params);
    }
  } else {
    const existingDb = loadSandboxDb();
    if (existingDb || forceDemo) {
      const db = existingDb || seedSandboxFromSample();
      appState = buildSandboxState(db);
      enterAuthenticatedShell();
      await handleUrlParams(params);
    } else {
      showWelcome(params);
    }
  }
  renderModeBanner();

  window.addEventListener('online', () => {
    if (backendMode === 'live' && authToken) {
      refreshState();
    }
  });

  // Live countdown ticker & automatic day/prayer boundary rollover check
  setInterval(() => {
    if (!appState || !appState.me) return;
    const nowMs = Date.now();
    const win = appState.me.currentWindow;
    if (nowMs >= win.endMs) {
      refreshState();
    } else {
      updateCountdownRingLive(nowMs);
    }
  }, 1000);

  // Live circle sync every 20s when visible
  setInterval(() => {
    if (document.visibilityState === 'visible' && appState) {
      refreshState();
      if (activeTab === 'chat' && activeChatPeerUid) {
        loadChatMessages(activeChatPeerUid);
      }
    }
  }, 20000);

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && appState) refreshState();
  });
}

async function handleUrlParams(params) {
  const joinCode = params.get('join');
  if (joinCode && appState) {
    try {
      await actionJoinCircle(joinCode);
      switchTab('circle');
      window.history.replaceState({}, '', '/');
    } catch (e) {
      toast(e.message);
    }
  }

  const action = params.get('action');
  const prayerParam = params.get('prayer');
  const dateParam = params.get('date');
  if (action === 'prayed' && appState) {
    await actionConfirmPrayer(prayerParam || appState.me.currentWindow.name, dateParam || null);
    window.history.replaceState({}, '', '/');
    return;
  }
  if (action === 'snooze' && appState) {
    await actionSnoozePrayer(prayerParam || appState.me.currentWindow.name);
    window.history.replaceState({}, '', '/');
    return;
  }

  const screen = params.get('screen');
  if (screen === 'reminder' && appState) {
    openReminderOverlay();
    window.history.replaceState({}, '', '/');
  } else if (screen === 'chat' && appState) {
    const peer = params.get('peer');
    if (peer) activeChatPeerUid = peer;
    switchTab('chat');
    window.history.replaceState({}, '', '/');
  } else if (screen === 'circle' && appState) {
    switchTab('circle');
    window.history.replaceState({}, '', '/');
  }
}

// ==================== SCREEN VISIBILITY ====================
function showWelcome(params = new URLSearchParams(window.location.search)) {
  $('screen-loading').hidden = true;
  $('authenticated-shell').hidden = true;
  $('screen-welcome').hidden = false;
  $('btn-enter-demo').hidden = false;
  $('wrap-access-code').hidden = !serverConfig.requiresAccessCode;

  const joinCode = params.get('join');
  if (joinCode) {
    $('welcome-extra-fields').hidden = false;
    $('in-invite-code').value = joinCode.toUpperCase();
  }
  if (serverConfig.requiresAccessCode) {
    $('welcome-extra-fields').hidden = false;
  }
  renderModeBanner();
}

function enterAuthenticatedShell() {
  $('screen-loading').hidden = true;
  $('screen-welcome').hidden = true;
  $('authenticated-shell').hidden = false;
  renderModeBanner();
  renderAll();
}

function switchTab(tab) {
  activeTab = tab;
  $('view-home').hidden = tab !== 'home';
  $('view-circle').hidden = tab !== 'circle';
  $('view-chat').hidden = tab !== 'chat';
  $('view-settings').hidden = tab !== 'settings';
  $('view-characters').hidden = tab !== 'characters';

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    const t = btn.dataset.tab;
    const isActive = t === tab || (tab === 'characters' && t === 'settings');
    btn.classList.toggle('active', isActive);
  });

  if (tab === 'chat') {
    ensureChatPeerSelected();
    renderChatView();
    if (activeChatPeerUid) loadChatMessages(activeChatPeerUid);
  } else if (tab === 'characters') {
    renderCharactersView();
  } else {
    renderAll();
  }
}

// ==================== RENDERING ====================
function getActiveCircle() {
  if (!appState || !appState.circles || appState.circles.length === 0) return null;
  const match = appState.circles.find((c) => c.circleId === selectedCircleId);
  if (match) return match;
  selectedCircleId = appState.circles[0].circleId;
  return appState.circles[0];
}

function renderAll() {
  if (!appState || !appState.me) return;
  renderHomeView();
  renderCircleView();
  renderSettingsView();
  if (activeTab === 'characters') renderCharactersView();
  if (activeTab === 'chat') renderChatView();
}

function updateCountdownRingLive(nowMs = Date.now()) {
  if (!appState || !appState.me) return;
  const win = appState.me.currentWindow;
  const total = Math.max(60000, win.endMs - win.startMs);
  const remaining = Math.max(0, win.endMs - nowMs);
  const fractionRemaining = Math.min(1, Math.max(0, remaining / total));
  const dashOffset = RING_CIRCUMFERENCE * (1 - fractionRemaining);

  const arc = $('ring-arc');
  if (arc) {
    arc.setAttribute('stroke-dasharray', RING_CIRCUMFERENCE.toFixed(2));
    arc.setAttribute('stroke-dashoffset', dashOffset.toFixed(2));
  }
  $('ring-remaining').textContent = `${formatDuration(remaining)} remaining`;
}

function renderHomeView() {
  const me = appState.me;
  const win = me.currentWindow;

  $('home-user-name').textContent = me.displayName;
  $('ring-arabic').textContent = win.arabic;
  $('ring-prayer').textContent = win.name;
  $('ring-window').textContent = `Started ${win.startFormatted} · ${win.nextName} at ${win.nextStartFormatted} · Timetable ›`;
  updateCountdownRingLive();

  // Bell indicator dot
  $('bell-dot').hidden = !appState.activeNudge;

  // 5-Prayer Pill Strip
  const pillsEl = $('home-prayer-pills');
  pillsEl.textContent = '';
  const todayLog = me.todayPrayerLog || {};
  const activeLog = me.activePrayerLog || {};
  const schedMs = me.todayScheduleMs || {};

  PRAYERS.forEach((p) => {
    const isCurrent = p === win.name;
    const isPrayed = isCurrent ? Boolean(activeLog[p]) : Boolean(todayLog[p]);
    const pTimeStr = schedMs[p] ? formatTimeInZone(new Date(schedMs[p]), me.tz) : '';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `prayer-pill${isPrayed ? ' prayed' : ''}${isCurrent ? ' current' : ''}`;
    btn.setAttribute('aria-pressed', String(isPrayed));
    const timeSuffix = pTimeStr ? ` (${pTimeStr})` : '';
    btn.title = isPrayed
      ? `${p}${timeSuffix} — prayed (tap to undo)`
      : `Mark ${p}${timeSuffix} as prayed`;
    if (isPrayed) btn.appendChild(createCheckSvg(12, 3));
    const lbl = document.createElement('span');
    lbl.textContent = p;
    btn.appendChild(lbl);
    btn.addEventListener('click', () => {
      const targetDate = isCurrent ? win.date : win.todayDate;
      actionConfirmPrayer(p, targetDate, isPrayed);
    });
    pillsEl.appendChild(btn);
  });

  // Primary I Prayed Button
  const currentPrayed = Boolean(activeLog[win.name]);
  const primaryBtn = $('btn-home-prayed');
  primaryBtn.classList.toggle('confirmed', currentPrayed);
  $('btn-home-prayed-label').textContent = currentPrayed
    ? `Prayed ${win.name} · Alhamdulillah`
    : `I prayed ${win.name}`;
  $('home-primary-hint').textContent = me.shareStatus
    ? 'Your circle will see a quiet checkmark'
    : 'Private mode — recorded just for you';

  // Incoming Nudge Banner
  const incomingCard = $('home-incoming-card');
  if (appState.activeNudge) {
    incomingCard.hidden = false;
    $('home-incoming-title').textContent = appState.activeNudge.summaryLine;
  } else {
    incomingCard.hidden = true;
  }

  // Circle Strip & Cross-Circle Nudge Suggestion Card
  const circle = getActiveCircle();
  const stripEl = $('home-avatar-strip');
  stripEl.textContent = '';

  if (!circle) {
    $('home-circle-count').textContent = '';
    $('home-empty-circle').hidden = false;
    $('home-nudge-card').hidden = true;
  } else {
    $('home-empty-circle').hidden = true;
    const sharingMembers = circle.members.filter((m) => m.shareStatus);
    const prayedMembers = sharingMembers.filter((m) => m.currentPrayer && m.currentPrayer.prayed);
    const samePrayerHome =
      sharingMembers.length > 0 &&
      sharingMembers.every((m) => m.currentPrayer && m.currentPrayer.name === win.name);
    $('home-circle-count').textContent =
      sharingMembers.length > 0
        ? samePrayerHome
          ? `${prayedMembers.length} of ${sharingMembers.length} prayed ${win.name}`
          : `${prayedMembers.length} of ${sharingMembers.length} prayed current prayer`
        : `${circle.members.length} members`;

    // Find a circle member (not me) who hasn't prayed their current prayer yet (prioritizing un-nudged members)
    const candidate =
      circle.members.find(
        (m) =>
          !m.isSelf &&
          !m.isPrivate &&
          m.currentPrayer &&
          !m.currentPrayer.prayed &&
          !m.alreadyNudgedByMe
      ) ||
      circle.members.find(
        (m) => !m.isSelf && !m.isPrivate && m.currentPrayer && !m.currentPrayer.prayed
      );
    const nudgeCard = $('home-nudge-card');
    if (candidate) {
      nudgeCard.hidden = false;
      const where = candidate.city ? ` in ${candidate.city}` : '';
      $('home-nudge-title').textContent = `${candidate.displayName} is at ${candidate.currentPrayer.name}${where}`;
      $('home-nudge-body').textContent = candidate.alreadyNudgedByMe
        ? `✓ Reminder sent for ${candidate.currentPrayer.name}`
        : 'Send a little light their way.';
      $('btn-home-nudge').onclick = () => openNudgeSheet(candidate);
    } else {
      nudgeCard.hidden = true;
    }

    // Render avatars (others first as in Main.dc.html, or full circle)
    const displayMembers = circle.members.filter((m) => !m.isSelf);
    const listToShow = displayMembers.length > 0 ? displayMembers : circle.members;
    listToShow.forEach((m) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'strip-member-btn';
      const ring = document.createElement('div');
      const prayed = Boolean(m.currentPrayer && m.currentPrayer.prayed);
      ring.className = `avatar-ring${prayed ? ' prayed' : ''}${m.isPrivate ? ' private' : ''}`;
      ring.textContent = (m.displayName || '?').charAt(0).toUpperCase();
      if (prayed) {
        const badge = document.createElement('div');
        badge.className = 'avatar-check';
        badge.appendChild(createCheckSvg(11, 3.4));
        ring.appendChild(badge);
      }
      const nameSpan = document.createElement('span');
      nameSpan.className = 'strip-name';
      nameSpan.textContent = m.isSelf ? 'You' : m.displayName;
      btn.append(ring, nameSpan);
      btn.addEventListener('click', () => {
        if (m.isSelf) switchTab('circle');
        else openNudgeSheet(m);
      });
      stripEl.appendChild(btn);
    });
  }

  // Push Prompt Card
  renderHomePushBanner();
}

function renderHomePushBanner() {
  const pushCard = $('home-push-card');
  if (!appState || appState.me.pushEnabled) {
    pushCard.hidden = true;
    return;
  }
  const standalone =
    window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  if (isIOS && !standalone) {
    pushCard.hidden = false;
    $('home-push-hint').textContent =
      'On iPhone: tap Share ↑ → Add to Home Screen, then open Waqt to get lock-screen reminders.';
    $('btn-home-enable-push').textContent = 'How';
    $('btn-home-enable-push').onclick = () =>
      toast('Tap Safari Share ↑ → "Add to Home Screen", then open Waqt from your Home Screen.', 4200);
    return;
  }
  if ('Notification' in window && Notification.permission !== 'denied') {
    pushCard.hidden = false;
    $('home-push-hint').textContent = 'Receive gentle prayer & family nudges on your lock screen.';
    $('btn-home-enable-push').textContent = 'Turn on';
    $('btn-home-enable-push').onclick = () => enableWebPush();
  } else {
    pushCard.hidden = true;
  }
}

function renderCircleView() {
  const circles = appState.circles || [];
  const tabsEl = $('circle-switcher-tabs');
  tabsEl.textContent = '';

  circles.forEach((c) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `pill-tab${c.circleId === (getActiveCircle() && getActiveCircle().circleId) ? ' active' : ''}`;
    b.textContent = c.name;
    b.addEventListener('click', () => {
      selectedCircleId = c.circleId;
      renderAll();
    });
    tabsEl.appendChild(b);
  });

  const newBtn = document.createElement('button');
  newBtn.type = 'button';
  newBtn.className = 'pill-tab dashed';
  newBtn.textContent = '+ New circle';
  newBtn.addEventListener('click', () => openCircleModal());
  tabsEl.appendChild(newBtn);

  const joinBtn = document.createElement('button');
  joinBtn.type = 'button';
  joinBtn.className = 'pill-tab';
  joinBtn.textContent = 'Join code';
  joinBtn.addEventListener('click', () => openCircleModal('join'));
  tabsEl.appendChild(joinBtn);

  const active = getActiveCircle();
  if (!active) {
    $('circle-screen-title').textContent = 'Your circle';
    $('circle-screen-sub').textContent = 'Invite the people you love';
    $('circle-content-wrap').hidden = true;
    $('circle-empty-state').hidden = false;
    return;
  }

  $('circle-content-wrap').hidden = false;
  $('circle-empty-state').hidden = true;
  $('circle-screen-title').textContent = active.name;

  const uniqueCities = new Set(active.members.map((m) => m.city).filter(Boolean));
  const cityCount = Math.max(1, uniqueCities.size);
  $('circle-screen-sub').textContent = `${active.members.length} ${
    active.members.length === 1 ? 'member' : 'members'
  } across ${cityCount} ${cityCount === 1 ? 'city' : 'cities'}`;

  // Privacy-preserving ratio: denominator is ONLY members with shareStatus === true
  const sharing = active.members.filter((m) => m.shareStatus);
  const done = sharing.filter((m) => m.currentPrayer && m.currentPrayer.prayed).length;
  const total = sharing.length;
  const remaining = Math.max(0, total - done);
  const myPrayer = appState.me.currentWindow.name;

  const ratioEl = $('circle-ratio');
  ratioEl.textContent = String(done);
  const denomSpan = document.createElement('span');
  denomSpan.textContent = `/${total}`;
  ratioEl.appendChild(denomSpan);

  const samePrayerCircle =
    sharing.length > 0 &&
    sharing.every((m) => m.currentPrayer && m.currentPrayer.name === myPrayer);
  const doneWord = NUMBER_WORDS[done] || String(done);
  $('circle-together-body').textContent =
    total === 0
      ? 'Everyone is in private status mode today.'
      : remaining === 0
      ? samePrayerCircle
        ? `All ${done} of you have prayed ${myPrayer}, alhamdulillah.`
        : `All ${done} of you have prayed your current prayer across time zones, alhamdulillah.`
      : samePrayerCircle
      ? `${doneWord} of you ${done === 1 ? 'has' : 'have'} prayed ${myPrayer}. ${
          NUMBER_WORDS[remaining] || remaining
        } more to go, in sha Allah.`
      : `${doneWord} of you ${done === 1 ? 'has' : 'have'} prayed their current prayer across time zones. ${
          NUMBER_WORDS[remaining] || remaining
        } more to go, in sha Allah.`;

  // Member rows
  const rowsEl = $('circle-member-rows');
  rowsEl.textContent = '';
  active.members.forEach((m) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'member-row';

    const prayed = Boolean(m.currentPrayer && m.currentPrayer.prayed);
    const av = document.createElement('div');
    av.className = `avatar-ring avatar-list${prayed ? ' prayed' : ''}${m.isPrivate ? ' private' : ''}`;
    av.textContent = (m.displayName || '?').charAt(0).toUpperCase();
    if (prayed) {
      const check = document.createElement('div');
      check.className = 'avatar-check';
      check.style.width = '18px';
      check.style.height = '18px';
      check.appendChild(createCheckSvg(10, 3.4));
      av.appendChild(check);
    }

    const info = document.createElement('div');
    info.style.flex = '1';
    info.style.minWidth = '0';

    const nameLine = document.createElement('div');
    nameLine.style.fontSize = '15px';
    nameLine.style.fontWeight = '600';
    nameLine.textContent = m.displayName;
    if (m.isSelf) {
      const youSpan = document.createElement('span');
      youSpan.style.color = 'var(--muted)';
      youSpan.style.fontWeight = '500';
      youSpan.textContent = ' (you)';
      nameLine.appendChild(youSpan);
    }

    const subLine = document.createElement('div');
    subLine.style.fontSize = '12.5px';
    subLine.style.color = 'var(--muted)';
    const locStr = m.city && m.country ? `${m.city}, ${m.country}` : 'City hidden';
    const pStr = m.currentPrayer
      ? m.localTimeFormatted
        ? `${m.currentPrayer.name} (${m.localTimeFormatted})`
        : m.currentPrayer.name
      : '';
    subLine.textContent = [locStr, pStr].filter(Boolean).join(' · ');
    info.append(nameLine, subLine);

    const right = document.createElement('div');
    right.style.display = 'flex';
    right.style.alignItems = 'center';
    right.style.gap = '6px';
    if (m.uid === active.ownerUid) {
      const badge = document.createElement('span');
      badge.className = 'badge-admin';
      badge.textContent = 'Admin';
      right.appendChild(badge);
      if (m.isPrivate || !m.shareStatus) {
        const lbl = document.createElement('span');
        lbl.className = 'status-private-lbl';
        lbl.textContent = 'Private';
        right.appendChild(lbl);
      } else if (prayed) {
        const lbl = document.createElement('span');
        lbl.className = 'status-sharing';
        lbl.textContent = 'Prayed';
        right.appendChild(lbl);
      }
    } else if (m.isPrivate || !m.shareStatus) {
      const lbl = document.createElement('span');
      lbl.className = 'status-private-lbl';
      lbl.textContent = 'Private';
      right.appendChild(lbl);
    } else {
      const lbl = document.createElement('span');
      lbl.className = 'status-sharing';
      lbl.textContent = prayed ? 'Prayed' : 'Sharing on';
      right.appendChild(lbl);
    }

    row.append(av, info, right);
    row.addEventListener('click', () => {
      if (m.isSelf) switchTab('settings');
      else openNudgeSheet(m);
    });
    rowsEl.appendChild(row);
  });

  $('circle-invite-code').textContent = active.inviteCode;
}

// ==================== SCREEN 3: CROSS-CIRCLE NUDGE SHEET ====================
function openNudgeSheet(member) {
  selectedNudgeMember = mergeMemberContact(member);
  selectedNudgeCharacter = appState.me.preferredCharacter || 'teta';

  const prayed = Boolean(member.currentPrayer && member.currentPrayer.prayed);
  const av = $('nudge-sheet-avatar');
  av.className = `avatar-ring${prayed ? ' prayed' : ''}${member.isPrivate ? ' private' : ''}`;
  av.style.width = '64px';
  av.style.height = '64px';
  av.style.fontSize = '30px';
  av.textContent = (member.displayName || '?').charAt(0).toUpperCase();

  $('nudge-sheet-name').textContent = member.displayName;
  const cityLabel =
    member.city && member.country ? `${member.city}, ${member.country}` : 'Circle member';
  $('nudge-sheet-city').textContent = [cityLabel, member.localTimeFormatted]
    .filter(Boolean)
    .join(' · ');
  $('nudge-sheet-arabic').textContent = (member.currentPrayer && member.currentPrayer.arabic) || '';

  const remMs = member.currentPrayer ? Math.max(0, member.currentPrayer.endMs - Date.now()) : 0;
  const remSuffix = remMs > 0 ? ` · ${formatDuration(remMs)} left` : '';
  const pName = (member.currentPrayer && member.currentPrayer.name) || 'Prayer';
  $('nudge-sheet-prayer-chip').textContent = `${pName} now${remSuffix}`;

  const sendBtn = $('btn-sheet-send-nudge');
  if (sendBtn) {
    if (prayed) {
      sendBtn.disabled = true;
      sendBtn.classList.add('confirmed');
      sendBtn.textContent = `✓ Prayed ${pName} · Alhamdulillah`;
    } else if (member.alreadyNudgedByMe) {
      sendBtn.disabled = true;
      sendBtn.classList.add('confirmed');
      sendBtn.textContent = `✓ Reminder sent for ${pName}`;
    } else {
      sendBtn.disabled = false;
      sendBtn.classList.remove('confirmed');
      sendBtn.innerHTML =
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.6 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/></svg> Send a gentle reminder';
    }
  }

  const activeCircle = getActiveCircle();
  const removeBtn = $('btn-sheet-remove-member');
  if (removeBtn) {
    const canRemove = Boolean(
      activeCircle && activeCircle.ownerUid === appState.me.uid && !member.isSelf
    );
    removeBtn.hidden = !canRemove;
    removeBtn.textContent = `Remove ${member.displayName} from circle`;
  }
  renderNudgeCharacterStrip();
  updateNudgePreviewText();
  $('sheet-nudge').hidden = false;
}

function renderNudgeCharacterStrip() {
  const strip = $('nudge-char-strip');
  strip.textContent = '';
  if (appState.me.characterStyle === 'off') {
    strip.hidden = true;
    return;
  }
  strip.hidden = false;
  const allowed =
    appState.me.characterStyle === 'symbols'
      ? CHARACTERS.filter((c) => c.symbol)
      : CHARACTERS.filter((c) => c.id !== 'hilal');

  allowed.forEach((c) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = `char-mini-chip${selectedNudgeCharacter === c.id ? ' active' : ''}`;
    chip.textContent = c.name;
    chip.addEventListener('click', () => {
      selectedNudgeCharacter = c.id;
      renderNudgeCharacterStrip();
      updateNudgePreviewText();
    });
    strip.appendChild(chip);
  });
}

function updateNudgePreviewText() {
  if (!selectedNudgeMember || !appState) return;
  const prayerName =
    (selectedNudgeMember.currentPrayer && selectedNudgeMember.currentPrayer.name) || 'Asr';
  $('nudge-preview-label').textContent = `WHAT ${selectedNudgeMember.displayName.toUpperCase()} WILL SEE`;
  const charObj = CHARACTERS.find((c) => c.id === selectedNudgeCharacter);
  const base = `${appState.me.displayName} is thinking of you for ${prayerName}. Pray when you're ready.`;
  $('nudge-preview-body').textContent =
    appState.me.characterStyle !== 'off' && charObj
      ? `${base} — "${charObj.line.replace('{prayer}', prayerName)}"`
      : base;
}

// ==================== 1-TAP WHATSAPP & FACETIME CALL SHEET ====================
function openCallSheet(member) {
  const enriched = mergeMemberContact(member);
  selectedCallMember = enriched;
  $('sheet-nudge').hidden = true;

  $('call-sheet-title').textContent = `Check in with ${enriched.displayName}`;
  $('call-sheet-sub').textContent = enriched.city
    ? [enriched.city, enriched.localTimeFormatted].filter(Boolean).join(' · ')
    : '1-tap family voice or video call';

  renderCallLinks();
  $('sheet-call').hidden = false;
}

function renderCallLinks() {
  const member = selectedCallMember;
  if (!member) return;
  const links = buildCallShortcuts(member, appState ? appState.me.displayName : '');
  const box = $('call-links-box');
  box.textContent = '';

  const addLink = (label, sublabel, href, extraClass = '') => {
    const a = document.createElement('a');
    a.href = href;
    if (href.startsWith('https://')) {
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
    }
    a.className = `call-action-link ${extraClass}`.trim();
    const left = document.createElement('div');
    const title = document.createElement('div');
    title.textContent = label;
    const sub = document.createElement('div');
    sub.style.fontSize = '12px';
    sub.style.color = 'var(--muted)';
    sub.style.fontWeight = '400';
    sub.textContent = sublabel;
    left.append(title, sub);
    const arrow = document.createElement('span');
    arrow.style.color = 'var(--gold)';
    arrow.textContent = '↗';
    a.append(left, arrow);
    box.appendChild(a);
  };

  addLink(
    `WhatsApp ${member.displayName}`,
    links.hasSavedContact ? 'Opens 1-tap WhatsApp chat & video/voice call' : 'Opens WhatsApp to pick contact',
    links.whatsappUrl,
    'whatsapp'
  );

  if (links.facetimeVideoUrl) {
    addLink('FaceTime Video', `1-tap FaceTime video call (${member.facetimeId || member.phone})`, links.facetimeVideoUrl);
    addLink('FaceTime Audio', '1-tap FaceTime audio check-in', links.facetimeAudioUrl);
  }
  if (links.telUrl) {
    addLink('Phone Call', `Call ${member.phone}`, links.telUrl);
  }

  $('call-missing-contact').hidden = false;
  $('in-peer-phone').value = member.facetimeId || member.phone || '';
}

// ==================== SCREEN 4: REMINDER RECEIVED OVERLAY ====================
function openReminderOverlay() {
  if (!appState || !appState.me) return;
  const me = appState.me;
  const win = me.currentWindow;
  const nudge = appState.activeNudge || {
    prayer: win.name,
    arabic: win.arabic,
    startFormatted: win.startFormatted,
    endFormatted: win.endFormatted,
    senders: [
      { uid: 's1', displayName: 'Layla', characterId: 'teta' },
      { uid: 's2', displayName: 'Mama', characterId: 'teta' },
    ],
    summaryLine: 'Layla and Mama are thinking of you',
    latestCharacterId: me.preferredCharacter || 'teta',
  };

  const firstSender = nudge.senders[0] ? nudge.senders[0].displayName : 'Your circle';
  $('rem-banner-line').textContent = `${firstSender} is thinking of you for ${nudge.prayer}.`;

  // Character illustration spot (respecting characterStyle: characters | symbols | off)
  const charSpot = $('rem-char-spot');
  charSpot.innerHTML = '';
  if (me.characterStyle !== 'off') {
    let charId = nudge.latestCharacterId || 'teta';
    if (me.characterStyle === 'symbols' && charId !== 'hilal' && charId !== 'fanous') {
      charId = 'fanous';
    }
    if (CHARACTER_SVGS[charId]) {
      charSpot.innerHTML = CHARACTER_SVGS[charId];
    }
  }

  const stack = $('rem-sender-stack');
  stack.textContent = '';
  nudge.senders.slice(0, 4).forEach((s) => {
    const d = document.createElement('div');
    d.className = 'sender-stack-avatar';
    d.textContent = (s.displayName || '?').charAt(0).toUpperCase();
    stack.appendChild(d);
  });

  $('rem-thinking-line').textContent = nudge.summaryLine;
  $('rem-arabic').textContent = nudge.arabic || PRAYER_ARABIC[nudge.prayer] || win.arabic;
  $('rem-prayer').textContent = nudge.prayer;
  $('rem-window').textContent = `Started ${nudge.startFormatted} · ends ${nudge.endFormatted}`;

  $('overlay-reminder').hidden = false;
}

// ==================== SCREEN 6: CHAT ====================
function getAllPeers() {
  if (!appState || !appState.circles) return [];
  const map = new Map();
  for (const c of appState.circles) {
    for (const m of c.members) {
      if (!m.isSelf && !map.has(m.uid)) map.set(m.uid, m);
    }
  }
  return [...map.values()];
}

function ensureChatPeerSelected() {
  const peers = getAllPeers();
  if (peers.length === 0) {
    activeChatPeerUid = null;
    return;
  }
  if (!activeChatPeerUid || !peers.some((p) => p.uid === activeChatPeerUid)) {
    activeChatPeerUid = peers[0].uid;
  }
}

async function loadChatMessages(peerUid) {
  if (!peerUid) return;
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    if (!db) return;
    chatMessages = db.messages.filter(
      (m) =>
        (m.fromUid === db.currentUid && m.toUid === peerUid) ||
        (m.fromUid === peerUid && m.toUid === db.currentUid)
    );
    renderChatStream();
    return;
  }
  try {
    const res = await apiFetch(`/api/messages?peerUid=${encodeURIComponent(peerUid)}`);
    chatMessages = res.messages || [];
    renderChatStream();
  } catch {
    // ignore transient error
  }
}

function renderChatView() {
  const peers = getAllPeers();
  const strip = $('chat-peer-strip');
  strip.textContent = '';

  peers.forEach((p) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `peer-chip${p.uid === activeChatPeerUid ? ' active' : ''}`;
    btn.textContent = p.displayName;
    btn.addEventListener('click', () => {
      activeChatPeerUid = p.uid;
      renderChatView();
      loadChatMessages(p.uid);
    });
    strip.appendChild(btn);
  });

  const peer = peers.find((p) => p.uid === activeChatPeerUid);
  if (!peer) {
    $('chat-peer-avatar').textContent = 'W';
    $('chat-peer-name').textContent = 'Family Chat';
    $('chat-peer-meta').textContent = 'Invite family to your circle to start chatting';
    $('chat-input').placeholder = 'Join a circle first…';
    $('chat-input').disabled = true;
    $('btn-chat-call').disabled = true;
    $('chat-quick-chips').textContent = '';
    $('chat-stream').textContent = '';
    return;
  }

  $('chat-input').disabled = false;
  $('btn-chat-call').disabled = false;
  const quickStrip = $('chat-quick-chips');
  if (quickStrip) {
    quickStrip.textContent = '';
    ['Alhamdulillah', 'JazakAllah khair', 'Praying now', 'Make dua for me', 'Aameen'].forEach((phrase) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'chat-quick-chip';
      chip.textContent = phrase;
      chip.addEventListener('click', () => {
        $('chat-input').value = phrase;
        $('chat-form').requestSubmit();
      });
      quickStrip.appendChild(chip);
    });
  }
  $('chat-peer-avatar').textContent = (peer.displayName || '?').charAt(0).toUpperCase();
  $('chat-peer-name').textContent = peer.displayName;
  const loc = peer.city && peer.country ? `${peer.city}, ${peer.country}` : 'Circle member';
  $('chat-peer-meta').textContent = [loc, peer.localTimeFormatted].filter(Boolean).join(' · ');
  $('chat-input').placeholder = `Write to ${peer.displayName}`;
  $('btn-chat-call').onclick = () => openCallSheet(peer);
  renderChatStream();
}

function renderChatStream() {
  const stream = $('chat-stream');
  stream.textContent = '';
  const peers = getAllPeers();
  const peer = peers.find((p) => p.uid === activeChatPeerUid);
  if (!peer || !appState) return;

  const dateLbl = document.createElement('div');
  dateLbl.className = 'chat-date-lbl';
  dateLbl.textContent = 'Today';
  stream.appendChild(dateLbl);

  if (chatMessages.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'chat-date-lbl';
    empty.style.marginTop = '24px';
    empty.textContent = `Send a warm note or prayer check-in to ${peer.displayName}.`;
    stream.appendChild(empty);
    return;
  }

  chatMessages.forEach((m) => {
    const isMine = m.fromUid === appState.me.uid;
    if (m.kind === 'nudge') {
      const pill = document.createElement('div');
      pill.className = 'chat-sys-nudge';
      pill.textContent = isMine
        ? `♥ You sent a reminder for ${m.prayer || 'prayer'}`
        : `♥ ${peer.displayName} sent a reminder for ${m.prayer || 'prayer'}`;
      stream.appendChild(pill);
    } else if (m.kind === 'confirmed') {
      const card = document.createElement('div');
      card.className = 'chat-confirmed-card';
      const icon = document.createElement('div');
      icon.className = 'chat-confirmed-icon';
      icon.appendChild(createCheckSvg(18, 3));
      const textWrap = document.createElement('div');
      const title = document.createElement('div');
      title.style.fontSize = '14.5px';
      title.style.fontWeight = '700';
      title.style.color = 'var(--prayed)';
      title.textContent = isMine
        ? `You prayed ${m.prayer || ''}`
        : `${peer.displayName} prayed ${m.prayer || ''}`;
      const sub = document.createElement('div');
      sub.style.fontSize = '12px';
      sub.style.color = 'var(--muted)';
      const tStr = new Date(m.createdAtMs).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
      sub.textContent = isMine ? `${tStr} · shared with ${peer.displayName}` : `${tStr} · thanks to you`;
      textWrap.append(title, sub);
      card.append(icon, textWrap);
      stream.appendChild(card);
    } else {
      const b = document.createElement('div');
      b.className = `chat-bubble ${isMine ? 'out' : 'in'}`;
      b.textContent = m.body;
      stream.appendChild(b);
    }
  });

  stream.scrollTop = stream.scrollHeight;
}

// ==================== SCREEN 7: CHARACTERS ====================
function renderCharactersView() {
  if (!appState || !appState.me) return;
  const me = appState.me;
  const prayerName = me.currentWindow ? me.currentWindow.name : 'Asr';

  document.querySelectorAll('[data-char-style]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.charStyle === me.characterStyle);
  });

  const grid = $('characters-grid');
  grid.textContent = '';

  CHARACTERS.forEach((c) => {
    const dimmed =
      me.characterStyle === 'off' || (me.characterStyle === 'symbols' && !c.symbol);
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `char-card${me.preferredCharacter === c.id ? ' selected' : ''}`;
    if (dimmed) card.style.opacity = '0.45';

    const art = document.createElement('div');
    art.innerHTML = CHARACTER_SVGS[c.id];

    const name = document.createElement('div');
    name.className = 'char-name';
    name.textContent = c.name;

    const role = document.createElement('div');
    role.className = 'char-role';
    role.textContent = c.role;

    const line = document.createElement('div');
    line.className = 'char-line';
    line.textContent = c.line.replace('{prayer}', prayerName);

    card.append(art, name, role, line);
    card.addEventListener('click', async () => {
      const patch = { preferredCharacter: c.id };
      if (me.characterStyle === 'off') patch.characterStyle = c.symbol ? 'symbols' : 'characters';
      else if (me.characterStyle === 'symbols' && !c.symbol) patch.characterStyle = 'characters';
      await actionUpdateMe(patch);
      toast(`${c.name} selected as your reminder friend`);
    });
    grid.appendChild(card);
  });
}

// ==================== SCREEN 8: SETTINGS ====================
function renderSettingsView() {
  const me = appState.me;
  $('set-val-location').textContent = `${me.city}, ${me.country}`;
  const preset = METHOD_PRESETS[me.method] || METHOD_PRESETS.MuslimWorldLeague;
  $('set-val-method').textContent = preset.shortLabel || preset.label;

  const off = Number(me.remindOffsetMinutes);
  $('set-val-remind').textContent =
    off < 0 ? 'Off' : off === 0 ? 'At prayer time' : `${off}m before`;

  setSwitchState($('sw-set-share'), me.shareStatus);
  setSwitchState($('sw-set-city'), me.showCity);
  setSwitchState($('sw-set-circle-rem'), me.circleReminders);
  setSwitchState($('sw-set-quiet'), me.quietToday);
  setSwitchState($('sw-set-summary'), me.eveningSummary);

  $('set-val-contact').textContent = me.phone || me.facetimeId ? 'Saved' : 'Add';
  $('set-val-push').textContent = me.pushEnabled ? 'Active · Test' : 'Turn on';
  $('set-val-characters').textContent =
    me.characterStyle === 'characters'
      ? 'Characters'
      : me.characterStyle === 'symbols'
      ? 'Moon & lantern'
      : 'Off';
}

function setSwitchState(btn, checked) {
  if (!btn) return;
  btn.setAttribute('aria-checked', String(Boolean(checked)));
}

// ==================== DYNAMIC SETTINGS MODALS ====================
function openDynamicSheet(renderFn) {
  const container = $('dyn-sheet-body');
  container.textContent = '';
  renderFn(container);
  $('sheet-Dynamic').hidden = false;
}

function closeDynamicSheet() {
  $('sheet-Dynamic').hidden = true;
}

function openLocationPickerModal() {
  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = 'Choose your city';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'text-input';
    input.style.marginTop = '12px';
    input.placeholder = 'Search 126 cities or country…';

    const gpsBtn = document.createElement('button');
    gpsBtn.type = 'button';
    gpsBtn.className = 'btn-outline';
    gpsBtn.style.marginTop = '10px';
    gpsBtn.style.height = '44px';
    gpsBtn.textContent = 'Use my current location';
    gpsBtn.addEventListener('click', () => {
      detectNearestCity(async (found) => {
        const def = (methodsData.defaultsByCountry && methodsData.defaultsByCountry[found.country]) || methodsData.defaultsByCountry.default;
        await actionUpdateMe({
          city: found.name,
          country: found.country,
          lat: found.lat,
          lon: found.lon,
          tz: found.tz,
          method: def.method,
          asrMethod: def.asrMethod,
        });
        closeDynamicSheet();
        toast(`Location updated to ${found.name} (${found.tz})`);
      });
    });

    const listWrap = document.createElement('div');
    listWrap.style.maxHeight = '280px';
    listWrap.style.overflowY = 'auto';
    listWrap.style.marginTop = '10px';

    const renderList = (q) => {
      listWrap.textContent = '';
      const needle = q.trim().toLowerCase();
      const matches = citiesData
        .filter((c) => !needle || `${c.name}, ${c.country}`.toLowerCase().includes(needle))
        .slice(0, 40);
      matches.forEach((c) => {
        const opt = document.createElement('button');
        opt.type = 'button';
        opt.className = 'city-option';
        const left = document.createElement('span');
        left.textContent = `${c.name}, ${c.country}`;
        const right = document.createElement('span');
        right.className = 'city-option-tz';
        right.textContent = c.tz;
        opt.append(left, right);
        opt.addEventListener('click', async () => {
          const def =
            (methodsData.defaultsByCountry && methodsData.defaultsByCountry[c.country]) ||
            methodsData.defaultsByCountry.default;
          await actionUpdateMe({
            city: c.name,
            country: c.country,
            lat: c.lat,
            lon: c.lon,
            tz: c.tz,
            method: def.method,
            asrMethod: def.asrMethod,
          });
          closeDynamicSheet();
          toast(`Location set to ${c.name}, ${c.country}`);
        });
        listWrap.appendChild(opt);
      });
    };

    input.addEventListener('input', () => renderList(input.value));
    renderList('');
    box.append(title, input, gpsBtn, listWrap);
  });
}

function openMethodPickerModal() {
  const me = appState.me;
  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = 'Prayer calculation';

    const makeSelect = (labelTxt, options, currentVal, onChange) => {
      const lbl = document.createElement('label');
      lbl.className = 'field-label';
      lbl.style.marginTop = '12px';
      lbl.textContent = labelTxt;
      const sel = document.createElement('select');
      sel.className = 'text-input';
      options.forEach(([val, text]) => {
        const o = document.createElement('option');
        o.value = val;
        o.textContent = text;
        if (val === currentVal) o.selected = true;
        sel.appendChild(o);
      });
      sel.addEventListener('change', () => onChange(sel.value));
      lbl.appendChild(sel);
      return lbl;
    };

    const methodEntries = Object.entries(METHOD_PRESETS).map(([k, v]) => [k, v.label]);
    box.appendChild(
      makeSelect('Calculation method', methodEntries, me.method, (v) =>
        actionUpdateMe({ method: v }).then(() => toast('Calculation method updated'))
      )
    );

    box.appendChild(
      makeSelect(
        'Asr juristic method',
        [
          ['standard', 'Standard (Shafi’i, Maliki, Hanbali)'],
          ['hanafi', 'Hanafi (later Asr shadow)'],
        ],
        me.asrMethod,
        (v) => actionUpdateMe({ asrMethod: v }).then(() => toast('Asr method updated'))
      )
    );

    const highLatNote = Math.abs(me.lat) > 48 ? ' (Active for your latitude > 48°)' : ' (Used above 48° latitude)';
    box.appendChild(
      makeSelect(
        `High-latitude rule${highLatNote}`,
        [
          ['auto', 'Automatic (1/7 above 48° · recommended)'],
          ['middleOfTheNight', 'Middle of the Night (1/2)'],
          ['seventhOfTheNight', 'One-Seventh of the Night (1/7)'],
          ['twilightAngle', 'Twilight Angle (Angle / 60)'],
        ],
        me.highLatitudeRule || 'auto',
        (v) => actionUpdateMe({ highLatitudeRule: v }).then(() => toast('High-latitude rule updated'))
      )
    );
  });
}

function openRemindTimingModal() {
  const me = appState.me;
  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = 'Remind me';

    const choices = [
      [0, 'At prayer time'],
      [5, '5 minutes before'],
      [10, '10 minutes before'],
      [15, '15 minutes before'],
      [-1, 'Off (only family nudges)'],
    ];

    const list = document.createElement('div');
    list.style.marginTop = '12px';
    list.style.display = 'flex';
    list.style.flexDirection = 'column';
    list.style.gap = '8px';

    choices.forEach(([val, txt]) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = Number(me.remindOffsetMinutes) === val ? 'btn-gold' : 'btn-outline';
      b.style.height = '48px';
      b.textContent = txt;
      b.addEventListener('click', async () => {
        await actionUpdateMe({ remindOffsetMinutes: val });
        closeDynamicSheet();
        toast(`Personal reminder: ${txt}`);
      });
      list.appendChild(b);
    });
    box.append(title, list);
  });
}

function openContactAndPinModal() {
  const me = appState.me;
  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = 'Family calls & PIN';

    const sub = document.createElement('div');
    sub.style.fontSize = '12.5px';
    sub.style.color = 'var(--muted)';
    sub.style.marginTop = '4px';
    sub.textContent = 'Shared only with your circle so family can call you in 1 tap on WhatsApp or FaceTime.';

    const phoneLbl = document.createElement('label');
    phoneLbl.className = 'field-label';
    phoneLbl.style.marginTop = '12px';
    phoneLbl.textContent = 'WhatsApp / mobile number (with country code)';
    const phoneIn = document.createElement('input');
    phoneIn.type = 'tel';
    phoneIn.className = 'text-input';
    phoneIn.placeholder = '+971 50 123 4567';
    phoneIn.value = me.phone || '';
    phoneLbl.appendChild(phoneIn);

    const ftLbl = document.createElement('label');
    ftLbl.className = 'field-label';
    ftLbl.style.marginTop = '10px';
    ftLbl.textContent = 'FaceTime Apple ID email or phone';
    const ftIn = document.createElement('input');
    ftIn.type = 'text';
    ftIn.className = 'text-input';
    ftIn.placeholder = 'noor@icloud.com or +971501234567';
    ftIn.value = me.facetimeId || '';
    ftLbl.appendChild(ftIn);

    const pinLbl = document.createElement('label');
    pinLbl.className = 'field-label';
    pinLbl.style.marginTop = '10px';
    pinLbl.textContent = 'Recovery PIN (4+ digits to sign back in on new phones)';
    const pinIn = document.createElement('input');
    pinIn.type = 'password';
    pinIn.className = 'text-input';
    pinIn.placeholder = me.hasPin ? '•••• (leave blank to keep)' : 'Set a 4+ digit PIN';
    pinLbl.appendChild(pinIn);

    const saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    saveBtn.className = 'btn-gold';
    saveBtn.style.marginTop = '16px';
    saveBtn.style.height = '50px';
    saveBtn.textContent = 'Save details';
    saveBtn.addEventListener('click', async () => {
      const patch = {
        phone: phoneIn.value.trim(),
        facetimeId: ftIn.value.trim(),
      };
      if (pinIn.value.trim()) patch.pin = pinIn.value.trim();
      try {
        await actionUpdateMe(patch);
        closeDynamicSheet();
        toast('Saved your family call & PIN details');
      } catch (e) {
        toast(e.message);
      }
    });

    box.append(title, sub, phoneLbl, ftLbl, pinLbl, saveBtn);
  });
}

function openCircleModal(initialMode = 'create') {
  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = initialMode === 'join' ? 'Join a circle' : 'Create a new circle';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'text-input';
    input.style.marginTop = '12px';
    input.placeholder = initialMode === 'join' ? 'Enter invite code, e.g. FAM-4K7Q' : 'Circle name, e.g. Family or Friends';

    const goBtn = document.createElement('button');
    goBtn.type = 'button';
    goBtn.className = 'btn-gold';
    goBtn.style.marginTop = '14px';
    goBtn.style.height = '50px';
    goBtn.textContent = initialMode === 'join' ? 'Join circle' : 'Create circle';
    goBtn.addEventListener('click', async () => {
      const val = input.value.trim();
      if (!val) return;
      try {
        if (initialMode === 'join') {
          await actionJoinCircle(val);
          toast('Joined circle!');
        } else {
          await actionCreateCircle(val);
          toast(`Created "${val}" circle!`);
        }
        closeDynamicSheet();
      } catch (e) {
        toast(e.message);
      }
    });

    box.append(title, input, goBtn);
  });
}

function openScheduleModal() {
  if (!appState || !appState.me) return;
  const me = appState.me;
  const win = me.currentWindow;
  const schedMs = me.todayScheduleMs || {};
  const todayLog = me.todayPrayerLog || {};
  const activeLog = me.activePrayerLog || {};

  const rows = [
    { key: 'Fajr', name: 'Fajr', arabic: PRAYER_ARABIC.Fajr, isPrayer: true },
    { key: 'Sunrise', name: 'Sunrise (Shuruq)', arabic: 'الشروق', isPrayer: false },
    { key: 'Dhuhr', name: 'Dhuhr', arabic: PRAYER_ARABIC.Dhuhr, isPrayer: true },
    { key: 'Asr', name: 'Asr', arabic: PRAYER_ARABIC.Asr, isPrayer: true },
    { key: 'Maghrib', name: 'Maghrib', arabic: PRAYER_ARABIC.Maghrib, isPrayer: true },
    { key: 'Isha', name: 'Isha', arabic: PRAYER_ARABIC.Isha, isPrayer: true },
  ];

  openDynamicSheet((box) => {
    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = "Today's prayer times";

    const methodObj = METHOD_PRESETS[me.method];
    const sub = document.createElement('div');
    sub.style.fontSize = '12.5px';
    sub.style.color = 'var(--muted)';
    sub.style.marginTop = '4px';
    sub.textContent = `${me.city}, ${me.country} · ${(methodObj && methodObj.shortLabel) || me.method}`;

    const list = document.createElement('div');
    list.className = 'schedule-list';

    rows.forEach((r) => {
      const row = document.createElement('div');
      const isCurrent = r.isPrayer && win.name === r.key;
      const isPrayed = r.isPrayer
        ? isCurrent
          ? Boolean(activeLog[r.key])
          : Boolean(todayLog[r.key])
        : false;
      row.className = `schedule-row${isCurrent ? ' current' : ''}`;

      const left = document.createElement('div');
      left.style.display = 'flex';
      left.style.alignItems = 'baseline';
      left.style.gap = '10px';

      const en = document.createElement('span');
      en.style.fontWeight = isCurrent ? '700' : '600';
      en.style.fontSize = '15px';
      en.style.color = isCurrent ? 'var(--gold)' : 'var(--ivory)';
      en.textContent = r.name;

      const ar = document.createElement('span');
      ar.style.fontFamily = 'var(--font-arabic)';
      ar.style.fontSize = '16px';
      ar.style.color = 'var(--muted)';
      ar.textContent = r.arabic;
      left.append(en, ar);

      const right = document.createElement('div');
      right.style.display = 'flex';
      right.style.alignItems = 'center';
      right.style.gap = '10px';

      if (isPrayed) {
        const badge = document.createElement('span');
        badge.className = 'status-sharing';
        badge.style.fontSize = '11.5px';
        badge.textContent = 'Prayed ✓';
        right.appendChild(badge);
      } else if (isCurrent) {
        const badge = document.createElement('span');
        badge.className = 'now-chip';
        badge.textContent = 'Now';
        right.appendChild(badge);
      }

      const timeSpan = document.createElement('span');
      timeSpan.style.fontWeight = '600';
      timeSpan.style.fontSize = '14px';
      timeSpan.textContent = schedMs[r.key] ? formatTimeInZone(new Date(schedMs[r.key]), me.tz) : '—';
      right.appendChild(timeSpan);

      row.append(left, right);
      list.appendChild(row);
    });

    box.append(title, sub, list);
  });
}

function openQrInviteModal() {
  const active = getActiveCircle();
  if (!active) return;
  const inviteUrl = `${window.location.origin}/?join=${encodeURIComponent(active.inviteCode)}`;

  openDynamicSheet((box) => {
    const wrap = document.createElement('div');
    wrap.style.textAlign = 'center';

    const title = document.createElement('div');
    title.style.fontFamily = 'var(--font-display)';
    title.style.fontSize = '28px';
    title.style.fontWeight = '600';
    title.textContent = `Join ${active.name}`;

    const sub = document.createElement('div');
    sub.style.fontSize = '13px';
    sub.style.color = 'var(--muted)';
    sub.style.marginTop = '4px';
    sub.textContent = 'Point any phone camera here to join the circle';

    const qrFrame = document.createElement('div');
    qrFrame.className = 'qr-card-frame';
    try {
      qrFrame.innerHTML = renderInviteQrSvg(inviteUrl, active.inviteCode);
    } catch {
      qrFrame.textContent = active.inviteCode;
    }

    const codePill = document.createElement('div');
    codePill.style.fontFamily = 'var(--font-sans)';
    codePill.style.fontSize = '18px';
    codePill.style.fontWeight = '700';
    codePill.style.letterSpacing = '0.08em';
    codePill.style.color = 'var(--gold)';
    codePill.textContent = active.inviteCode;

    const copyBtn = document.createElement('button');
    copyBtn.type = 'button';
    copyBtn.className = 'btn-gold';
    copyBtn.style.marginTop = '14px';
    copyBtn.style.height = '48px';
    copyBtn.textContent = 'Copy invite link';
    copyBtn.addEventListener('click', async () => {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(inviteUrl).catch(() => {});
      }
      closeDynamicSheet();
      toast(`Copied invite link (${active.inviteCode})!`);
    });

    wrap.append(title, sub, qrFrame, codePill, copyBtn);
    box.appendChild(wrap);
  });
}

// ==================== ACTIONS ====================
async function actionUpdateMe(patch) {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    const u = db.users[db.currentUid];
    if (patch.quietToday !== undefined) {
      u.quietUntilMs = patch.quietToday ? endOfLocalDayUtc(new Date(), patch.tz || u.tz).getTime() : null;
      delete patch.quietToday;
    }
    Object.assign(u, patch);
    saveSandboxDb(db);
    appState = buildSandboxState(db);
    renderModeBanner();
    renderAll();
    return;
  }
  const res = await apiFetch('/api/me', {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });
  appState = res.state;
  saveLiveStateCache(appState);
  renderModeBanner();
  renderAll();
}

async function actionConfirmPrayer(prayerName, dateStr = null, unconfirm = false) {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    const u = db.users[db.currentUid];
    const win = currentPrayerWindow(u, new Date());
    const targetDate = dateStr || (prayerName === win.name ? win.date : win.todayDate);
    const key = `${u.uid}|${targetDate}`;
    db.prayerLogs[key] = db.prayerLogs[key] || {};
    const alreadyPrayed = Boolean(db.prayerLogs[key][prayerName]);
    if (unconfirm) {
      delete db.prayerLogs[key][prayerName];
    } else {
      const nowMs = Date.now();
      db.prayerLogs[key][prayerName] = nowMs;
      if (!alreadyPrayed && u.shareStatus) {
        const matchingNudges = db.nudges.filter(
          (n) => n.toUid === u.uid && n.localDate === targetDate && n.prayer === prayerName
        );
        const senderUids = [...new Set(matchingNudges.map((n) => n.fromUid))];
        senderUids.forEach((senderUid) => {
          const nudgeRow = matchingNudges.find((n) => n.fromUid === senderUid);
          db.messages.push({
            messageId: `m_${nowMs}_${senderUid}`,
            circleId: nudgeRow ? nudgeRow.circleId : 'circle_family',
            fromUid: u.uid,
            toUid: senderUid,
            kind: 'confirmed',
            prayer: prayerName,
            body: `${u.displayName} prayed ${prayerName}`,
            createdAtMs: nowMs,
          });
        });
      }
    }
    saveSandboxDb(db);
    appState = buildSandboxState(db);
    renderAll();
  } else {
    try {
      const res = await apiFetch('/api/prayers/confirm', {
        method: 'POST',
        body: JSON.stringify({ prayer: prayerName, date: dateStr, unconfirm }),
      });
      appState = res.state;
      saveLiveStateCache(appState);
      renderModeBanner();
      renderAll();
    } catch (err) {
      if (!err.status && appState && appState.me) {
        const now = new Date();
        const myWin = currentPrayerWindow(appState.me, now);
        const targetDate = dateStr || (prayerName === myWin.name ? myWin.date : myWin.todayDate);
        queuePendingConfirm(appState.me.uid, prayerName, targetDate, unconfirm, now.getTime());
        appState = revalidateCachedLiveState(appState, now);
        saveLiveStateCache(appState);
        renderModeBanner();
        renderAll();
      } else {
        toast(err.message || 'Could not update prayer status');
        return;
      }
    }
  }

  if (!unconfirm) {
    const style = appState.me.characterStyle;
    toast(
      style !== 'off'
        ? `Mashallah! ${prayerName} is done.`
        : `${prayerName} marked as prayed`
    );
  }
}

async function actionSnoozePrayer(prayerName) {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    db.users[db.currentUid].snoozePrayerName = prayerName;
    db.users[db.currentUid].snoozeAtMs = Date.now() + 15 * 60000;
    saveSandboxDb(db);
    setTimeout(() => {
      toast(`Gentle 15-minute check-in for ${prayerName}`);
    }, 15 * 60000);
    appState = buildSandboxState(db);
    renderAll();
  } else {
    try {
      const res = await apiFetch('/api/prayers/snooze', {
        method: 'POST',
        body: JSON.stringify({ prayer: prayerName, minutes: 15 }),
      });
      appState = res.state;
      saveLiveStateCache(appState);
      renderAll();
    } catch (err) {
      if (!err.status && appState && appState.me) {
        appState.me.snoozePrayerName = prayerName;
        appState.me.snoozeAtMs = Date.now() + 15 * 60000;
        saveLiveStateCache(appState);
        setTimeout(() => {
          toast(`Gentle 15-minute check-in for ${prayerName}`);
        }, 15 * 60000);
        renderAll();
      } else {
        toast(err.message || 'Could not snooze reminder');
        return;
      }
    }
  }
  toast('We will gently remind you in 15 minutes');
}

async function actionSendNudge() {
  if (!selectedNudgeMember) return;
  const circle = getActiveCircle();
  const target = selectedNudgeMember;
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    const prayerName = (target.currentPrayer && target.currentPrayer.name) || 'Dhuhr';
    const dateStr = (target.currentPrayer && target.currentPrayer.date) || '2026-10-26';
    const targetLog = db.prayerLogs[`${target.uid}|${dateStr}`] || {};
    const targetUser = db.users[target.uid];
    if (targetLog[prayerName] && targetUser && targetUser.shareStatus) {
      toast(`${target.displayName} has already prayed ${prayerName}, alhamdulillah.`);
      $('sheet-nudge').hidden = true;
      return;
    }
    const nudgeId = `${target.uid}_${dateStr}_${prayerName}_${db.currentUid}`;
    if (db.nudges.some((n) => n.nudgeId === nudgeId)) {
      toast(`You already sent a gentle reminder to ${target.displayName} for ${prayerName}`);
      $('sheet-nudge').hidden = true;
      return;
    }
    db.nudges.push({
      nudgeId,
      fromUid: db.currentUid,
      toUid: target.uid,
      circleId: circle ? circle.circleId : 'circle_family',
      prayer: prayerName,
      localDate: dateStr,
      characterId: selectedNudgeCharacter,
      createdAtMs: Date.now(),
      suppressed: Boolean(targetLog[prayerName]),
    });
    db.messages.push({
      messageId: `m_${Date.now()}`,
      circleId: circle ? circle.circleId : 'circle_family',
      fromUid: db.currentUid,
      toUid: target.uid,
      kind: 'nudge',
      prayer: prayerName,
      body: `Sent a reminder for ${prayerName}`,
      createdAtMs: Date.now(),
    });
    saveSandboxDb(db);
    appState = buildSandboxState(db);
    $('sheet-nudge').hidden = true;
    renderAll();
    toast(`Reminder sent to ${target.displayName}`);
    return;
  }

  try {
    const res = await apiFetch('/api/nudges', {
      method: 'POST',
      body: JSON.stringify({
        toUid: target.uid,
        circleId: circle ? circle.circleId : '',
        characterId: selectedNudgeCharacter,
      }),
    });
    if (res.state) {
      appState = res.state;
      saveLiveStateCache(appState);
      renderAll();
    } else {
      await refreshState();
    }
    $('sheet-nudge').hidden = true;
    toast(`Reminder sent to ${target.displayName}`);
  } catch (e) {
    $('sheet-nudge').hidden = true;
    toast(e.message);
  }
}

async function actionCreateCircle(name) {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    const code = `${name.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase().padEnd(3, 'X')}-7Q2M`;
    const cid = `cir_${Date.now()}`;
    db.circles.push({
      circleId: cid,
      name,
      ownerUid: db.currentUid,
      inviteCode: code,
      memberUids: [db.currentUid],
    });
    selectedCircleId = cid;
    saveSandboxDb(db);
    appState = buildSandboxState(db);
    renderAll();
    return;
  }
  const res = await apiFetch('/api/circles/create', {
    method: 'POST',
    body: JSON.stringify({ name }),
  });
  selectedCircleId = res.circleId;
  appState = res.state;
  saveLiveStateCache(appState);
  renderAll();
}

async function actionJoinCircle(inviteCode) {
  if (backendMode === 'sandbox') {
    const db = loadSandboxDb();
    const c = db.circles.find((x) => x.inviteCode === inviteCode.trim().toUpperCase());
    if (!c) throw new Error('Invite code not found in sandbox.');
    if (!c.memberUids.includes(db.currentUid)) c.memberUids.push(db.currentUid);
    selectedCircleId = c.circleId;
    saveSandboxDb(db);
    appState = buildSandboxState(db);
    renderAll();
    return;
  }
  const res = await apiFetch('/api/circles/join', {
    method: 'POST',
    body: JSON.stringify({ inviteCode }),
  });
  selectedCircleId = res.circleId;
  appState = res.state;
  saveLiveStateCache(appState);
  renderAll();
}

async function enableWebPush() {
  const standalone =
    window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  if (isIOS && !standalone) {
    toast('On iPhone: tap Share ↑ → "Add to Home Screen", then open Waqt from your Home Screen.', 4500);
    return;
  }
  if (!('Notification' in window) || !('serviceWorker' in navigator)) {
    toast('Push notifications are not supported in this browser.');
    return;
  }

  const perm = await Notification.requestPermission();
  if (perm !== 'granted') {
    toast('Notification permission was not granted.');
    return;
  }

  if (backendMode === 'sandbox' || !serverConfig.vapidPublicKey) {
    new Notification('Waqt', {
      body: `Assalamu alaikum ${appState.me.displayName} — reminders are enabled!`,
      icon: '/icons/icon-192.png',
    });
    await refreshState();
    toast('Local notifications enabled!');
    return;
  }

  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(serverConfig.vapidPublicKey),
    });
    await apiFetch('/api/push/subscribe', {
      method: 'POST',
      body: JSON.stringify({ subscription: sub.toJSON() }),
    });
    await refreshState();
    toast('Lock-screen Web Push reminders are active!');
  } catch (e) {
    toast(e.message || 'Could not subscribe to Web Push.');
  }
}

// ==================== GEOLOCATION CITY HELPER ====================
function detectNearestCity(onFound) {
  if (!('geolocation' in navigator)) {
    toast('Location is not available on this device — pick your city from the list.');
    return;
  }
  toast('Finding nearest city…');
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const hit = nearestCity(pos.coords.latitude, pos.coords.longitude, citiesData);
      if (!hit) {
        toast('Could not match a city.');
        return;
      }
      const deviceTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const chosen = {
        ...hit.city,
        tz: hit.distanceKm > 250 && deviceTz ? deviceTz : hit.city.tz,
      };
      onFound(chosen);
    },
    () => {
      toast('Location permission declined — type your city instead.');
    },
    { enableHighAccuracy: false, timeout: 8000 }
  );
}

// ==================== WIRE DOM EVENTS ====================
function wireEvents() {
  // Mode banner perspective switcher & reset
  const demoSelect = $('demo-member-select');
  if (demoSelect) {
    demoSelect.addEventListener('change', () => {
      const db = loadSandboxDb();
      if (!db || !db.users[demoSelect.value]) return;
      db.currentUid = demoSelect.value;
      saveSandboxDb(db);
      appState = buildSandboxState(db);
      activeChatPeerUid = null;
      renderModeBanner();
      renderAll();
      toast(`Viewing as ${db.users[db.currentUid].displayName} (${db.users[db.currentUid].city})`);
    });
  }

  $('btn-reset-demo').addEventListener('click', () => {
    localStorage.removeItem(SANDBOX_KEY);
    const db = seedSandboxFromSample();
    appState = buildSandboxState(db);
    enterAuthenticatedShell();
    toast('Sample family reset');
  });

  // Welcome city autocomplete
  const cityInput = $('in-city');
  const cityDrop = $('welcome-city-dropdown');

  const updateWelcomeCityMatches = () => {
    const q = cityInput.value.trim().toLowerCase();
    cityDrop.textContent = '';
    const matches = citiesData
      .filter((c) => !q || `${c.name}, ${c.country}`.toLowerCase().includes(q))
      .slice(0, 12);
    if (matches.length === 0) {
      cityDrop.hidden = true;
      return;
    }
    matches.forEach((c) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'city-option';
      const l = document.createElement('span');
      l.textContent = `${c.name}, ${c.country}`;
      const r = document.createElement('span');
      r.className = 'city-option-tz';
      r.textContent = c.tz;
      btn.append(l, r);
      btn.addEventListener('click', () => {
        selectedWelcomeCity = c;
        cityInput.value = `${c.name}, ${c.country}`;
        const def =
          (methodsData.defaultsByCountry && methodsData.defaultsByCountry[c.country]) ||
          methodsData.defaultsByCountry.default;
        const mLabel = (METHOD_PRESETS[def.method] && METHOD_PRESETS[def.method].label) || def.method;
        $('welcome-city-meta').textContent = `${c.tz} · ${mLabel}`;
        cityDrop.hidden = true;
      });
      cityDrop.appendChild(btn);
    });
    cityDrop.hidden = false;
  };

  cityInput.addEventListener('focus', updateWelcomeCityMatches);
  cityInput.addEventListener('input', () => {
    selectedWelcomeCity = null;
    updateWelcomeCityMatches();
  });
  document.addEventListener('click', (e) => {
    if (!cityInput.contains(e.target) && !cityDrop.contains(e.target)) {
      cityDrop.hidden = true;
    }
  });

  // Welcome privacy toggle
  $('sw-welcome-share').addEventListener('click', () => {
    const cur = $('sw-welcome-share').getAttribute('aria-checked') === 'true';
    setSwitchState($('sw-welcome-share'), !cur);
  });

  $('btn-toggle-extra').addEventListener('click', () => {
    const el = $('welcome-extra-fields');
    el.hidden = !el.hidden;
  });

  $('btn-switch-login').addEventListener('click', () => {
    $('welcome-signup-box').hidden = true;
    $('welcome-login-box').hidden = false;
  });
  $('btn-back-signup').addEventListener('click', () => {
    $('welcome-login-box').hidden = true;
    $('welcome-signup-box').hidden = false;
  });

  $('btn-use-gps').addEventListener('click', () => {
    detectNearestCity((c) => {
      selectedWelcomeCity = c;
      cityInput.value = `${c.name}, ${c.country}`;
      const def =
        (methodsData.defaultsByCountry && methodsData.defaultsByCountry[c.country]) ||
        methodsData.defaultsByCountry.default;
      $('welcome-city-meta').textContent = `${c.tz} · ${METHOD_PRESETS[def.method].label}`;
      toast(`Found ${c.name}, ${c.country}`);
    });
  });

  $('btn-enter-demo').addEventListener('click', () => {
    backendMode = 'sandbox';
    const db = loadSandboxDb() || seedSandboxFromSample();
    appState = buildSandboxState(db);
    enterAuthenticatedShell();
    toast('Exploring 6-member sample family circle');
  });

  // Join the circle (Onboarding submit)
  $('btn-join-circle').addEventListener('click', async () => {
    const errEl = $('welcome-error');
    errEl.textContent = '';
    const displayName = $('in-name').value.trim();
    const typedCity = cityInput.value.trim().toLowerCase();
    const city =
      selectedWelcomeCity ||
      citiesData.find(
        (c) =>
          `${c.name}, ${c.country}`.toLowerCase() === typedCity ||
          c.name.toLowerCase() === typedCity
      );

    if (!displayName) {
      errEl.textContent = 'Please enter your name.';
      return;
    }
    if (!city) {
      errEl.textContent = 'Please select your city from the list (or tap Use current location).';
      return;
    }

    const shareStatus = $('sw-welcome-share').getAttribute('aria-checked') === 'true';
    const def =
      (methodsData.defaultsByCountry && methodsData.defaultsByCountry[city.country]) ||
      methodsData.defaultsByCountry.default;

    if (backendMode === 'sandbox') {
      const db = seedSandboxFromSample({
        displayName,
        city: city.name,
        country: city.country,
        lat: city.lat,
        lon: city.lon,
        tz: city.tz,
        method: def.method,
        asrMethod: def.asrMethod,
        shareStatus,
      });
      appState = buildSandboxState(db);
      enterAuthenticatedShell();
      return;
    }

    try {
      const res = await apiFetch('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          displayName,
          city: city.name,
          country: city.country,
          lat: city.lat,
          lon: city.lon,
          tz: city.tz,
          method: def.method,
          asrMethod: def.asrMethod,
          shareStatus,
          inviteCode: $('in-invite-code').value.trim(),
          pin: $('in-pin').value.trim(),
          accessCode: $('in-access-code').value.trim(),
        }),
      });
      authToken = res.token;
      localStorage.setItem(TOKEN_KEY, authToken);
      syncSwToken(authToken);
      appState = res.state;
      saveLiveStateCache(appState);
      enterAuthenticatedShell();
    } catch (e) {
      errEl.textContent = e.message;
    }
  });

  // Returning member login
  $('btn-do-login').addEventListener('click', async () => {
    const errEl = $('login-error');
    errEl.textContent = '';
    const displayName = $('login-name').value.trim();
    const pin = $('login-pin').value.trim();
    if (!displayName) {
      errEl.textContent = 'Enter your name.';
      return;
    }
    if (backendMode === 'sandbox') {
      const db = loadSandboxDb() || seedSandboxFromSample();
      const match = Object.values(db.users).find(
        (u) => u.displayName.toLowerCase() === displayName.toLowerCase()
      );
      if (!match) {
        errEl.textContent = 'Name not found in sample family (try Noor, Mama, Ahmed, Layla, Yusuf, or Sara).';
        return;
      }
      db.currentUid = match.uid;
      saveSandboxDb(db);
      appState = buildSandboxState(db);
      enterAuthenticatedShell();
      return;
    }
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          displayName,
          pin,
        }),
      });
      authToken = res.token;
      localStorage.setItem(TOKEN_KEY, authToken);
      syncSwToken(authToken);
      appState = res.state;
      saveLiveStateCache(appState);
      enterAuthenticatedShell();
    } catch (e) {
      errEl.textContent = e.message;
    }
  });

  // Bottom navigation tabs
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Home interactions
  $('ring-window').addEventListener('click', openScheduleModal);
  $('btn-home-bell').addEventListener('click', () => {
    openReminderOverlay();
  });
  $('btn-open-incoming').addEventListener('click', () => openReminderOverlay());
  $('btn-home-go-circle').addEventListener('click', () => switchTab('circle'));
  $('btn-home-prayed').addEventListener('click', () => {
    if (!appState) return;
    const win = appState.me.currentWindow;
    const already = Boolean(appState.me.activePrayerLog && appState.me.activePrayerLog[win.name]);
    actionConfirmPrayer(win.name, win.date, already);
  });

  // Circle interactions
  $('btn-empty-create-circle').addEventListener('click', () => openCircleModal('create'));
  $('btn-empty-join-circle').addEventListener('click', () => openCircleModal('join'));
  const qrBtn = $('btn-qr-invite');
  if (qrBtn) {
    qrBtn.addEventListener('click', openQrInviteModal);
  }

  $('btn-share-invite').addEventListener('click', async () => {
    const active = getActiveCircle();
    if (!active) return;
    const inviteUrl = `${window.location.origin}/?join=${encodeURIComponent(active.inviteCode)}`;
    const shareText = `Join our "${active.name}" prayer circle on Waqt! Invite code: ${active.inviteCode}\n${inviteUrl}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Join our Waqt circle', text: shareText, url: inviteUrl });
        return;
      } catch {
        // user cancelled share sheet; copy instead
      }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(shareText).catch(() => {});
      toast(`Copied invite code ${active.inviteCode} & link!`);
    } else {
      toast(`Invite code: ${active.inviteCode}`);
    }
  });

  $('btn-whatsapp-invite').addEventListener('click', () => {
    const active = getActiveCircle();
    if (!active) return;
    const inviteUrl = `${window.location.origin}/?join=${encodeURIComponent(active.inviteCode)}`;
    const text = `Assalamu alaikum! Join our "${active.name}" prayer circle on Waqt with code ${active.inviteCode}: ${inviteUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  });

  $('btn-leave-circle').addEventListener('click', async () => {
    const active = getActiveCircle();
    if (!active) return;
    if (!window.confirm(`Leave "${active.name}" circle?`)) return;
    if (backendMode === 'sandbox') {
      const db = loadSandboxDb();
      db.circles = db.circles.filter((c) => c.circleId !== active.circleId);
      saveSandboxDb(db);
      appState = buildSandboxState(db);
      renderAll();
      return;
    }
    const res = await apiFetch('/api/circles/leave', {
      method: 'POST',
      body: JSON.stringify({ circleId: active.circleId }),
    });
    appState = res.state;
    saveLiveStateCache(appState);
    renderAll();
    toast(`Left ${active.name}`);
  });

  // NudgeSheet interactions
  $('btn-sheet-send-nudge').addEventListener('click', () => actionSendNudge());
  $('btn-sheet-message').addEventListener('click', () => {
    if (!selectedNudgeMember) return;
    activeChatPeerUid = selectedNudgeMember.uid;
    $('sheet-nudge').hidden = true;
    switchTab('chat');
  });
  $('btn-sheet-call').addEventListener('click', () => {
    if (selectedNudgeMember) openCallSheet(selectedNudgeMember);
  });
  $('btn-sheet-remove-member').addEventListener('click', async () => {
    const active = getActiveCircle();
    const target = selectedNudgeMember;
    if (!active || !target) return;
    if (!window.confirm(`Remove ${target.displayName} from "${active.name}"?`)) return;
    $('sheet-nudge').hidden = true;
    if (backendMode === 'sandbox') {
      const db = loadSandboxDb();
      const c = db.circles.find((x) => x.circleId === active.circleId);
      if (c) c.memberUids = c.memberUids.filter((u) => u !== target.uid);
      saveSandboxDb(db);
      appState = buildSandboxState(db);
      renderAll();
      toast(`Removed ${target.displayName} from ${active.name}`);
      return;
    }
    try {
      const res = await apiFetch('/api/circles/remove-member', {
        method: 'POST',
        body: JSON.stringify({ circleId: active.circleId, memberUid: target.uid }),
      });
      appState = res.state;
      saveLiveStateCache(appState);
      renderAll();
      toast(`Removed ${target.displayName} from ${active.name}`);
    } catch (e) {
      toast(e.message);
    }
  });
  $('btn-sheet-dismiss').addEventListener('click', () => {
    $('sheet-nudge').hidden = true;
  });
  $('sheet-nudge').addEventListener('click', (e) => {
    if (e.target === $('sheet-nudge')) $('sheet-nudge').hidden = true;
  });

  // Call check-in sheet
  $('btn-save-peer-contact').addEventListener('click', () => {
    if (!selectedCallMember) return;
    const val = $('in-peer-phone').value.trim();
    saveLocalPeerContact(selectedCallMember.uid, val);
    selectedCallMember = mergeMemberContact(selectedCallMember);
    renderCallLinks();
    toast(`Saved 1-tap call contact for ${selectedCallMember.displayName}`);
  });
  $('btn-call-close').addEventListener('click', () => {
    $('sheet-call').hidden = true;
  });
  $('sheet-call').addEventListener('click', (e) => {
    if (e.target === $('sheet-call')) $('sheet-call').hidden = true;
  });

  // Dynamic sheet close
  $('btn-dyn-close').addEventListener('click', closeDynamicSheet);
  $('sheet-Dynamic').addEventListener('click', (e) => {
    if (e.target === $('sheet-Dynamic')) closeDynamicSheet();
  });

  // Reminder Received overlay interactions
  $('btn-rem-close').addEventListener('click', () => {
    $('overlay-reminder').hidden = true;
  });
  $('btn-rem-prayed').addEventListener('click', async () => {
    $('overlay-reminder').hidden = true;
    if (appState) {
      await actionConfirmPrayer(appState.me.currentWindow.name, appState.me.currentWindow.date, false);
    }
  });
  $('btn-rem-snooze').addEventListener('click', async () => {
    $('overlay-reminder').hidden = true;
    if (appState) {
      await actionSnoozePrayer(appState.me.currentWindow.name);
    }
  });
  $('btn-rem-quiet').addEventListener('click', async () => {
    $('overlay-reminder').hidden = true;
    await actionUpdateMe({ quietToday: true });
    toast('Quiet mode on for today — nobody is notified');
  });

  // Chat interactions
  $('btn-chat-back').addEventListener('click', () => switchTab('home'));
  $('chat-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = $('chat-input').value.trim();
    if (!text || !activeChatPeerUid) return;
    $('chat-input').value = '';
    const active = getActiveCircle();

    if (backendMode === 'sandbox') {
      const db = loadSandboxDb();
      db.messages.push({
        messageId: `m_${Date.now()}`,
        circleId: active ? active.circleId : 'circle_family',
        fromUid: db.currentUid,
        toUid: activeChatPeerUid,
        kind: 'text',
        prayer: null,
        body: text,
        createdAtMs: Date.now(),
      });
      saveSandboxDb(db);
      loadChatMessages(activeChatPeerUid);
      return;
    }

    try {
      const res = await apiFetch('/api/messages', {
        method: 'POST',
        body: JSON.stringify({
          toUid: activeChatPeerUid,
          circleId: active ? active.circleId : 'circle',
          body: text,
        }),
      });
      chatMessages = res.messages || chatMessages;
      renderChatStream();
    } catch (err) {
      toast(err.message);
    }
  });

  // Settings rows & switches
  $('set-row-location').addEventListener('click', openLocationPickerModal);
  $('set-row-method').addEventListener('click', openMethodPickerModal);
  $('set-row-remind').addEventListener('click', openRemindTimingModal);
  $('set-row-contact').addEventListener('click', openContactAndPinModal);
  $('set-row-characters').addEventListener('click', () => switchTab('characters'));
  $('btn-char-back').addEventListener('click', () => switchTab('settings'));

  document.querySelectorAll('[data-char-style]').forEach((btn) => {
    btn.addEventListener('click', () => {
      actionUpdateMe({ characterStyle: btn.dataset.charStyle });
    });
  });

  $('set-row-push').addEventListener('click', async () => {
    if (appState && appState.me.pushEnabled && backendMode === 'live') {
      try {
        const res = await apiFetch('/api/push/test', { method: 'POST', body: '{}' });
        toast(res.sent > 0 ? 'Sent test push! Lock your screen to see it.' : 'Push registered — check VAPID secrets.');
      } catch (e) {
        toast(e.message);
      }
    } else {
      await enableWebPush();
    }
  });

  const bindSwitch = (id, key) => {
    $(id).addEventListener('click', () => {
      if (!appState) return;
      const current = $(id).getAttribute('aria-checked') === 'true';
      actionUpdateMe({ [key]: !current });
    });
  };
  bindSwitch('sw-set-share', 'shareStatus');
  bindSwitch('sw-set-city', 'showCity');
  bindSwitch('sw-set-circle-rem', 'circleReminders');
  bindSwitch('sw-set-quiet', 'quietToday');
  bindSwitch('sw-set-summary', 'eveningSummary');

  $('btn-preview-reminder-screen').addEventListener('click', openReminderOverlay);
  $('btn-sign-out').addEventListener('click', async () => {
    if (!window.confirm('Sign out on this device?')) return;
    if (backendMode === 'live' && authToken) {
      let endpoint = '';
      try {
        if ('serviceWorker' in navigator) {
          const reg = await navigator.serviceWorker.getRegistration();
          const sub = reg && reg.pushManager ? await reg.pushManager.getSubscription() : null;
          if (sub) {
            endpoint = sub.endpoint || '';
            await sub.unsubscribe().catch(() => {});
          }
        }
      } catch {
        // Ignore PushManager lookup errors
      }
      await apiFetch('/api/auth/logout', {
        method: 'POST',
        body: JSON.stringify({ endpoint }),
      }).catch(() => {});
      authToken = null;
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(LIVE_STATE_CACHE_KEY);
      localStorage.removeItem(PENDING_CONFIRMS_KEY);
      syncSwToken(null);
    } else {
      localStorage.removeItem(SANDBOX_KEY);
      if (serverConfig && serverConfig.ok) {
        backendMode = 'live';
      }
    }
    appState = null;
    showWelcome();
  });
}

function loadOptionalWebFonts() {
  if (typeof window === "undefined" || typeof document === "undefined") return;
  if (navigator.onLine === false) return;
  if (window.__WAQT_SKIP_EXTERNAL_FONTS__) return;
  const run = async () => {
    if (document.getElementById("waqt-google-fonts")) return;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 2500);
    try {
      const res = await fetch(
        "https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Manrope:wght@400;500;600;700&display=swap",
        { signal: ctrl.signal, mode: "cors" }
      );
      if (!res.ok) return;
      const css = await res.text();
      const style = document.createElement("style");
      style.id = "waqt-google-fonts";
      style.textContent = css;
      document.head.appendChild(style);
    } catch {
      // Offline / captive-portal fallback: tokens.json system serif & sans-serif stacks already active
    } finally {
      clearTimeout(timer);
    }
  };
  if (document.readyState === "complete") {
    setTimeout(run, 50);
  } else {
    window.addEventListener("load", () => setTimeout(run, 50), { once: true });
  }
}

if (typeof window !== "undefined" && typeof document !== "undefined") {
  loadOptionalWebFonts();
  boot();
}
