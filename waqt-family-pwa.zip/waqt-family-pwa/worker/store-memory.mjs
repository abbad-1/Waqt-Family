// In-memory storage adapter matching D1WaqtStore 1-to-1 for local dev server & automated integration tests.

export class MemoryWaqtStore {
  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.circles = new Map();
    this.prayerLogs = new Map(); // `${uid}|${date}` -> { Fajr: ms, ... }
    this.nudges = new Map(); // nudgeId -> nudge
    this.messages = [];
    this.pushSubs = new Map(); // endpoint -> { endpoint, uid, keys, userAgent }
  }

  async createUser(u) {
    const record = {
      uid: u.uid,
      displayName: u.displayName,
      pinHash: u.pinHash || null,
      pinSalt: u.pinSalt || null,
      phone: u.phone || '',
      facetimeId: u.facetimeId || '',
      city: u.city,
      country: u.country,
      lat: Number(u.lat),
      lon: Number(u.lon),
      tz: u.tz,
      method: u.method,
      asrMethod: u.asrMethod || 'standard',
      highLatitudeRule: u.highLatitudeRule || 'auto',
      remindOffsetMinutes: Number(u.remindOffsetMinutes ?? 0),
      shareStatus: Boolean(u.shareStatus),
      showCity: Boolean(u.showCity),
      circleReminders: u.circleReminders !== undefined ? Boolean(u.circleReminders) : true,
      quietUntilMs: u.quietUntilMs ?? null,
      eveningSummary: Boolean(u.eveningSummary),
      lastSummaryDate: u.lastSummaryDate ?? null,
      characterStyle: u.characterStyle || 'characters',
      preferredCharacter: u.preferredCharacter || 'teta',
      nextPrayerName: u.nextPrayerName ?? null,
      nextPrayerAtMs: u.nextPrayerAtMs ?? null,
      nextPrayerDate: u.nextPrayerDate ?? null,
      snoozePrayerName: u.snoozePrayerName ?? null,
      snoozeAtMs: u.snoozeAtMs ?? null,
      createdAtMs: Number(u.createdAtMs),
    };
    this.users.set(u.uid, record);
    return { ...record };
  }

  async getUser(uid) {
    const u = this.users.get(uid);
    return u ? { ...u } : null;
  }

  async findUsersByName(displayName) {
    const target = displayName.trim().toLowerCase();
    const out = [];
    for (const u of this.users.values()) {
      if (u.displayName.toLowerCase() === target) out.push({ ...u });
    }
    return out;
  }

  async updateUser(uid, patch) {
    const curr = this.users.get(uid);
    if (!curr) return null;
    const next = { ...curr, ...patch };
    this.users.set(uid, next);
    return { ...next };
  }

  async createSession(tokenHash, uid, createdAtMs) {
    this.sessions.set(tokenHash, { uid, createdAtMs });
  }

  async getUidBySession(tokenHash) {
    const s = this.sessions.get(tokenHash);
    return s ? s.uid : null;
  }

  async deleteSession(tokenHash) {
    this.sessions.delete(tokenHash);
  }

  async getCircleByInviteCode(inviteCode) {
    for (const c of this.circles.values()) {
      if (c.inviteCode === inviteCode) return { ...c, memberUids: [...c.memberUids] };
    }
    return null;
  }

  async getCircle(circleId) {
    const c = this.circles.get(circleId);
    return c ? { ...c, memberUids: [...c.memberUids] } : null;
  }

  async createCircle({ circleId, name, ownerUid, inviteCode, createdAtMs }) {
    const c = { circleId, name, ownerUid, inviteCode, createdAtMs, memberUids: [ownerUid] };
    this.circles.set(circleId, c);
    return { ...c, memberUids: [...c.memberUids] };
  }

  async addCircleMember(circleId, uid) {
    const c = this.circles.get(circleId);
    if (!c) return;
    if (!c.memberUids.includes(uid)) c.memberUids.push(uid);
  }

  async removeCircleMember(circleId, uid) {
    const c = this.circles.get(circleId);
    if (!c) return;
    c.memberUids = c.memberUids.filter((m) => m !== uid);
    if (c.memberUids.length === 0) {
      this.circles.delete(circleId);
    } else if (c.ownerUid === uid) {
      c.ownerUid = c.memberUids[0];
    }
  }

  async getCirclesForUser(uid) {
    const out = [];
    for (const c of this.circles.values()) {
      if (c.memberUids.includes(uid)) out.push({ ...c, memberUids: [...c.memberUids] });
    }
    return out;
  }

  async sharesCircle(uidA, uidB) {
    if (uidA === uidB) return true;
    for (const c of this.circles.values()) {
      if (c.memberUids.includes(uidA) && c.memberUids.includes(uidB)) return true;
    }
    return false;
  }

  async setPrayerConfirmed(uid, localDate, prayer, confirmedAtMs) {
    const key = `${uid}|${localDate}`;
    const entry = this.prayerLogs.get(key) || {};
    entry[prayer] = confirmedAtMs;
    this.prayerLogs.set(key, entry);
  }

  async removePrayerConfirmed(uid, localDate, prayer) {
    const key = `${uid}|${localDate}`;
    const entry = this.prayerLogs.get(key);
    if (entry) delete entry[prayer];
  }

  async getPrayerLog(uid, localDate) {
    const entry = this.prayerLogs.get(`${uid}|${localDate}`);
    return entry ? { ...entry } : {};
  }

  async createNudge(n) {
    if (this.nudges.has(n.nudgeId)) return { duplicate: true };
    this.nudges.set(n.nudgeId, { ...n, suppressed: Boolean(n.suppressed) });
    return { duplicate: false };
  }

  async getNudgesForRecipientPrayer(toUid, localDate, prayer) {
    const out = [];
    for (const n of this.nudges.values()) {
      if (n.toUid === toUid && n.localDate === localDate && n.prayer === prayer) {
        out.push({ ...n });
      }
    }
    return out.sort((a, b) => a.createdAtMs - b.createdAtMs);
  }

  async getRecentNudgesForRecipient(toUid, sinceMs) {
    const out = [];
    for (const n of this.nudges.values()) {
      if (n.toUid === toUid && !n.suppressed && n.createdAtMs >= sinceMs) {
        out.push({ ...n });
      }
    }
    return out.sort((a, b) => b.createdAtMs - a.createdAtMs).slice(0, 20);
  }

  async createMessage(m) {
    this.messages.push({
      messageId: m.messageId,
      circleId: m.circleId,
      fromUid: m.fromUid,
      toUid: m.toUid,
      kind: m.kind || 'text',
      prayer: m.prayer || null,
      body: m.body,
      createdAtMs: m.createdAtMs,
    });
  }

  async getMessagesBetween(uidA, uidB, limit = 60) {
    const filtered = this.messages.filter(
      (m) =>
        (m.fromUid === uidA && m.toUid === uidB) ||
        (m.fromUid === uidB && m.toUid === uidA)
    );
    filtered.sort((a, b) => a.createdAtMs - b.createdAtMs);
    return filtered.slice(-limit);
  }

  async upsertPushSubscription({ endpoint, uid, p256dh, auth, userAgent, createdAtMs }) {
    this.pushSubs.set(endpoint, {
      endpoint,
      uid,
      keys: { p256dh, auth },
      userAgent: userAgent || '',
      createdAtMs,
    });
  }

  async getPushSubscriptions(uid) {
    const out = [];
    for (const s of this.pushSubs.values()) {
      if (s.uid === uid) out.push({ ...s, keys: { ...s.keys } });
    }
    return out;
  }

  async deletePushSubscription(endpoint) {
    this.pushSubs.delete(endpoint);
  }

  async getDuePrayerUsers(nowMs) {
    const out = [];
    for (const u of this.users.values()) {
      if (u.nextPrayerAtMs === null || u.nextPrayerAtMs <= nowMs) out.push({ ...u });
    }
    return out;
  }

  async getDueSnoozeUsers(nowMs) {
    const out = [];
    for (const u of this.users.values()) {
      if (u.snoozeAtMs !== null && u.snoozeAtMs <= nowMs) out.push({ ...u });
    }
    return out;
  }

  async getEveningSummaryUsers() {
    const out = [];
    for (const u of this.users.values()) {
      if (u.eveningSummary) out.push({ ...u });
    }
    return out;
  }
}
