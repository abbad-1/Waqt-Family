// Zero-dependency Web Push (RFC 8291 aes128gcm + RFC 8188 + RFC 8292 VAPID ES256)
// Runs identically on Cloudflare Workers (Free Tier) and Node.js 18+ using standard Web Crypto API.

let cachedCrypto = globalThis.crypto && globalThis.crypto.subtle ? globalThis.crypto : null;

async function ensureCrypto() {
  if (cachedCrypto) return cachedCrypto;
  const mod = await import('node:' + 'crypto');
  cachedCrypto = mod.webcrypto;
  if (!globalThis.crypto) globalThis.crypto = cachedCrypto;
  return cachedCrypto;
}

export function getWebCrypto() {
  return cachedCrypto || globalThis.crypto;
}

export function normalizeVapidSubject(subject) {
  const raw = String(subject || '').trim();
  if (!raw) return 'mailto:family@waqt.app';
  if (/^https:\/\//i.test(raw)) {
    try {
      const u = new URL(raw);
      if (!u.hostname.endsWith('.local') && !u.hostname.endsWith('.localhost') && u.hostname !== 'localhost') {
        return raw;
      }
    } catch {
      return 'mailto:family@waqt.app';
    }
    return 'mailto:family@waqt.app';
  }
  const email = raw.replace(/^mailto:/i, '').trim();
  if (!email.includes('@')) return 'mailto:family@waqt.app';
  const domain = email.split('@')[1].toLowerCase();
  if (!domain.includes('.') || domain.endsWith('.local') || domain.endsWith('.localhost')) {
    return 'mailto:family@waqt.app';
  }
  return `mailto:${email}`;
}
const encoder = new TextEncoder();

export function base64UrlEncode(bytes) {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = '';
  for (let i = 0; i < arr.length; i += 1) {
    binary += String.fromCharCode(arr[i]);
  }
  const b64 =
    typeof btoa === 'function'
      ? btoa(binary)
      : Buffer.from(arr).toString('base64');
  return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

export function base64UrlDecode(str) {
  const clean = String(str).trim().replace(/-/g, '+').replace(/_/g, '/');
  const padded = clean + '='.repeat((4 - (clean.length % 4)) % 4);
  if (typeof atob === 'function') {
    const bin = atob(padded);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
    return out;
  }
  return new Uint8Array(Buffer.from(padded, 'base64'));
}

function concatBytes(...arrays) {
  const total = arrays.reduce((acc, a) => acc + a.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const a of arrays) {
    out.set(a, offset);
    offset += a.length;
  }
  return out;
}

async function hmacSha256(keyBytes, dataBytes) {
  const key = await (await ensureCrypto()).subtle.importKey(
    'raw',
    keyBytes,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await (await ensureCrypto()).subtle.sign('HMAC', key, dataBytes);
  return new Uint8Array(sig);
}

// Generates a fresh VAPID P-256 keypair (87-char public key, 43-char private key in base64url).
export async function generateVapidKeys() {
  const keyPair = await (await ensureCrypto()).subtle.generateKey(
    { name: 'ECDSA', namedCurve: 'P-256' },
    true,
    ['sign', 'verify']
  );
  const rawPub = new Uint8Array(await (await ensureCrypto()).subtle.exportKey('raw', keyPair.publicKey));
  const jwkPriv = await (await ensureCrypto()).subtle.exportKey('jwk', keyPair.privateKey);
  return {
    publicKey: base64UrlEncode(rawPub),
    privateKey: jwkPriv.d,
  };
}

// Creates a signed RFC 8292 VAPID ES256 Authorization header value.
export async function createVapidAuthHeader(endpoint, vapidPublicKey, vapidPrivateKey, subject = 'mailto:family@waqt.app') {
  const pubBytes = base64UrlDecode(vapidPublicKey);
  if (pubBytes.length !== 65 || pubBytes[0] !== 0x04) {
    throw new Error('Invalid VAPID public key: expected 65-byte uncompressed P-256 point');
  }
  const x = base64UrlEncode(pubBytes.slice(1, 33));
  const y = base64UrlEncode(pubBytes.slice(33, 65));

  const jwk = {
    kty: 'EC',
    crv: 'P-256',
    x,
    y,
    d: vapidPrivateKey.trim(),
    ext: true,
  };

  const signingKey = await (await ensureCrypto()).subtle.importKey(
    'jwk',
    jwk,
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign']
  );

  const origin = new URL(endpoint).origin;
  const exp = Math.floor(Date.now() / 1000) + 12 * 3600;
  const headerB64 = base64UrlEncode(encoder.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const safeSubject = normalizeVapidSubject(subject);
  const payloadB64 = base64UrlEncode(encoder.encode(JSON.stringify({ aud: origin, exp, sub: safeSubject })));
  const unsignedToken = `${headerB64}.${payloadB64}`;

  const signature = new Uint8Array(
    await (await ensureCrypto()).subtle.sign(
      { name: 'ECDSA', hash: 'SHA-256' },
      signingKey,
      encoder.encode(unsignedToken)
    )
  );
  const jwt = `${unsignedToken}.${base64UrlEncode(signature)}`;
  return {
    authorization: `vapid t=${jwt}, k=${vapidPublicKey.trim()}`,
    jwt,
  };
}

// Encrypts a UTF-8 string/JSON payload per RFC 8291 (Web Push) + RFC 8188 (`aes128gcm`).
export async function encryptWebPushPayload(payloadString, subscriptionOrKeys) {
  const subscriptionKeys =
    subscriptionOrKeys && subscriptionOrKeys.keys ? subscriptionOrKeys.keys : subscriptionOrKeys;
  const uaPublic = base64UrlDecode(subscriptionKeys.p256dh);
  const authSecret = base64UrlDecode(subscriptionKeys.auth);
  if (uaPublic.length !== 65 || uaPublic[0] !== 0x04) {
    throw new Error('Invalid subscription p256dh key');
  }
  if (authSecret.length !== 16) {
    throw new Error('Invalid subscription auth secret (expected 16 bytes)');
  }

  const asKeyPair = await (await ensureCrypto()).subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits']
  );
  const asPublic = new Uint8Array(await (await ensureCrypto()).subtle.exportKey('raw', asKeyPair.publicKey));
  const uaCryptoKey = await (await ensureCrypto()).subtle.importKey(
    'raw',
    uaPublic,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );

  const ecdhSecret = new Uint8Array(
    await (await ensureCrypto()).subtle.deriveBits(
      { name: 'ECDH', public: uaCryptoKey },
      asKeyPair.privateKey,
      256
    )
  );

  const salt = (await ensureCrypto()).getRandomValues(new Uint8Array(16));

  // RFC 8291 §3.3-3.4 key combination
  const prkKey = await hmacSha256(authSecret, ecdhSecret);
  const keyInfo = concatBytes(encoder.encode('WebPush: info\0'), uaPublic, asPublic, new Uint8Array([1]));
  const ikm = await hmacSha256(prkKey, keyInfo);

  // RFC 8188 §2.2-2.3 CEK & Nonce derivation
  const prk = await hmacSha256(salt, ikm);
  const cekInfo = concatBytes(encoder.encode('Content-Encoding: aes128gcm\0'), new Uint8Array([1]));
  const cekBytes = (await hmacSha256(prk, cekInfo)).slice(0, 16);
  const nonceInfo = concatBytes(encoder.encode('Content-Encoding: nonce\0'), new Uint8Array([1]));
  const nonceBytes = (await hmacSha256(prk, nonceInfo)).slice(0, 12);

  const plaintext = encoder.encode(payloadString);
  if (plaintext.length > 3800) {
    throw new Error('Web Push payload exceeds 3800 bytes (4KB frame limit)');
  }
  const paddedPlaintext = concatBytes(plaintext, new Uint8Array([0x02]));

  const aesKey = await (await ensureCrypto()).subtle.importKey('raw', cekBytes, { name: 'AES-GCM' }, false, ['encrypt']);
  const ciphertext = new Uint8Array(
    await (await ensureCrypto()).subtle.encrypt(
      { name: 'AES-GCM', iv: nonceBytes, tagLength: 128 },
      aesKey,
      paddedPlaintext
    )
  );

  // RFC 8188 §2.1 header: salt (16) || rs=4096 (4 BE) || idlen=65 (1) || asPublic (65)
  const rsBytes = new Uint8Array([0x00, 0x00, 0x10, 0x00]);
  const idLen = new Uint8Array([asPublic.length]);
  return concatBytes(salt, rsBytes, idLen, asPublic, ciphertext);
}

// Decrypts an RFC 8291 `aes128gcm` Web Push body (used by automated tests to verify spec compliance).
export async function decryptWebPushPayload(encryptedBody, uaPrivateKeyOrJwk, uaPublicBytes, authSecretBytes) {
  const uaPrivateKey =
    uaPrivateKeyOrJwk && uaPrivateKeyOrJwk.kty === 'EC'
      ? await (await ensureCrypto()).subtle.importKey(
          'jwk',
          uaPrivateKeyOrJwk,
          { name: 'ECDH', namedCurve: 'P-256' },
          false,
          ['deriveBits']
        )
      : uaPrivateKeyOrJwk;
  const salt = encryptedBody.slice(0, 16);
  const idLen = encryptedBody[20];
  const asPublic = encryptedBody.slice(21, 21 + idLen);
  const ciphertext = encryptedBody.slice(21 + idLen);

  const asCryptoKey = await (await ensureCrypto()).subtle.importKey(
    'raw',
    asPublic,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );
  const ecdhSecret = new Uint8Array(
    await (await ensureCrypto()).subtle.deriveBits({ name: 'ECDH', public: asCryptoKey }, uaPrivateKey, 256)
  );

  const prkKey = await hmacSha256(authSecretBytes, ecdhSecret);
  const keyInfo = concatBytes(encoder.encode('WebPush: info\0'), uaPublicBytes, asPublic, new Uint8Array([1]));
  const ikm = await hmacSha256(prkKey, keyInfo);

  const prk = await hmacSha256(salt, ikm);
  const cekInfo = concatBytes(encoder.encode('Content-Encoding: aes128gcm\0'), new Uint8Array([1]));
  const cekBytes = (await hmacSha256(prk, cekInfo)).slice(0, 16);
  const nonceInfo = concatBytes(encoder.encode('Content-Encoding: nonce\0'), new Uint8Array([1]));
  const nonceBytes = (await hmacSha256(prk, nonceInfo)).slice(0, 12);

  const aesKey = await (await ensureCrypto()).subtle.importKey('raw', cekBytes, { name: 'AES-GCM' }, false, ['decrypt']);
  const padded = new Uint8Array(
    await (await ensureCrypto()).subtle.decrypt({ name: 'AES-GCM', iv: nonceBytes, tagLength: 128 }, aesKey, ciphertext)
  );
  let delimIdx = padded.length - 1;
  while (delimIdx >= 0 && padded[delimIdx] === 0x00) delimIdx -= 1;
  if (delimIdx < 0 || padded[delimIdx] !== 0x02) {
    throw new Error('Missing 0x02 record delimiter in decrypted Web Push payload');
  }
  return new TextDecoder().decode(padded.slice(0, delimIdx));
}

// Sends an encrypted Web Push notification to one browser subscription.
export async function sendWebPush(subscription, payloadObj, vapidConfig, fetchImpl = globalThis.fetch) {
  if (!vapidConfig || !vapidConfig.publicKey || !vapidConfig.privateKey) {
    return { ok: false, skipped: true, reason: 'missing-vapid-keys' };
  }
  const bodyBytes = await encryptWebPushPayload(JSON.stringify(payloadObj), subscription.keys);
  const { authorization } = await createVapidAuthHeader(
    subscription.endpoint,
    vapidConfig.publicKey,
    vapidConfig.privateKey,
    vapidConfig.subject || 'mailto:family@waqt.app'
  );

  const resp = await fetchImpl(subscription.endpoint, {
    method: 'POST',
    headers: {
      Authorization: authorization,
      'Content-Type': 'application/octet-stream',
      'Content-Encoding': 'aes128gcm',
      'Content-Length': String(bodyBytes.byteLength),
      TTL: '7200',
      Urgency: 'high',
    },
    body: bodyBytes,
  });

  const gone = resp.status === 404 || resp.status === 410;
  return {
    ok: resp.status >= 200 && resp.status < 300,
    status: resp.status,
    gone,
  };
}
