// Real SQLite-backed Cloudflare D1 shim for automated tests.
// Spawns a lightweight Python 3 `sqlite3` worker process over stdio so every SQL query in
// `worker/store-d1.mjs` and `schema.sql` is tested against genuine SQLite 3!

import { spawn } from 'node:child_process';
import readline from 'node:readline';

const PYTHON_SQLITE_DRIVER = `
import json, sqlite3, sys

conn = sqlite3.connect(":memory:")
conn.row_factory = sqlite3.Row
conn.execute("PRAGMA foreign_keys = ON;")

def run_stmt(sql, params, mode):
    cur = conn.cursor()
    cur.execute(sql, params)
    if mode == "first":
        row = cur.fetchone()
        return dict(row) if row is not None else None
    elif mode == "all":
        rows = [dict(r) for r in cur.fetchall()]
        return {"results": rows}
    else:
        return {"meta": {"changes": cur.rowcount}}

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    req = json.loads(line)
    req_id = req["id"]
    try:
        op = req["op"]
        if op == "exec":
            conn.executescript(req["sql"])
            conn.commit()
            resp = {"id": req_id, "ok": True, "result": True}
        elif op == "stmt":
            res = run_stmt(req["sql"], req.get("params", []), req["mode"])
            conn.commit()
            resp = {"id": req_id, "ok": True, "result": res}
        elif op == "batch":
            out = []
            for item in req["items"]:
                out.append(run_stmt(item["sql"], item.get("params", []), item.get("mode", "run")))
            conn.commit()
            resp = {"id": req_id, "ok": True, "result": out}
        else:
            raise ValueError(f"Unknown op: {op}")
    except Exception as exc:
        conn.rollback()
        resp = {"id": req_id, "ok": False, "error": str(exc)}
    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()
`;

class PreparedStmt {
  constructor(client, sql, params = []) {
    this.client = client;
    this.sql = sql;
    this.params = params;
  }

  bind(...values) {
    return new PreparedStmt(this.client, this.sql, values);
  }

  run() {
    return this.client._rpc({ op: 'stmt', mode: 'run', sql: this.sql, params: this.params });
  }

  first() {
    return this.client._rpc({ op: 'stmt', mode: 'first', sql: this.sql, params: this.params });
  }

  all() {
    return this.client._rpc({ op: 'stmt', mode: 'all', sql: this.sql, params: this.params });
  }
}

export class SqliteD1Database {
  constructor(pythonBin = '/usr/bin/python3') {
    this.proc = spawn(pythonBin, ['-u', '-c', PYTHON_SQLITE_DRIVER], {
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    this.nextId = 1;
    this.pending = new Map();

    this.rl = readline.createInterface({ input: this.proc.stdout });
    this.rl.on('line', (line) => {
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        return;
      }
      const entry = this.pending.get(msg.id);
      if (!entry) return;
      this.pending.delete(msg.id);
      if (msg.ok) entry.resolve(msg.result);
      else entry.reject(new Error(`SQLite error: ${msg.error}`));
    });

    this.proc.on('exit', (code) => {
      for (const [, entry] of this.pending) {
        entry.reject(new Error(`SQLite subprocess exited (${code})`));
      }
      this.pending.clear();
    });
  }

  _rpc(payload) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.proc.stdin.write(`${JSON.stringify({ id, ...payload })}\n`);
    });
  }

  exec(sqlScript) {
    return this._rpc({ op: 'exec', sql: sqlScript });
  }

  prepare(sql) {
    return new PreparedStmt(this, sql);
  }

  batch(stmts) {
    const items = stmts.map((s) => ({ sql: s.sql, params: s.params, mode: 'run' }));
    return this._rpc({ op: 'batch', items });
  }

  close() {
    this.rl.close();
    try {
      this.proc.stdin.destroy();
      this.proc.stdout.destroy();
      this.proc.stderr.destroy();
      this.proc.kill('SIGKILL');
      this.proc.unref();
    } catch {
      // Ignore already-closed child handles
    }
  }
}
